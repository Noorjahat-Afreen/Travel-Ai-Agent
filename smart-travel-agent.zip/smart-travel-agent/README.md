# AI-Powered Smart Travel Agent — India

An advanced, production-style **B.Tech CSE (AI & ML) major project**: a full-stack travel
planning platform for India with a **LangChain multi-agent architecture**, **Google Gemini**
integration, **computer vision**, **real public-data APIs**, an interactive map and honest
handling of missing information.

> **Data honesty guarantee:** the platform never invents hotels, restaurants, fares,
> ratings or availability. Every record carries a named source, link and retrieval
> timestamp. Missing information renders exactly as *"details unavailable in collected
> data"*. Booking always happens on the provider's website via prefilled deep links.

---

## Feature overview

| Area | What is implemented |
| --- | --- |
| Multi-agent AI | Master Travel Agent orchestrating 12 specialised agents (LangChain + Gemini, with deterministic local fallback) |
| Trip planner | Origin → destination, dates, travellers, budget, transport mode, interests → complete plan (transport, hotels, restaurants, attractions, weather, budget, day-wise itinerary, map, booking links) |
| Destination discovery | 102 curated destinations across all Indian states + live Nominatim geocoding for anywhere in India |
| Transport | Prefilled deep links: IRCTC (station codes), redBus, Google Flights, MakeMyTrip, Skyscanner, Google Maps; OSRM road-distance estimates |
| Hotels & restaurants | Live OpenStreetMap Overpass data with Photon fallback; veg tags only where tagged |
| Weather | Open-Meteo daily forecast, honestly bounded to the ~16-day API horizon |
| Budget | Transparent category-wise estimates with assumptions + per-person split (never quoted as supplier prices) |
| Itinerary | Day-wise schedule from geographically ordered attractions; **clock times are never invented** |
| Chatbot | Tool-calling assistant grounded on the same collected data, with SQLite conversation memory (consent + clear button) |
| Computer vision | OpenCV pipeline (resize → grayscale → Gaussian blur → Canny → K-means) + Gemini Vision landmark recognition with uncertainty reporting |
| RAG | SQLite-backed BM25 retrieval over curated destination facts + Wikipedia summaries; optional sentence-transformers embeddings if installed |
| Maps | Leaflet + OpenStreetMap tiles with category markers and directions links |
| Database | SQLite via SQLAlchemy 2.0 (12 tables, PostgreSQL-ready) |
| Exports | Trip CSV + multi-sheet Excel via pandas/openpyxl |
| Testing | 95 backend pytest tests + 14 frontend vitest tests |
| Security | .env-only secrets, rate limiting, caching, retries, timeouts, CORS, log redaction |

## Quick start (local development)

### Prerequisites

- Python 3.10+ (3.12 recommended)
- Node.js 18+ (for the frontend)
- A free [Gemini API key](https://aistudio.google.com/apikey) — *optional*: without it the
  app runs in **local intelligence mode** (all data features still work; AI narratives,
  Gemini chat reasoning and landmark naming are disabled and clearly labelled).

### 1. Backend

```bash
cd backend
python -m venv venv
venv\Scripts\activate        # Windows  (source venv/bin/activate on Linux/macOS)
pip install -r requirements.txt

copy .env.example .env       # then edit: add GEMINI_API_KEY=...
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

The database (`../data/travel_agent.db`) is created and seeded automatically on startup.
Interactive API docs: <http://localhost:8000/api/docs>

### 2. Frontend

```bash
cd frontend
npm install
npm run dev          # http://localhost:5173 (proxies /api to port 8000)
```

### 3. Run the tests

```bash
cd backend && python -m pytest          # 95 tests (no network needed - providers are mocked)
cd frontend && npm test                 # 14 tests
```

## Project structure

```
smart-travel-agent/
├── frontend/                     # React 18 + TypeScript + Vite + Tailwind
│   ├── public/images/            # real destination photos (with attribution manifest)
│   └── src/
│       ├── components/           # Navbar, MapView, PlaceCard, BudgetChart, ...
│       ├── pages/                # 12 pages: Home, TripPlanner, ExploreIndia, Transport,
│       │                         # Hotels, Restaurants, Attractions, Chatbot,
│       │                         # WeatherBudget, VisionPage, SavedTrips, About
│       ├── services/             # API client (gateway-port aware), image resolver
│       ├── hooks/  context/  types/
├── backend/
│   ├── agents/                   # 12 agents + master orchestrator + LangChain tools
│   ├── api/routes/               # health, dashboard, explore, places, transport,
│   │                             # weather, trips, chat, vision, exports
│   ├── core/                     # settings, cache, rate limit, http client, logging
│   ├── database/                 # engine + init/seeding
│   ├── models/                   # 12 SQLAlchemy tables
│   ├── schemas/                  # Pydantic v2 request/response models
│   ├── services/                 # nominatim, overpass, photon, wikipedia, open_meteo,
│   │                             # osrm, data_collector, booking_links, export_service,
│   │                             # rag, llm, india_reference (curated facts)
│   ├── vision/                   # (see agents/vision_agent.py + services/llm.py)
│   ├── tests/                    # 95 pytest tests
│   ├── main.py                   # FastAPI app (also serves the built frontend)
│   └── .env.example
├── data/                         # SQLite database (created at runtime)
├── docs/                         # ARCHITECTURE, DEPLOYMENT, DATA_SOURCES, SETUP_WINDOWS
└── scripts/                      # utility scripts (image fetching)
```

## The multi-agent architecture

```
TripRequest
    │
    ▼
Master Travel Agent
    ├── 1. Destination Discovery Agent  (Nominatim + Wikipedia + curated facts)
    ├── 2. parallel ──┬─ Transport Agent   (IRCTC/redBus/Flights/Maps links + OSRM)
    │                 ├─ Hotel Agent        (Overpass → Photon fallback)
    │                 ├─ Restaurant Agent   (Overpass → Photon fallback)
    │                 ├─ Attraction Agent   (curated + live OSM + Wikipedia)
    │                 └─ Weather Agent      (Open-Meteo, horizon-aware)
    ├── 3. Budget Agent        (transparent estimates + assumptions)
    ├── 4. Itinerary Agent     (nearest-neighbour geographic scheduling)
    ├── 5. Recommendation Agent (preference ranking with reasons)
    ├── 6. Verification Agent   (source & field audit)
    └── 7. Persist + respond   (travel_plans + all record tables, plan snapshot)
```

Every agent reports a **status** (ok / degraded / error) that is displayed in the plan UI,
so examiners can see exactly which data providers succeeded — no silent failures.

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for details.

## Booking links (Book Now)

Booking buttons open **real provider searches in a new tab**, prefilled where the
provider's public URL format supports it:

- Trains → IRCTC `nget/train-search` with station codes (e.g. INDB → JP) and date
- Buses → redBus `search?fromCityName=…&toCityName=…&onward=…`
- Flights → Google Flights, MakeMyTrip (`DEL-BOM-10/12/2026`), Skyscanner
- Hotels → Booking.com `searchresults.html?ss=…&checkin=…&group_adults=…`, MakeMyTrip
- Cars / directions → Google Maps Directions API 1 URLs

The app never displays invented fares and never claims a booking was completed.

## AI mode (Gemini vs local)

| Capability | `GEMINI_API_KEY` set | No key (local mode) |
| --- | --- | --- |
| Data collection (all APIs) | ✔ | ✔ |
| Budget, itinerary, recommendations, verification | ✔ | ✔ |
| Trip summary narrative (Gemini, grounded) | ✔ | Labelled off |
| Chatbot reasoning over tools | ✔ | Rule-based router with the same real tools |
| Landmark recognition | ✔ Gemini Vision | Honest uncertainty + OpenCV features |

## API surface (selected)

```
GET  /api/health                 POST /api/trips/plan          POST /api/chat
GET  /api/ai/status              GET  /api/trips               DELETE /api/chat/history/{sid}
GET  /api/dashboard/stats        GET  /api/trips/{id}          POST /api/vision/analyze
GET  /api/explore/states         PATCH /api/trips/{id}         GET  /api/exports/trip/{id}/csv
GET  /api/explore/destinations   DELETE /api/trips/{id}        GET  /api/exports/trip/{id}/xlsx
GET  /api/explore/search?q=      GET  /api/hotels?city=…       GET  /api/weather?city=…
GET  /api/transport/search       GET  /api/restaurants?city=…  GET  /api/attractions?city=…
```

Full interactive docs at `/api/docs` (OpenAPI).

## Data sources & attribution

OpenStreetMap (Nominatim, Overpass — ODbL), Wikipedia (CC BY-SA), Open-Meteo,
OSRM, Photon by Komoot. Usage policies are respected (descriptive User-Agent,
Nominatim ≤1 req/s, caching, retries, rate limiting). See [docs/DATA_SOURCES.md](docs/DATA_SOURCES.md).

## Deployment

Render (backend) + Vercel (frontend) + PostgreSQL instructions in
[docs/DEPLOYMENT.md](docs/DEPLOYMENT.md). Windows setup walkthrough in
[docs/SETUP_WINDOWS.md](docs/SETUP_WINDOWS.md).

## Academic integrity note

All third-party data remains the property of its providers and is used for educational
demonstration with attribution. Verify live prices and availability on the linked
provider websites before making real bookings.
