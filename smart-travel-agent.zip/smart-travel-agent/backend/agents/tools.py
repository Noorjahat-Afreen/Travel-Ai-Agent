"""LangChain tools exposing agent capabilities to the conversational agent.

Each tool returns compact JSON so the LLM (or the local fallback router) can
compose grounded answers. Tools call the SAME services as the agents - there
is a single source of truth for collected data.
"""
from __future__ import annotations

import json
from datetime import date, timedelta

from langchain_core.tools import tool

from schemas.common import PlaceRecord
from services import booking_links, nominatim, open_meteo, osrm, rag


def _place_brief(r: PlaceRecord) -> dict:
    return {
        "name": r.name,
        "category": r.category,
        "address": r.address or "details unavailable in collected data",
        "distance_km": r.distance_km,
        "cuisine": r.cuisine,
        "vegetarian": r.vegetarian,
        "website": r.website,
        "map_link": r.map_link,
        "source": r.source.name,
    }


@tool
async def search_destination(city: str) -> str:
    """Get geocoding, verified description and RAG facts for an Indian destination."""
    geo = await nominatim.geocode_city(city)
    context = rag.context_for_answer(city, k=3)
    return json.dumps({
        "geocoded": geo,
        "rag_context": context or "details unavailable in collected data",
    }, default=str)


@tool
async def find_hotels(city: str) -> str:
    """Find real hotel records for a city from OpenStreetMap data."""
    from agents.hotel_agent import HotelAgent

    geo = await nominatim.geocode_city(city)
    if not geo:
        return json.dumps({"error": f"could not geocode {city}", "hotels": []})
    records = await HotelAgent().run(city, geo["lat"], geo["lon"])
    links = booking_links.hotel_links(city, date.today() + timedelta(days=7), date.today() + timedelta(days=9), 2)
    return json.dumps({
        "hotels": [_place_brief(r) for r in records[:8]],
        "booking_links": [{"label": l.label, "url": l.url, "provider": l.provider} for l in links],
    }, default=str)


@tool
async def find_restaurants(city: str) -> str:
    """Find real restaurant records (with veg tags when available) for a city."""
    from agents.restaurant_agent import RestaurantAgent

    geo = await nominatim.geocode_city(city)
    if not geo:
        return json.dumps({"error": f"could not geocode {city}", "restaurants": []})
    records = await RestaurantAgent().run(city, geo["lat"], geo["lon"])
    return json.dumps({"restaurants": [_place_brief(r) for r in records[:8]]}, default=str)


@tool
async def find_attractions(city: str) -> str:
    """Find tourist attractions with descriptions and source links."""
    from agents.attraction_agent import AttractionAgent

    geo = await nominatim.geocode_city(city)
    if not geo:
        return json.dumps({"error": f"could not geocode {city}", "attractions": []})
    records = await AttractionAgent().run(city, geo["lat"], geo["lon"])
    return json.dumps({
        "attractions": [
            {"name": r.name, "distance_km": r.distance_km, "description": (r.description or "")[:150],
             "source": r.source.name, "wiki_or_map": (r.booking_links or [{}])[0].url}
            for r in records[:10]
        ]
    }, default=str)


@tool
async def get_weather(city: str, days: int = 5) -> str:
    """Weather forecast for a city for the next N days (bounded by API horizon)."""
    geo = await nominatim.geocode_city(city)
    if not geo:
        return json.dumps({"error": f"could not geocode {city}"})
    start = date.today()
    end = start + timedelta(days=min(max(days, 1), 16) - 1)
    result = await open_meteo.forecast(geo["lat"], geo["lon"], start, end)
    return json.dumps({
        "city": city,
        "available": result["available"],
        "note": result.get("note", ""),
        "days": result["days"][:days],
        "source": result["source_name"],
    }, default=str)


@tool
async def estimate_budget(origin: str, destination: str, days: int = 3, travellers: int = 2, mode: str = "train") -> str:
    """Rough estimated budget breakdown (clearly marked as estimates, not quotes)."""
    from agents.budget_agent import BudgetAgent
    from schemas.trip import HotelPreference, FoodPreference, TransportMode, TripRequest

    geo_o = await nominatim.geocode_city(origin)
    geo_d = await nominatim.geocode_city(destination)
    distance = None
    if geo_o and geo_d:
        road = await osrm.road_route(geo_o["lat"], geo_o["lon"], geo_d["lat"], geo_d["lon"])
        distance = road["distance_km"] if road else osrm.haversine_km(geo_o["lat"], geo_o["lon"], geo_d["lat"], geo_d["lon"])
    request = TripRequest(
        origin_city=origin,
        destination_city=destination,
        start_date=date.today() + timedelta(days=7),
        end_date=date.today() + timedelta(days=6 + max(1, days)),
        travellers=max(1, travellers),
        budget_inr=10_000_000,
        transport_mode=TransportMode(mode) if mode in ("train", "bus", "flight", "car") else TransportMode.any_mode,
        hotel_preference=HotelPreference.any,
        food_preference=FoodPreference.any,
    )
    budget = BudgetAgent().compute(request, distance, [])
    return json.dumps(budget.model_dump(), default=str)


@tool
async def transport_links(origin: str, destination: str, travel_date: str = "") -> str:
    """Real booking/search deep links for train, bus, flight and car providers."""
    try:
        d = date.fromisoformat(travel_date) if travel_date else date.today() + timedelta(days=7)
    except ValueError:
        d = date.today() + timedelta(days=7)
    links = booking_links.all_transport_links(origin, destination, d, 2)
    return json.dumps(
        [{"label": l.label, "provider": l.provider, "url": l.url, "kind": l.kind} for l in links]
    )
