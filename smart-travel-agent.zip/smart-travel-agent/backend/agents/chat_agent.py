"""AI Travel Chatbot Agent.

Gemini mode: a LangChain tool-calling loop over ChatGoogleGenerativeAI with
the agent tools (real data retrieval) and SQLite-backed conversation memory
(store/user consent respected: history is kept per session id and can be
cleared via DELETE /api/chat/history/{session_id}).

Local mode: a deterministic intent router that uses the SAME tools - so the
chatbot still answers with real collected data, and clearly labels itself as
running without the AI model. It never invents prices or availability.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re

from agents import tools as agent_tools
from agents.base import BaseAgent
from core.config import settings
from database.engine import SessionLocal
from models import AIConversation
from schemas.chat import ChatResponse, DataCard
from schemas.common import SourceInfo
from services.llm import get_chat_model, llm_status

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are the AI Travel Assistant for an India trip planning platform.
Rules you MUST follow:
- Use the provided tools to retrieve REAL data (destinations, hotels, restaurants,
  attractions, weather, budget estimates, transport links). Never invent hotel or
  restaurant names, ratings, fares, availability or opening hours.
- Prices/availability: say they are confirmed on the provider website linked in the data.
- If data is missing say exactly: "details unavailable in collected data".
- Keep answers concise (max ~180 words) and friendly. Use simple markdown bullets.
- Cite the source names of records you used (e.g. "Source: OpenStreetMap").
"""

MAX_TOOL_ROUNDS = 4

SUGGESTED_PROMPTS = [
    "Plan a trip from Indore to Manali",
    "Find budget hotels in Jaipur",
    "Suggest restaurants in Udaipur",
    "Compare train and flight options Delhi to Goa",
    "Create a five-day Rajasthan itinerary",
    "Weather in Shimla next week",
]


class ChatAgent(BaseAgent):
    name = "Chat Agent"
    description = "Conversational assistant grounded on collected data."

    async def respond(self, session_id: str, message: str) -> ChatResponse:
        self._log_message(session_id, "user", message)
        mode = "gemini" if get_chat_model() is not None else "local"
        history = self._history(session_id)
        if mode == "gemini":
            response = await self._respond_gemini(session_id, message, history)
        else:
            response = await self._respond_local(session_id, message)
        response.mode = mode
        response.suggestions = response.suggestions or SUGGESTED_PROMPTS[:4]
        self._log_message(session_id, "assistant", response.reply, mode=mode, meta={"tools": response.tool_trace})
        return response

    # ------------------------------------------------------------------ gemini
    async def _respond_gemini(self, session_id: str, message: str, history: list[dict]) -> ChatResponse:
        from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

        model = get_chat_model()
        if model is None:  # safety net
            return await self._respond_local(session_id, message)

        tools = [
            agent_tools.search_destination,
            agent_tools.find_hotels,
            agent_tools.find_restaurants,
            agent_tools.find_attractions,
            agent_tools.get_weather,
            agent_tools.estimate_budget,
            agent_tools.transport_links,
        ]
        bound = model.bind_tools(tools)
        messages: list = [SystemMessage(content=SYSTEM_PROMPT)]
        for h in history[-10:]:
            messages.append(HumanMessage(content=h["content"]) if h["role"] == "user" else AIMessage(content=h["content"]))
        messages.append(HumanMessage(content=message))

        tool_trace: list[str] = []
        sources: list[SourceInfo] = []
        cards: list[DataCard] = []
        reply = ""
        for _ in range(MAX_TOOL_ROUNDS):
            response = await bound.ainvoke(messages)
            messages.append(response)
            calls = list(getattr(response, "tool_calls", None) or [])
            if not calls:
                reply = getattr(response, "content", "") or ""
                if isinstance(reply, list):
                    reply = "".join(str(x) for x in reply)
                break
            for call in calls:
                name = call.get("name", "")
                args = call.get("args", {}) or {}
                tool_trace.append(f"{name}({', '.join(f'{k}={v}' for k, v in list(args.items())[:3])[:80]})")
                fn = next((t for t in tools if t.name == name), None)
                observation = f"tool {name} unavailable"
                if fn is not None:
                    try:
                        observation = str(await fn.ainvoke(args))
                        card = self._card_from_tool(name, observation)
                        if card:
                            cards.append(card)
                        sources.append(SourceInfo(name="Collected data via agent tools", url="https://www.openstreetmap.org"))
                    except Exception as exc:  # noqa: BLE001
                        logger.warning("tool %s failed: %s", name, exc)
                        observation = json.dumps({"error": str(exc)[:120]})
                messages.append(ToolMessage(content=observation, tool_call_id=call.get("id", name)))
        if not reply:
            reply = (
                "I could not compose a final answer. Here is what I retrieved from live data; "
                "please try rephrasing your question."
            )
        return ChatResponse(reply=reply, mode="gemini", sources=sources, data_cards=cards, tool_trace=tool_trace)

    # ------------------------------------------------------------------ local
    async def _respond_local(self, session_id: str, message: str) -> ChatResponse:
        text = message.lower()
        cities = self._extract_cities(message)
        trace: list[str] = []
        cards: list[DataCard] = []

        origin, destination = (cities[:2] if len(cities) >= 2 else (None, cities[0] if cities else None))

        # Intent: transport comparison
        if re.search(r"compare.*(train|flight|bus)|train (and|vs) flight|flight (and|vs) train", text):
            links = await agent_tools.transport_links.ainvoke({
                "origin": origin or "Delhi", "destination": destination or "Jaipur"
            })
            data = json.loads(links)
            cards.append(DataCard(title="Transport provider links (train / bus / flight / car)", kind="transport", items=data))
            trace.append("transport_links")
            reply = (
                f"I cannot quote live fares, but here are prefilled booking pages for "
                f"{origin or 'your origin'} → {destination or 'your destination'}: trains on IRCTC, buses on redBus, "
                "flights on Google Flights/MakeMyTrip and driving routes on Google Maps. "
                "Open each link to see real prices and availability for your date."
            )

        # Intent: hotels
        elif re.search(r"\b(hotels?|stays?|accommodations?|lodging)\b", text) and destination:
            out = json.loads(await agent_tools.find_hotels.ainvoke({"city": destination}))
            trace.append("find_hotels")
            cards.append(DataCard(title=f"Hotels in {destination.title()} (collected)", kind="hotels", items=out.get("hotels", [])))
            if out.get("booking_links"):
                cards.append(DataCard(title="Booking search links", kind="transport", items=out["booking_links"]))
            reply = (
                f"I found {len(out.get('hotels', []))} accommodation record(s) in OpenStreetMap data for {destination.title()}. "
                "Use the booking links to check live prices - I never invent rates. "
                + ("Note: " + out["error"] if out.get("error") else "")
            )

        # Intent: restaurants
        elif re.search(r"\b(restaurants?|foods?|eats?|cafes?|dine|dining|dinner|lunch)\b", text) and destination:
            out = json.loads(await agent_tools.find_restaurants.ainvoke({"city": destination}))
            trace.append("find_restaurants")
            cards.append(DataCard(title=f"Restaurants in {destination.title()} (collected)", kind="restaurants", items=out.get("restaurants", [])))
            reply = (
                f"{len(out.get('restaurants', []))} restaurant record(s) collected from OpenStreetMap for {destination.title()}. "
                "Vegetarian flags appear only where venues are tagged; otherwise confirm directly."
            )

        # Intent: weather
        elif re.search(r"\b(weather|rain|temperature|forecast)\b", text) and destination:
            out = json.loads(await agent_tools.get_weather.ainvoke({"city": destination, "days": 5}))
            trace.append("get_weather")
            cards.append(DataCard(title=f"Weather forecast - {destination.title()}", kind="weather", items=out.get("days", [])))
            reply = (
                f"Forecast from Open-Meteo for {destination.title()}. " + out.get("note", "")
                if not out.get("available")
                else f"5-day forecast for {destination.title()} (Open-Meteo): see the weather card."
            )

        # Intent: itinerary / trip plan
        elif re.search(r"\b(plan|itinerary|trip)\b", text):
            days = 3
            m = re.search(r"(\w+)[- ]day", text)
            if m and m.group(1).isdigit():
                days = min(int(m.group(1)), 10)
            days_map = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7}
            for w, n in days_map.items():
                if w in text:
                    days = n
            budget_out = json.loads(await agent_tools.estimate_budget.ainvoke({
                "origin": origin or "Delhi", "destination": destination or "Manali",
                "days": days, "travellers": 2,
            }))
            trace.append("estimate_budget")
            links = json.loads(await agent_tools.transport_links.ainvoke({
                "origin": origin or "Delhi", "destination": destination or "Manali",
            }))
            trace.append("transport_links")
            cards.append(DataCard(title=f"Estimated budget for {days} days (algorithmic estimates)", kind="budget", items=[budget_out]))
            cards.append(DataCard(title="Booking links for each mode", kind="transport", items=links))
            att = await agent_tools.find_attractions.ainvoke({"city": destination or "Manali"})
            trace.append("find_attractions")
            att_data = json.loads(att)
            cards.append(DataCard(title=f"Attractions in {destination or 'Manali'} for your itinerary", kind="attractions", items=att_data.get("attractions", [])))
            reply = (
                f"Here is a {days}-day framework for {destination or 'Manali'}: Day 1 travel + arrival (booking links on the card), "
                "middle days schedule the collected attractions geographically (2 per day: morning/afternoon, market evening), "
                "final day departure. The budget card shows category ESTIMATES - real prices come from the provider links. "
                "Open the AI Trip Planner page for the full generated plan with map and day-wise schedule."
            )

        # Intent: attractions
        elif destination and re.search(r"\b(attraction|place|visit|famous|sightseeing|see)\b", text):
            out = json.loads(await agent_tools.find_attractions.ainvoke({"city": destination}))
            trace.append("find_attractions")
            cards.append(DataCard(title=f"Attractions in {destination.title()} (collected)", kind="attractions", items=out.get("attractions", [])))
            reply = (
                f"{len(out.get('attractions', []))} attraction record(s) with sources for {destination.title()}. "
                + ("Note: " + out.get("error", "") if out.get("error") else "Each carries a source link.")
            )

        # Intent: budget explanation
        elif re.search(r"\b(budget|cost|expense|money)\b", text):
            reply = (
                "The budget agent estimates: transport (mode × distance × travellers × 2 for round trip), "
                "hotel (tier rate × nights, 2 guests/room), food (per-person/day), activities (entry fees), "
                "local travel and a 10% emergency buffer. Every amount is an ESTIMATE - the plan page "
                "shows the full breakdown with assumptions, and booking links show real provider prices."
            )

        # Fallback: RAG-grounded info or guidance
        else:
            from services.rag import context_for_answer

            context = context_for_answer(message, k=3)
            if context:
                cards.append(DataCard(title="Knowledge base matches", kind="info", items=[{"text": context[:600]}]))
                reply = (
                    "Here is what our collected knowledge base has on that (sources included). "
                    "For live options, try asking: 'hotels in Jaipur', 'restaurants in Udaipur', "
                    "'weather in Shimla' or 'plan a trip from Indore to Manali'."
                )
            else:
                reply = (
                    "I'm running in local mode (no GEMINI_API_KEY configured), so I answer with real collected data only. "
                    "Try: 'Find budget hotels in Jaipur', 'Suggest restaurants in Udaipur', 'Weather in Manali', "
                    "'Compare train and flight options Delhi to Goa', or 'Create a five-day Rajasthan itinerary'."
                )

        return ChatResponse(
            reply=reply,
            mode="local",
            sources=[SourceInfo(name="Collected data (OpenStreetMap / Open-Meteo / Wikipedia)", url="https://www.openstreetmap.org")] if cards else [],
            data_cards=cards,
            tool_trace=trace,
        )

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _extract_cities(message: str) -> list[str]:
        """Extract candidate city names from common phrasings."""
        patterns = [
            r"from ([A-Za-z ]+?) (?:to|and) ([A-Za-z ]+?)(?:\?|$| on| for|,| with| next| this)",
            r"hotels? in ([A-Za-z ]+?)(?:\?|$| on| for|,| with| next| this)",
            r"restaurants? in ([A-Za-z ]+?)(?:\?|$| on| for|,| with| next| this)",
            r"weather in ([A-Za-z ]+?)(?:\?|$| on| for|,| with| next| this)",
            r"(?:visit|to|for) ([A-Za-z ]+?)(?:\?|$| on| for|,| with| next| this)",
        ]
        found: list[str] = []
        for pattern in patterns:
            for match in re.finditer(pattern, message, re.IGNORECASE):
                groups = [g.strip() for g in match.groups() if g and g.strip()]
                for g in groups:
                    g = re.sub(r"\b(\d+ days?|next week|tomorrow|today)\b.*$", "", g, flags=re.IGNORECASE).strip()
                    if 2 < len(g) < 40 and " " not in g.strip()[-4:]:
                        found.append(g.title() if g.isupper() or g.islower() else g)
        # Deduplicate preserving order.
        seen, result = set(), []
        for c in found:
            key = c.lower()
            if key not in seen:
                seen.add(key)
                result.append(c)
        return result[:3]

    def _card_from_tool(self, tool_name: str, observation: str) -> DataCard | None:
        try:
            data = json.loads(observation)
        except ValueError:
            return None
        mapping = {
            "find_hotels": ("Hotels (collected)", "hotels", "hotels"),
            "find_restaurants": ("Restaurants (collected)", "restaurants", "restaurants"),
            "find_attractions": ("Attractions (collected)", "attractions", "attractions"),
            "get_weather": ("Weather forecast", "weather", "days"),
            "transport_links": ("Transport booking links", "transport", None),
            "estimate_budget": ("Estimated budget", "budget", None),
            "search_destination": ("Destination facts", "info", None),
        }
        if tool_name not in mapping:
            return None
        title, kind, key = mapping[tool_name]
        items = data.get(key, []) if key else ([data] if isinstance(data, dict) else data)
        if isinstance(items, dict):
            items = [items]
        return DataCard(title=title, kind=kind, items=items[:10] if isinstance(items, list) else [items])

    # ------------------------------------------------------------------ memory
    def _history(self, session_id: str, limit: int = 10) -> list[dict]:
        def _work():
            with SessionLocal() as db:
                rows = (
                    db.query(AIConversation)
                    .filter(AIConversation.session_id == session_id)
                    .order_by(AIConversation.id.desc())
                    .limit(limit)
                    .all()
                )
                return [{"role": r.role, "content": r.content} for r in reversed(rows)]

        return asyncio.to_thread(_work).result() if False else self._run(_work)

    @staticmethod
    def _run(fn):
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(fn).result(timeout=10)

    def _log_message(self, session_id: str, role: str, content: str, mode: str = "local", meta: dict | None = None) -> None:
        def _work():
            with SessionLocal() as db:
                db.add(AIConversation(session_id=session_id, role=role, content=content[:4000], mode=mode, tool_metadata=meta))
                db.commit()

        self._run(_work)

    def clear_history(self, session_id: str) -> int:
        def _work():
            with SessionLocal() as db:
                count = db.query(AIConversation).filter(AIConversation.session_id == session_id).count()
                db.query(AIConversation).filter(AIConversation.session_id == session_id).delete()
                db.commit()
                return count

        return self._run(_work)
