"""Agent foundation: status transparency + shared behaviour.

Every specialised agent reports an AgentStatus so the UI can show exactly
which data sources succeeded, degraded or failed - no silent placeholders.
"""
from __future__ import annotations

from schemas.common import AgentStatus


class BaseAgent:
    """Base class for all specialised travel agents."""

    name: str = "agent"
    description: str = ""

    def __init__(self) -> None:
        self.status = AgentStatus(agent=self.name, status="ok", message="")

    # -- status helpers -------------------------------------------------
    def ok(self, message: str = "") -> AgentStatus:
        self.status = AgentStatus(agent=self.name, status="ok", message=message, degraded=False)
        return self.status

    def degraded(self, message: str) -> AgentStatus:
        self.status = AgentStatus(agent=self.name, status="degraded", message=message, degraded=True)
        return self.status

    def failed(self, message: str) -> AgentStatus:
        self.status = AgentStatus(agent=self.name, status="error", message=message, degraded=True)
        return self.status

    def skipped(self, message: str) -> AgentStatus:
        self.status = AgentStatus(agent=self.name, status="skipped", message=message, degraded=True)
        return self.status

    # -- shared helpers -------------------------------------------------
    @staticmethod
    def unavailable_text() -> str:
        return "details unavailable in collected data"
