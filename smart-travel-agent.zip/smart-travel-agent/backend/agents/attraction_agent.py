"""Tourist Attraction Agent - real attractions from OSM + verified descriptions."""
from __future__ import annotations

import logging

from agents.base import BaseAgent
from schemas.common import PlaceRecord
from services import data_collector, overpass, wikipedia

logger = logging.getLogger(__name__)


class AttractionAgent(BaseAgent):
    name = "Tourist Attraction Agent"
    description = "Finds tourist attractions around the destination with source links."

    async def run(
        self,
        city: str,
        lat: float,
        lon: float,
        radius_km: float | None = None,
        interests: list[str] | None = None,
        curated: list[dict] | None = None,
    ) -> list[PlaceRecord]:
        from schemas.common import SourceInfo
        from services import booking_links

        records: list[PlaceRecord] = []

        # 1) Curated reference attractions (facts + Wikipedia links).
        from services import india_reference

        for item in curated or india_reference.find_curated(city):
            records.append(
                PlaceRecord(
                    name=item["name"],
                    category="attraction",
                    lat=item["lat"],
                    lon=item["lon"],
                    city=city,
                    description=item["blurb"],
                    types=[item["category"], *item.get("tags", [])],
                    distance_km=osrm_haversine(lat, lon, item["lat"], item["lon"]),
                    source=SourceInfo(
                        name="Curated reference data (OpenStreetMap coordinates)",
                        url=india_reference.WIKI + item.get("wiki", item["name"].replace(" ", "_")),
                    ),
                    map_link=booking_links.attraction_search_link(item["name"], city).url,
                    directions_link=booking_links.directions_link(item["lat"], item["lon"], city).url,
                    booking_links=[
                        booking_links.attraction_search_link(item["name"], city),
                        booking_links.wiki_search_link(item["name"]),
                    ],
                )
            )

        # 2) Live OSM attractions around the centre.
        elements, provider = await overpass.search_pois(lat, lon, "attraction", radius_km)
        if not elements:
            elements2, provider2 = await overpass.search_pois(lat, lon, "historic", radius_km)
            elements += elements2
            provider = provider if not elements2 else provider2
        live = data_collector.normalise_elements(elements, "attraction", city, provider, center=(lat, lon))
        live = [l for l in live if l.name not in {r.name for r in records}]

        if live:
            records.extend(live)
            if provider.startswith("OpenStreetMap Overpass"):
                self.ok(f"{len(records)} attractions ({len(live)} live from {provider})")
            else:
                self.degraded(f"Overpass unavailable; live attractions via {provider}.")
        elif records:
            self.ok(f"{len(records)} curated attractions (live POI providers unavailable)")
        else:
            self.failed(f"No attraction data available for {city}.")
        return records

    async def enrich_with_wiki(self, records: list[PlaceRecord], limit: int = 3) -> None:
        """Fetch Wikipedia descriptions for the top named attractions (no invented text)."""
        for rec in records[:limit]:
            if rec.description:
                continue
            wiki = await wikipedia.summary(rec.name)
            if wiki:
                rec.description = wiki["extract"][:400]
                rec.booking_links.append(
                    __import__("services.booking_links", fromlist=["wiki_search_link"]).wiki_search_link(rec.name)
                )


def osrm_haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    from services.osrm import haversine_km

    return haversine_km(lat1, lon1, lat2, lon2)
