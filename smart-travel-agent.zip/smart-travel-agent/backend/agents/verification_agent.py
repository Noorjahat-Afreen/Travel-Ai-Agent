"""Verification Agent - audits every record before it reaches the user.

Checks performed:
- every record carries a named source (attribution present),
- coordinates are valid Indian-range values,
- itinerary contains no fabricated clock times,
- weather days fall inside the provider-supported horizon,
- placeholders replace missing information ("details unavailable in collected data").
"""
from __future__ import annotations

from agents.base import BaseAgent
from schemas.common import VerificationIssue, VerificationReport
from schemas.trip import ItineraryDay, PlaceRecord, WeatherDay


class VerificationAgent(BaseAgent):
    name = "Verification Agent"
    description = "Validates sources, fields and honesty of the assembled plan."

    def verify(
        self,
        hotels: list[PlaceRecord],
        restaurants: list[PlaceRecord],
        attractions: list[PlaceRecord],
        weather: list[WeatherDay],
        itinerary: list[ItineraryDay],
    ) -> VerificationReport:
        issues: list[VerificationIssue] = []
        checked = 0

        def check_records(kind: str, records: list[PlaceRecord]) -> None:
            nonlocal checked
            for r in records:
                checked += 1
                if not r.source.name:
                    issues.append(VerificationIssue(record=r.name, kind="missing_source", detail=f"{kind} has no provider attribution"))
                if not (-1 <= r.lat <= 90 and -1 <= r.lon <= 360 and 6 <= r.lat <= 38 and 67 <= r.lon <= 98):
                    issues.append(VerificationIssue(record=r.name, kind="suspicious", detail="coordinates outside plausible India bounds"))
                if not r.description and kind == "attraction":
                    issues.append(VerificationIssue(record=r.name, kind="missing_field", detail="description: details unavailable in collected data"))

        check_records("hotel", hotels)
        check_records("restaurant", restaurants)
        check_records("attraction", attractions)

        for w in weather:
            checked += 1
            if w.temp_min_c is None and w.temp_max_c is None:
                issues.append(VerificationIssue(record=w.date.isoformat(), kind="missing_field", detail="weather values missing"))

        for day in itinerary:
            checked += 1
            for act in day.activities:
                if any(ch.isdigit() for ch in act.period):
                    issues.append(VerificationIssue(record=f"Day {day.day_number} {act.period}", kind="suspicious", detail="clock-like time found in period field"))
                if act.description.startswith("details unavailable"):
                    issues.append(VerificationIssue(record=f"Day {day.day_number}", kind="note", detail=act.description))

        all_sourced = not any(i.kind in ("missing_source", "suspicious") for i in issues)
        summary = (
            f"{checked} records checked; {len(issues)} issue(s). "
            + ("All presented records carry provider attribution." if all_sourced else "Some records need attention - see issues.")
        )
        if issues:
            self.degraded(f"{len(issues)} verification issue(s) found")
        else:
            self.ok(f"{checked} records verified clean")
        return VerificationReport(checked_records=checked, issues=issues, all_sourced=all_sourced, summary=summary)
