"""Master Travel Agent - orchestrates all specialised agents into one plan.

Pipeline:
  1. Understand & validate the request (schema-level validation already done).
  2. Destination Discovery (geocode + verified description) - needed first
     because every other agent depends on destination coordinates.
  3. Run independent agents IN PARALLEL: Transport, Hotels, Restaurants,
     Attractions, Weather.
  4. Budget Agent consumes distance + hotel tier.
  5. Itinerary Agent schedules collected attractions geographically.
  6. Recommendation Agent ranks everything with reasons.
  7. Verification Agent audits the assembled plan.
  8. Persist to database (travel_plans + all record tables) and respond.

When GEMINI_API_KEY is configured, Gemini additionally writes a short trip
narrative (structured output) - everything else already works on real data.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import date

from agents.attraction_agent import AttractionAgent
from agents.base import BaseAgent
from agents.budget_agent import BudgetAgent
from agents.destination_agent import DestinationDiscoveryAgent
from agents.hotel_agent import HotelAgent
from agents.itinerary_agent import ItineraryAgent
from agents.recommendation_agent import RecommendationAgent
from agents.restaurant_agent import RestaurantAgent
from agents.transport_agent import TransportAgent
from agents.verification_agent import VerificationAgent
from agents.weather_agent import WeatherAgent
from core.config import settings
from database.engine import SessionLocal
from schemas.common import AgentStatus
from schemas.trip import TripPlanResponse, TripRequest
from services import data_collector, osrm

logger = logging.getLogger(__name__)


class MasterTravelAgent(BaseAgent):
    name = "Master Travel Agent"
    description = "Coordinates all specialised agents and assembles the final trip plan."

    async def plan(self, request: TripRequest) -> TripPlanResponse:
        statuses: list[AgentStatus] = []
        notes: list[str] = []

        # --- 1. Destination discovery ------------------------------------
        destination_agent = DestinationDiscoveryAgent()
        dest_info, curated = await destination_agent.run(request.destination_city)
        statuses.append(destination_agent.status)
        origin_agent = DestinationDiscoveryAgent()
        origin_geo = await origin_agent.geocode_origin(request.origin_city)
        statuses.append(origin_agent.status)

        if dest_info is None:
            # Honest failure: nothing can be planned without a destination.
            self.failed(f"Destination '{request.destination_city}' could not be located.")
            statuses.append(self.status)
            budget = BudgetAgent().compute(request, None, [])
            return TripPlanResponse(
                ai_mode="gemini" if settings.gemini_api_key else "local",
                overview=_overview(request),
                budget=budget,
                agent_statuses=statuses,
                notes=[
                    f"Destination '{request.destination_city}' not found in Nominatim or curated data. "
                    "Check the spelling or try a nearby larger city."
                ],
            )

        # --- 2. Parallel independent agents -------------------------------
        distance_km: float | None = None
        if origin_geo:
            road = await osrm.road_route(origin_geo["lat"], origin_geo["lon"], dest_info.lat, dest_info.lon)
            distance_km = road["distance_km"] if road else osrm.haversine_km(
                origin_geo["lat"], origin_geo["lon"], dest_info.lat, dest_info.lon
            )

        transport_agent = TransportAgent()
        hotel_agent = HotelAgent()
        restaurant_agent = RestaurantAgent()
        attraction_agent = AttractionAgent()
        weather_agent = WeatherAgent()

        transport_t, hotels_t, restaurants_t, attractions_t, weather_t = await asyncio.gather(
            transport_agent.run(
                request.origin_city, request.destination_city, request.start_date,
                request.travellers, request.transport_mode.value, origin_geo,
                {"lat": dest_info.lat, "lon": dest_info.lon},
            ),
            hotel_agent.run(
                request.destination_city, dest_info.lat, dest_info.lon,
                preference=request.hotel_preference.value,
            ),
            restaurant_agent.run(
                request.destination_city, dest_info.lat, dest_info.lon,
                food_preference=request.food_preference.value,
            ),
            attraction_agent.run(
                request.destination_city, dest_info.lat, dest_info.lon,
                interests=request.interests, curated=curated,
            ),
            weather_agent.run(
                request.destination_city, dest_info.lat, dest_info.lon,
                request.start_date, request.end_date,
            ),
            return_exceptions=True,
        )

        def _unpack(result, agent: BaseAgent, fallback):
            if isinstance(result, Exception):
                logger.error("%s raised: %s", agent.name, result)
                return fallback, agent.failed(f"{type(result).__name__}: {str(result)[:120]}")
            return result, agent.status

        transport, transport_status = _unpack(transport_t, transport_agent, [])
        hotels, hotels_status = _unpack(hotels_t, hotel_agent, [])
        restaurants, restaurants_status = _unpack(restaurants_t, restaurant_agent, [])
        attractions, attractions_status = _unpack(attractions_t, attraction_agent, [])
        weather, weather_status = _unpack(weather_t, weather_agent, ([], False, ""))
        statuses += [transport_status, hotels_status, restaurants_status, attractions_status, weather_status]
        weather_days, weather_available, weather_note = weather if isinstance(weather, tuple) else ([], False, "")

        # --- 3. Budget -----------------------------------------------------
        budget_agent = BudgetAgent()
        budget = budget_agent.compute(request, distance_km, hotels)
        statuses.append(budget_agent.status)

        # --- 4. Itinerary (optional Gemini narrative) -----------------------
        itinerary_agent = ItineraryAgent()
        trip_summary = ""
        if settings.gemini_api_key:
            from services.llm import structured_output

            prompt = (
                f"Write a 2-3 sentence welcoming summary for a {request.days}-day trip from "
                f"{request.origin_city} to {request.destination_city} ({request.trip_type.value} trip, "
                f"interests: {', '.join(request.interests) or 'general'}). "
                f"Destination facts: {dest_info.description or 'unavailable'}. "
                "Only use these facts; do not invent attractions or prices."
            )
            from pydantic import BaseModel

            class _Summary(BaseModel):
                summary: str

            parsed = await structured_output(_Summary, prompt)
            if parsed and parsed.summary:
                trip_summary = parsed.summary[:400]
                notes.append("Trip summary generated by Google Gemini (grounded on collected facts).")
        itinerary = itinerary_agent.generate(
            request, dest_info.lat, dest_info.lon, attractions, trip_summary=trip_summary
        )
        statuses.append(itinerary_agent.status)

        # --- 5. Recommendations --------------------------------------------
        recommendation_agent = RecommendationAgent()
        recommendations = recommendation_agent.recommend(request, hotels, restaurants, attractions)
        statuses.append(recommendation_agent.status)

        # --- 6. Verification -------------------------------------------------
        verification_agent = VerificationAgent()
        verification = verification_agent.verify(hotels, restaurants, attractions, weather_days, itinerary)
        statuses.append(verification_agent.status)

        # --- 7. Persist (off the event loop) ---------------------------------
        trip_id: int | None = None
        saved = False
        if request.save_plan:
            trip_id, saved = await asyncio.to_thread(
                self._persist, request, dest_info, origin_geo, transport,
                hotels, restaurants, attractions, weather_days, budget, itinerary,
                bool(settings.gemini_api_key), trip_summary,
            )
            if trip_id:
                notes.append(f"Trip saved to database (id {trip_id}).")

        ai_mode = "gemini" if settings.gemini_api_key else "local"
        if ai_mode == "local":
            notes.append(
                "Running in local intelligence mode (GEMINI_API_KEY not set): all data comes from "
                "live public APIs; narrative AI generation is disabled."
            )

        self.ok(f"Trip plan assembled from {sum(1 for s in statuses if s.status == 'ok')} agent result(s)")
        statuses.append(self.status)

        response = TripPlanResponse(
            trip_id=trip_id,
            title=f"{request.origin_city.title()} → {request.destination_city.title()} ({request.days} days)",
            ai_mode=ai_mode,
            overview=_overview(request),
            destination_info=dest_info,
            transport_options=transport,
            hotels=hotels,
            restaurants=restaurants,
            attractions=attractions,
            weather=weather_days,
            weather_available=weather_available,
            weather_note=weather_note,
            budget=budget,
            itinerary=itinerary,
            recommendations=recommendations,
            verification=verification,
            agent_statuses=statuses,
            map_center={"lat": dest_info.lat, "lon": dest_info.lon, "name": dest_info.name},
            saved=saved,
            notes=notes,
        )
        response.generated_at = response.generated_at
        if trip_id:
            # Store the full plan snapshot so saved trips can be re-rendered offline.
            await asyncio.to_thread(self._store_plan_json, trip_id, response.model_dump(mode="json"))
        return response

    def _store_plan_json(self, trip_id: int, plan_json: dict) -> None:
        from sqlalchemy.orm.attributes import flag_modified

        from models import TravelPlan

        try:
            with SessionLocal() as db:
                row = db.get(TravelPlan, trip_id)
                if row is None:
                    return
                row.plan_json = plan_json
                flag_modified(row, "plan_json")
                db.commit()
        except Exception as exc:  # noqa: BLE001
            logger.error("plan_json persistence failed: %s", exc)

    # ------------------------------------------------------------------ persistence
    def _persist(
        self, request, dest_info, origin_geo, transport, hotels, restaurants,
        attractions, weather_days, budget, itinerary, ai_mode: bool, trip_summary: str,
    ) -> tuple[int | None, bool]:
        from models import TravelPlan

        try:
            with SessionLocal() as db:
                row = TravelPlan(
                    session_id=request.session_id,
                    origin_city=request.origin_city,
                    destination_city=request.destination_city,
                    origin_lat=origin_geo["lat"] if origin_geo else None,
                    origin_lon=origin_geo["lon"] if origin_geo else None,
                    dest_lat=dest_info.lat,
                    dest_lon=dest_info.lon,
                    start_date=request.start_date,
                    end_date=request.end_date,
                    travellers=request.travellers,
                    budget_inr=request.budget_inr,
                    transport_mode=request.transport_mode.value,
                    trip_type=request.trip_type.value,
                    interests=request.interests,
                    hotel_preference=request.hotel_preference.value,
                    food_preference=request.food_preference.value,
                    title=f"{request.origin_city.title()} → {request.destination_city.title()} ({request.days} days)",
                    ai_mode="gemini" if ai_mode else "local",
                )
                db.add(row)
                db.flush()
                data_collector.save_destination(db, {
                    "name": dest_info.name,
                    "city": request.destination_city,
                    "state": dest_info.state,
                    "lat": dest_info.lat,
                    "lon": dest_info.lon,
                    "description": dest_info.description,
                    "wiki_url": dest_info.wiki_url,
                    "source_name": dest_info.source.name,
                    "source_url": dest_info.source.url,
                })
                data_collector.upsert_hotels(db, row.id, request.destination_city, hotels)
                data_collector.upsert_restaurants(db, row.id, request.destination_city, restaurants)
                data_collector.upsert_attractions(db, row.id, request.destination_city, attractions)
                data_collector.save_weather(
                    db, row.id, request.destination_city, dest_info.lat, dest_info.lon,
                    [
                        {"date": w.date.isoformat(), "temp_min_c": w.temp_min_c, "temp_max_c": w.temp_max_c,
                         "precipitation_probability": w.precipitation_probability,
                         "precipitation_mm": w.precipitation_mm, "condition": w.condition}
                        for w in weather_days
                    ],
                )
                data_collector.save_transport_options(db, row.id, transport)
                db.commit()
                db.refresh(row)
                return row.id, True
        except Exception as exc:  # noqa: BLE001
            logger.error("plan persistence failed: %s", exc)
            return None, False


class _OverviewFactory:
    pass


def _overview(request: TripRequest):
    from schemas.trip import TripOverview

    return TripOverview(
        origin_city=request.origin_city.title(),
        destination_city=request.destination_city.title(),
        start_date=request.start_date,
        end_date=request.end_date,
        days=request.days,
        nights=request.nights,
        travellers=request.travellers,
        budget_inr=request.budget_inr,
        budget_per_person_inr=round(request.budget_inr / request.travellers, 2),
        transport_mode=request.transport_mode.value,
        trip_type=request.trip_type.value,
    )
