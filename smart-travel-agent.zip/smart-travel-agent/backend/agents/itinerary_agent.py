"""Itinerary Agent - day-wise plans organised geographically.

Rules enforced:
- Attractions are ordered with a nearest-neighbour walk from the city centre.
- Periods are Morning / Afternoon / Evening buckets - clock times are NEVER
  invented ("Suggested order only" note is attached to every activity).
- If no attraction data exists, days contain honest guidance instead of
  fabricated venues.
"""
from __future__ import annotations

from datetime import date, timedelta

from agents.base import BaseAgent
from schemas.common import PlaceRecord
from schemas.trip import ItineraryActivity, ItineraryDay, TripRequest
from services import india_reference

THEMES_BY_TRIP_TYPE = {
    "leisure": ("Leisure & sightseeing", "Local experiences"),
    "family": ("Family fun", "Relaxed exploring"),
    "adventure": ("Adventure", "Outdoor thrills"),
    "religious": ("Spiritual journey", "Temple visits"),
    "honeymoon": ("Romantic escape", "Scenic moments"),
    "business": ("Business + quick sightseeing", "Evening leisure"),
    "heritage": ("Heritage trail", "History & culture"),
}


class ItineraryAgent(BaseAgent):
    name = "Itinerary Agent"
    description = "Builds geographic day-wise schedules from collected attractions."

    def generate(
        self,
        request: TripRequest,
        dest_lat: float,
        dest_lon: float,
        attractions: list[PlaceRecord],
        trip_summary: str = "",
    ) -> list[ItineraryDay]:
        days = request.days
        main_theme, alt_theme = THEMES_BY_TRIP_TYPE.get(request.trip_type.value, THEMES_BY_TRIP_TYPE["leisure"])
        ordered = self._order_geographically(attractions, dest_lat, dest_lon, request.interests)

        itinerary: list[ItineraryDay] = []
        idx = 0
        for day_no in range(1, days + 1):
            day_date = request.start_date + timedelta(days=day_no - 1)
            if day_no == 1:
                title = f"Arrival in {request.destination_city.title()}"
                theme = main_theme
                activities = [self._act(
                    "Morning",
                    f"Travel from {request.origin_city.title()} to {request.destination_city.title()}",
                    "Use your selected transport mode; the Transport section has prefilled booking links.",
                )]
            elif day_no == days:
                title = f"Departure day - {request.destination_city.title()} → {request.origin_city.title()}"
                theme = "Return"
                activities = [
                    self._act(
                        "Morning",
                        "Pack up and check out",
                        "Settle any pending payments; collect luggage.",
                    )
                ]
            else:
                title = f"Day {day_no}: Exploring {request.destination_city.title()}"
                theme = main_theme if day_no % 2 == 0 else alt_theme
                activities = []

            if 1 < day_no < days or (days == 2 and day_no == 1):
                # 2 sightseeing slots on full days; 1 extra slot if it's the only full day.
                slots = 2 if days > 2 else 1
                for slot, period in enumerate(("Morning", "Afternoon")):
                    if slot >= slots or idx >= len(ordered):
                        break
                    att = ordered[idx]
                    idx += 1
                    activities.append(
                        ItineraryActivity(
                            period=period,
                            title=att.name,
                            description=(att.description or "Collected attraction.")[:220],
                            place_name=att.name,
                            lat=att.lat,
                            lon=att.lon,
                            map_link=att.map_link,
                            note="Suggested order only. Confirm opening hours and entry rules with the venue or your guide.",
                        )
                    )
                activities.append(
                    self._act(
                        "Evening",
                        "Local market / food street evening",
                        "Explore a popular local market area or food street for dinner. "
                        "Ask your hotel for the closest well-known option.",
                    )
                )

            travel_note = None
            if day_no == 1 and days == 1:
                travel_note = "Same-day trip: keep at least one full slot for the return journey."
            if day_no == days:
                travel_note = "Book the return leg in advance using the transport links provided."

            itinerary.append(
                ItineraryDay(
                    day_number=day_no,
                    date=day_date,
                    title=title,
                    theme=theme,
                    activities=activities,
                    travel_note=travel_note,
                    is_ai_generated=bool(trip_summary),
                )
            )

        if not ordered:
            self.degraded(
                "No attraction records were available, so days contain general guidance "
                "(marked 'details unavailable in collected data' where relevant)."
            )
        else:
            self.ok(f"{len(ordered)} attractions scheduled across {days} day(s) using geographic ordering")
        return itinerary

    def _order_geographically(
        self,
        attractions: list[PlaceRecord],
        lat: float,
        lon: float,
        interests: list[str],
    ) -> list[PlaceRecord]:
        """Nearest-neighbour ordering from the centre with interest-based boosting."""
        if not attractions:
            return []
        remaining = list(attractions)
        interest_kw = set()
        for i in interests or []:
            interest_kw.update(kw.lower() for kw in india_reference.INTEREST_KEYWORDS.get(i.lower(), [i.lower()]))

        def interest_boost(r: PlaceRecord) -> float:
            text = " ".join([r.name, r.category, " ".join(r.types), r.description or ""]).lower()
            return -1.5 * sum(1 for kw in interest_kw if kw in text)

        current = (lat, lon)
        ordered: list[PlaceRecord] = []
        while remaining:
            best = min(
                remaining,
                key=lambda r: (
                    (r.distance_km if r.distance_km is not None else self._dist(current[0], current[1], r.lat, r.lon))
                    + interest_boost(r)
                ),
            )
            ordered.append(best)
            remaining.remove(best)
            current = (best.lat, best.lon)
        return ordered

    @staticmethod
    def _dist(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        from services.osrm import haversine_km

        return haversine_km(lat1, lon1, lat2, lon2)

    @staticmethod
    def _act(period: str, title: str, description: str) -> ItineraryActivity:
        return ItineraryActivity(period=period, title=title, description=description)
