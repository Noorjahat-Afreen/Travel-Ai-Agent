"""Hotel Agent - real accommodation records from OpenStreetMap providers.

No fake hotels, no invented prices, no fabricated ratings. Records carry the
provider name, retrieval timestamp and external booking search links.
"""
from __future__ import annotations

from datetime import date

from agents.base import BaseAgent
from schemas.common import PlaceRecord
from services import data_collector, overpass


class HotelAgent(BaseAgent):
    name = "Hotel Agent"
    description = "Discovers hotels/guest houses/hostels from public OSM data."

    async def run(
        self,
        city: str,
        lat: float,
        lon: float,
        radius_km: float | None = None,
        preference: str = "any",
    ) -> list[PlaceRecord]:
        elements, provider = await overpass.search_pois(lat, lon, "hotel", radius_km)
        records = data_collector.normalise_elements(elements, "hotel", city, provider, center=(lat, lon))
        if not elements and not records:
            self.failed(
                f"No hotel data available from Overpass or Photon for {city}. "
                "Booking search links are still provided."
            )
            return records

        records = _filter_by_preference(records, preference)
        if provider.startswith("OpenStreetMap Overpass") is False and records:
            self.degraded(f"Overpass unavailable; hotels collected via {provider}.")
        else:
            self.ok(f"{len(records)} hotel records collected from {provider}")
        return records

    async def run_for_dates(
        self,
        city: str,
        lat: float,
        lon: float,
        check_in: date,
        check_out: date,
        guests: int,
        preference: str = "any",
    ) -> tuple[list[PlaceRecord], list]:
        records = await self.run(city, lat, lon, preference=preference)
        from services import booking_links

        for r in records:
            r.booking_links = booking_links.hotel_links(city, check_in, check_out, guests)
        return records, []


def _filter_by_preference(records: list[PlaceRecord], preference: str) -> list[PlaceRecord]:
    if preference == "any" or not records:
        return records
    ranked = sorted(records, key=lambda r: (r.distance_km is None, r.distance_km or 0))
    if preference == "luxury":
        key = lambda r: (-(r.stars or 0), -(r.price_level or 0))  # noqa: E731
    elif preference == "budget":
        key = lambda r: (r.price_level if r.price_level else 9, r.distance_km or 99)  # noqa: E731
    elif preference == "homestay":
        key = lambda r: (0 if "guest_house" in r.category else 1, r.distance_km or 99)  # noqa: E731
    else:  # mid-range
        key = lambda r: (abs((r.price_level or 2) - 2), r.distance_km or 99)  # noqa: E731
    return sorted(ranked, key=key)
