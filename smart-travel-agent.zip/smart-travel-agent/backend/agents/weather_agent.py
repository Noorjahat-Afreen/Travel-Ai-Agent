"""Weather Agent - Open-Meteo forecasts, honestly bounded by the API horizon."""
from __future__ import annotations

from datetime import date

from agents.base import BaseAgent
from schemas.common import SourceInfo
from schemas.trip import WeatherDay
from services import open_meteo


class WeatherAgent(BaseAgent):
    name = "Weather Agent"
    description = "Fetches daily forecasts from Open-Meteo for the travel window."

    async def run(self, city: str, lat: float, lon: float, start: date, end: date) -> tuple[list[WeatherDay], bool, str]:
        result = await open_meteo.forecast(lat, lon, start, end)
        days = [
            WeatherDay(
                date=date.fromisoformat(d["date"]),
                temp_min_c=d.get("temp_min_c"),
                temp_max_c=d.get("temp_max_c"),
                precipitation_probability=d.get("precipitation_probability"),
                precipitation_mm=d.get("precipitation_mm"),
                condition=d.get("condition", ""),
                source=SourceInfo(
                    name=result.get("source_name", "Open-Meteo"),
                    url=result.get("source_url", "https://open-meteo.com"),
                ),
            )
            for d in result.get("days", [])
        ]
        note = result.get("note", "")
        if not result.get("available"):
            self.degraded(note or f"Forecast unavailable for {city} on the selected dates.")
        else:
            self.ok(f"{len(days)} forecast day(s) retrieved from Open-Meteo")
        return days, bool(result.get("available")), note
