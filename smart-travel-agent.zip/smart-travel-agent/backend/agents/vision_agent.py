"""Computer Vision Agent - OpenCV preprocessing + AI landmark recognition.

Pipeline:
  1. Image validation (type, size) and resize to max 1024 px.
  2. OpenCV: grayscale -> Gaussian blur -> Canny edge detection, plus feature
     statistics (edge density, brightness, contrast, Laplacian sharpness,
     dominant colours).
  3. Landmark identification via Gemini Vision when GEMINI_API_KEY is set.
     Without the key the agent reports honest uncertainty (never guesses).
  4. Identified landmarks are enriched: geocode -> Wikipedia summary ->
     nearby hotels/restaurants/attractions.
"""
from __future__ import annotations

import base64
import logging

import cv2
import numpy as np

from agents.base import BaseAgent
from schemas.vision import ImageFeatures, LandmarkResult, ProcessedImages
from services.llm import get_chat_model, identify_landmark

logger = logging.getLogger(__name__)

MAX_DIMENSION = 1024
ALLOWED_MIME = {"image/jpeg", "image/png", "image/webp"}
MAX_BYTES = 8 * 1024 * 1024


class ImageValidationError(ValueError):
    pass


class VisionAgent(BaseAgent):
    name = "Computer Vision Agent"
    description = "OpenCV image intelligence + Gemini landmark recognition."

    def validate(self, image_bytes: bytes, mime: str) -> None:
        if mime not in ALLOWED_MIME:
            raise ImageValidationError(f"unsupported image type: {mime}. Allowed: JPEG, PNG, WEBP.")
        if len(image_bytes) == 0:
            raise ImageValidationError("uploaded image is empty")
        if len(image_bytes) > MAX_BYTES:
            raise ImageValidationError("image too large (max 8 MB)")

    def preprocess(self, image_bytes: bytes) -> tuple[ProcessedImages, ImageFeatures, np.ndarray]:
        """Decode, resize and produce grayscale/edge images + statistics."""
        buffer = np.frombuffer(image_bytes, dtype=np.uint8)
        image = cv2.imdecode(buffer, cv2.IMREAD_COLOR)
        if image is None:
            raise ImageValidationError("image could not be decoded (corrupt file?)")

        h, w = image.shape[:2]
        scale = MAX_DIMENSION / max(h, w)
        if scale < 1:
            image = cv2.resize(image, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)

        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        edges = cv2.Canny(blurred, threshold1=80, threshold2=200)

        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        edge_density = float(np.count_nonzero(edges)) / float(edges.size)
        brightness = float(gray.mean())
        contrast = float(gray.std())
        dominant = self._dominant_colors(image)

        features = ImageFeatures(
            width=image.shape[1],
            height=image.shape[0],
            edge_density=round(edge_density, 4),
            brightness=round(brightness, 1),
            contrast=round(contrast, 1),
            sharpness=round(laplacian_var, 1),
            dominant_colors=dominant,
        )
        processed = ProcessedImages(
            original=self._b64(image, "jpeg"),
            grayscale=self._b64(gray, "png"),
            edges=self._b64(edges, "png"),
        )
        self.ok("Image validated and preprocessed with OpenCV")
        return processed, features, image

    @staticmethod
    def _dominant_colors(image: np.ndarray, k: int = 4) -> list[str]:
        small = cv2.resize(image, (80, 80))
        data = small.reshape((-1, 3)).astype(np.float32)
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
        _, labels, centers = cv2.kmeans(data, k, None, criteria, 3, cv2.KMEANS_PP_CENTERS)
        counts = np.bincount(labels.flatten())
        order = np.argsort(counts)[::-1]
        return ["#%02x%02x%02x" % tuple(int(c) for c in centers[i][::-1]) for i in order]

    @staticmethod
    def _b64(image: np.ndarray, fmt: str) -> str:
        ok, buf = cv2.imencode(f".{fmt}", image)
        if not ok:
            return ""
        mime = "image/png" if fmt == "png" else "image/jpeg"
        return f"data:{mime};base64,{base64.b64encode(buf.tobytes()).decode()}"

    async def identify(self, image_bytes: bytes, mime: str) -> LandmarkResult:
        """AI landmark recognition with explicit uncertainty handling."""
        if get_chat_model() is None:
            self.degraded("AI model unavailable: set GEMINI_API_KEY for landmark recognition.")
            return LandmarkResult(
                identified=False,
                landmark="",
                confidence=None,
                note=(
                    "AI landmark identification requires GEMINI_API_KEY in backend/.env. "
                    "OpenCV feature analysis is shown on the right; try Google Lens for visual search."
                ),
            )
        data = await identify_landmark(image_bytes, mime)
        if not data:
            self.degraded("Gemini vision call failed; treat result as unidentified.")
            return LandmarkResult(
                identified=False,
                landmark="",
                confidence=None,
                note="The vision model could not be reached or returned an unparseable answer.",
            )
        confidence = float(data.get("confidence", 0.0))
        landmark = (data.get("landmark") or "").strip()
        if not landmark or confidence < 0.4:
            self.degraded(f"Low identification confidence ({confidence:.2f}) - reporting uncertainty.")
            return LandmarkResult(
                identified=False,
                landmark=landmark,
                confidence=confidence,
                rationale=data.get("rationale", ""),
                note="The model could not identify this landmark confidently. No guess is shown.",
            )
        self.ok(f"Landmark identified: {landmark} (confidence {confidence:.2f})")
        return LandmarkResult(
            identified=True,
            landmark=landmark,
            confidence=confidence,
            city=data.get("city", ""),
            state=data.get("state", ""),
            country=data.get("country", "India"),
            rationale=data.get("rationale", ""),
        )
