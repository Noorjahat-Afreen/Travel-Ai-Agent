"""Recommendation Agent - ranked suggestions with explainable reasons."""
from __future__ import annotations

from agents.base import BaseAgent
from schemas.common import PlaceRecord, RecommendationItem, RecommendationSet
from schemas.trip import TripRequest
from services import india_reference


class RecommendationAgent(BaseAgent):
    name = "Recommendation Agent"
    description = "Ranks collected hotels/restaurants/attractions against user preferences."

    def recommend(
        self,
        request: TripRequest,
        hotels: list[PlaceRecord],
        restaurants: list[PlaceRecord],
        attractions: list[PlaceRecord],
    ) -> RecommendationSet:
        tier = request.hotel_preference.value
        food = request.food_preference.value
        interests = [i.lower() for i in request.interests]

        hotel_items = self._rank(
            hotels,
            key=lambda r: (
                0 if tier == "any" else (1 if r.price_level and _level_tier(r.price_level) == tier else 0),
                -(r.stars or 0),
                r.distance_km or 9.9,
            ),
            reason=lambda r: _hotel_reason(r, tier, request.destination_city),
        )[:3]

        veg_first = food in ("vegetarian", "vegan")
        restaurant_items = self._rank(
            restaurants,
            key=lambda r: (
                0 if (not veg_first or r.vegetarian is True) else 1,
                0 if (r.vegetarian is True or (food != "any")) else 1,
                r.distance_km or 9.9,
            ),
            reason=lambda r: _food_reason(r, food, request.destination_city),
        )[:3]

        def attraction_score(r: PlaceRecord) -> float:
            text = " ".join([r.name, " ".join(r.types), r.description or ""]).lower()
            boost = sum(1 for i in interests for kw in india_reference.INTEREST_KEYWORDS.get(i, [i]) if kw in text)
            return -(boost * 2) + (r.distance_km or 9.9) / 10

        attraction_items = self._rank(
            attractions,
            key=lambda r: attraction_score(r),
            reason=lambda r: _attraction_reason(r, interests, request.destination_city),
        )[:3]

        if hotels or restaurants or attractions:
            self.ok(
                f"Recommended {len(hotel_items)} hotels, {len(restaurant_items)} restaurants, "
                f"{len(attraction_items)} attractions with reasons"
            )
        else:
            self.degraded("No collected records available to rank - nothing was invented.")
        return RecommendationSet(hotels=hotel_items, restaurants=restaurant_items, attractions=attraction_items)

    @staticmethod
    def _rank(records: list[PlaceRecord], key, reason) -> list[RecommendationItem]:
        ranked = sorted([r for r in records], key=key)
        return [RecommendationItem(record=r, reason=reason(r)) for r in ranked[:5]]


def _level_tier(level: int) -> str:
    return {1: "budget", 2: "mid-range", 3: "mid-range", 4: "luxury"}.get(level, "mid-range")


def _hotel_reason(r: PlaceRecord, tier: str, city: str) -> str:
    bits = [f"{r.distance_km:.1f} km from {city} centre" if r.distance_km is not None else "central location"]
    if r.stars:
        bits.append(f"{r.stars}-star tagged")
    if r.price_level:
        bits.append(f"price level {r.price_level}/4 in OSM tags")
    if tier != "any":
        bits.append(f"matches your {tier} preference" if _level_tier(r.price_level or 2) == tier else "closest to your tier preference in collected data")
    return "Selected for " + ", ".join(bits) + ". Source: " + r.source.name


def _food_reason(r: PlaceRecord, food: str, city: str) -> str:
    bits = []
    if r.vegetarian is True:
        bits.append("explicitly tagged vegetarian in OpenStreetMap")
    if r.cuisine:
        bits.append(f"serves {r.cuisine.replace(';', ', ')} cuisine")
    if r.distance_km is not None:
        bits.append(f"{r.distance_km:.1f} km from centre")
    if food in ("vegetarian", "vegan") and r.vegetarian is not True:
        bits.append("confirm veg menu directly - no veg tag in collected data")
    return ("Chosen because it is " + ", ".join(bits) + ".") if bits else "Top result from collected data."


def _attraction_reason(r: PlaceRecord, interests: list[str], city: str) -> str:
    kw_pool = set()
    for i in interests:
        kw_pool.update(india_reference.INTEREST_KEYWORDS.get(i, [i]))
    matched = [kw for kw in kw_pool if kw in " ".join([r.name, " ".join(r.types), r.description or ""]).lower()]
    if matched:
        return f"Matches your interests ({', '.join(sorted(set(matched)))}); {r.distance_km:.1f} km from centre." if r.distance_km is not None else f"Matches your interests ({', '.join(sorted(set(matched)))})."
    if r.distance_km is not None:
        return f"Popular collected attraction {r.distance_km:.1f} km from {city} centre."
    return "Popular attraction in collected data."
