"""Transport Agent - train / bus / flight / car options with real provider links.

This agent NEVER invents fares or availability. It returns:
- deep links to official providers (IRCTC, redBus, Google Flights, MakeMyTrip,
  Skyscanner, Google Maps) prefilled with cities and dates where documented;
- optional OSRM road distance/duration estimates for car travel, labelled as
  estimates with their source.
"""
from __future__ import annotations

from datetime import date

from agents.base import BaseAgent
from schemas.common import SourceInfo
from schemas.trip import TransportOptionOut
from services import booking_links, osrm


class TransportAgent(BaseAgent):
    name = "Transport Agent"
    description = "Builds provider deep links and road distance estimates for all modes."

    async def run(
        self,
        origin_city: str,
        dest_city: str,
        travel_date: date,
        travellers: int,
        mode: str = "any",
        origin_geo: dict | None = None,
        dest_geo: dict | None = None,
    ) -> list[TransportOptionOut]:
        options: list[TransportOptionOut] = []
        src = SourceInfo(name="Provider booking websites", url="")

        road = None
        if origin_geo and dest_geo:
            road = await osrm.road_route(
                origin_geo["lat"], origin_geo["lon"], dest_geo["lat"], dest_geo["lon"]
            )
        distance_km = road["distance_km"] if road else (
            osrm.haversine_km(origin_geo["lat"], origin_geo["lon"], dest_geo["lat"], dest_geo["lon"])
            if origin_geo and dest_geo
            else None
        )

        # --- Trains ---
        if mode in ("any", "train"):
            links = booking_links.train_links(origin_city, dest_city, travel_date)
            primary = links[0]
            options.append(
                TransportOptionOut(
                    mode="train",
                    provider=primary.provider,
                    summary=(
                        f"Search trains {origin_city} → {dest_city} on {travel_date.isoformat()}"
                        + (f" (route ≈ {distance_km} km)" if distance_km else "")
                    ),
                    detail="Live schedules, seat availability and fares are shown on the IRCTC website.",
                    deep_link=primary.url,
                    origin_city=origin_city,
                    destination_city=dest_city,
                    travel_date=travel_date,
                    is_estimate=False,
                    notes="The app does not display or store rail fares; confirm on IRCTC.",
                    source=src,
                    booking_links=links,
                )
            )

        # --- Buses ---
        if mode in ("any", "bus"):
            links = booking_links.bus_links(origin_city, dest_city, travel_date)
            primary = links[0]
            options.append(
                TransportOptionOut(
                    mode="bus",
                    provider=primary.provider,
                    summary=f"Search buses {origin_city} → {dest_city} on {_pretty(travel_date)}",
                    detail="Live operators, amenities and fares are shown on redBus.",
                    deep_link=primary.url,
                    origin_city=origin_city,
                    destination_city=dest_city,
                    travel_date=travel_date,
                    is_estimate=False,
                    notes="The app does not display or store bus fares; confirm on the provider.",
                    source=src,
                    booking_links=links,
                )
            )

        # --- Flights ---
        if mode in ("any", "flight"):
            links = booking_links.flight_links(origin_city, dest_city, travel_date, travellers)
            primary = links[0]
            options.append(
                TransportOptionOut(
                    mode="flight",
                    provider=primary.provider,
                    summary=f"Search flights {origin_city} → {dest_city} on {travel_date.isoformat()}",
                    detail="Fares and availability change constantly; compare on the provider sites.",
                    deep_link=primary.url,
                    origin_city=origin_city,
                    destination_city=dest_city,
                    travel_date=travel_date,
                    is_estimate=False,
                    notes="The app does not display or store air fares; confirm on the provider.",
                    source=src,
                    booking_links=links,
                )
            )

        # --- Car ---
        if mode in ("any", "car"):
            links = booking_links.car_links(origin_city, dest_city)
            primary = links[0]
            est = None
            detail = "Driving route, live traffic and tolls open on Google Maps."
            if road:
                est = round(distance_km * 8 + 0.08 * distance_km)  # fuel+wear, tolls
                detail += f" OSRM estimates ≈ {road['distance_km']} km / {road['duration_hours']} h (source: {road['source']})."
            elif distance_km:
                detail += f" Straight-line distance ≈ {distance_km} km; road distance is longer."
            options.append(
                TransportOptionOut(
                    mode="car",
                    provider=primary.provider,
                    summary=f"Driving route {origin_city} → {dest_city}",
                    detail=detail,
                    deep_link=primary.url,
                    origin_city=origin_city,
                    destination_city=dest_city,
                    travel_date=travel_date,
                    is_estimate=est is not None,
                    estimated_cost_inr=est,
                    notes="Self-drive cost is a rough fuel estimate, not a quote.",
                    source=SourceInfo(name=road["source"] if road else "Google Maps", url=road["source_url"] if road else "https://www.google.com/maps"),
                    booking_links=links,
                )
            )

        if not options:
            self.degraded("No transport providers matched the request.")
        else:
            self.ok(f"{len(options)} transport mode(s) prepared with provider links")
        return options

    async def road_estimate(self, origin_geo: dict, dest_geo: dict) -> dict | None:
        return await osrm.road_route(origin_geo["lat"], origin_geo["lon"], dest_geo["lat"], dest_geo["lon"])


def _pretty(d: date) -> str:
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    return f"{d.day:02d}-{months[d.month - 1]}-{d.year}"
