"""Budget Agent - transparent category-wise estimates with per-person split.

ALL amounts are algorithmic estimates clearly separated from provider prices.
Assumption text is included so examiners can audit every rupee.
"""
from __future__ import annotations

from datetime import date

from agents.base import BaseAgent
from schemas.common import PlaceRecord
from schemas.trip import BudgetBreakdown, BudgetCategory, TripRequest

# Rough national-average per-person unit costs (INR). Clearly labelled estimates.
TRANSPORT_COST_PER_KM = {
    "train": 1.3,      # approx AC3 average
    "bus": 1.6,        # approx AC seater/sleeper average
    "flight": 2.4,     # avg domestic economy beyond base
    "car": 9.0,        # fuel + wear + tolls per km (self drive)
}
TRANSPORT_MIN = {"train": 180, "bus": 250, "flight": 2200, "car": 400}
HOTEL_PER_NIGHT = {"budget": 1200, "mid-range": 2800, "luxury": 7500, "homestay": 1800, "any": 2500}
FOOD_PER_DAY = {"vegetarian": 400, "vegan": 400, "local": 550, "continental": 900, "any": 500}
ACTIVITY_PER_DAY = 300   # entry fees / local sightseeing, per person
LOCAL_TRAVEL_PER_DAY = 350  # autos/cabs in destination, per group share


class BudgetAgent(BaseAgent):
    name = "Budget Agent"
    description = "Calculates estimated category-wise spend and per-person split."

    def compute(
        self,
        request: TripRequest,
        distance_km: float | None,
        hotels: list[PlaceRecord],
    ) -> BudgetBreakdown:
        days = request.days
        nights = max(days - 1, 0) or 1
        travellers = request.travellers
        mode = request.transport_mode.value if request.transport_mode else "train"
        assumptions: list[str] = []

        # --- Transport -------------------------------------------------
        if distance_km is None:
            distance_km = 500.0
            assumptions.append("Distance unknown - transport estimate uses an assumed 500 km each way.")
        mode_for_cost = mode if mode in TRANSPORT_COST_PER_KM else "train"
        one_way = max(
            TRANSPORT_MIN[mode_for_cost], distance_km * TRANSPORT_COST_PER_KM[mode_for_cost]
        )
        transport_total = round(one_way * 2 * travellers)  # round trip
        assumptions.append(
            f"{mode_for_cost.title()}: ≈ ₹{one_way:.0f}/person one-way × {travellers} traveller(s) × 2 (round trip)."
        )

        # --- Hotel -----------------------------------------------------
        tier = request.hotel_preference.value
        per_night = HOTEL_PER_NIGHT.get(tier, HOTEL_PER_NIGHT["any"])
        tagged = [h.price_level for h in hotels if h.price_level]
        if tagged:
            median_level = sorted(tagged)[len(tagged) // 2]
            per_night = {1: 1100, 2: 2400, 3: 4500, 4: 9000}.get(median_level, per_night)
            assumptions.append(
                f"Hotel rate derived from OSM price_level tags of collected hotels (median level {median_level})."
            )
        else:
            assumptions.append(f"Hotel rate is the standard {tier} estimate ₹{per_night}/night for {nights} night(s).")
        hotel_total = round(per_night * nights * max(1, round(travellers / 2)))  # ~2 per room
        assumptions.append("Rooms assumed for 2 guests per room; adjust for your actual room split.")

        # --- Food ------------------------------------------------------
        food_pday = FOOD_PER_DAY.get(request.food_preference.value, FOOD_PER_DAY["any"])
        food_total = round(food_pday * days * travellers)
        assumptions.append(f"Food: ₹{food_pday}/person/day × {days} day(s) × {travellers} traveller(s).")

        # --- Activities ------------------------------------------------
        activity_total = round(ACTIVITY_PER_DAY * days * travellers)
        assumptions.append(f"Activities/entry fees: ₹{ACTIVITY_PER_DAY}/person/day (heritage sites ₹100-700 each).")

        # --- Local travel ---------------------------------------------
        local_total = round(LOCAL_TRAVEL_PER_DAY * days)
        assumptions.append(f"Local transport in destination: ≈ ₹{LOCAL_TRAVEL_PER_DAY}/day for the group.")

        subtotal = transport_total + hotel_total + food_total + activity_total + local_total
        emergency = round(subtotal * 0.10)
        assumptions.append("Emergency buffer: 10% of the estimated subtotal.")

        total = subtotal + emergency
        categories = [
            BudgetCategory(category="Transport", estimated_inr=transport_total, note=f"{mode_for_cost} round trip, {travellers} traveller(s)"),
            BudgetCategory(category="Hotel", estimated_inr=hotel_total, note=f"{tier} tier × {nights} night(s)"),
            BudgetCategory(category="Food", estimated_inr=food_total, note=f"{request.food_preference.value} preference"),
            BudgetCategory(category="Activities", estimated_inr=activity_total, note="Entry fees & sightseeing"),
            BudgetCategory(category="Local travel", estimated_inr=local_total, note="Autos / cabs in destination"),
            BudgetCategory(category="Emergency buffer", estimated_inr=emergency, note="10% of subtotal"),
        ]
        per_person = round(total / travellers)
        self.ok(f"Estimated total ₹{total:,} (₹{per_person:,}/person) vs budget ₹{request.budget_inr:,.0f}")
        return BudgetBreakdown(
            total_estimated_inr=total,
            per_person_inr=per_person,
            within_budget=total <= request.budget_inr,
            user_budget_inr=request.budget_inr,
            categories=categories,
            assumptions=assumptions,
        )


def per_day_totals(budget: BudgetBreakdown, days: int) -> dict[str, float]:
    """Daily allocation helper for the UI charts."""
    days = max(days, 1)
    return {c.category: round(c.estimated_inr / days, 0) for c in budget.categories}
