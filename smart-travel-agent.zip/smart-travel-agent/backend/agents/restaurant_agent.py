"""Restaurant Agent - real restaurants/cafes from OpenStreetMap providers."""
from __future__ import annotations

from agents.base import BaseAgent
from schemas.common import PlaceRecord
from services import data_collector, overpass


class RestaurantAgent(BaseAgent):
    name = "Restaurant Agent"
    description = "Discovers restaurants/cafes and vegetarian tags from public OSM data."

    async def run(
        self,
        city: str,
        lat: float,
        lon: float,
        radius_km: float | None = None,
        food_preference: str = "any",
    ) -> list[PlaceRecord]:
        elements, provider = await overpass.search_pois(lat, lon, "restaurant", radius_km)
        records = data_collector.normalise_elements(elements, "restaurant", city, provider, center=(lat, lon))
        if not records:
            self.failed(f"No restaurant data available from Overpass or Photon for {city}.")
            return records

        if food_preference in ("vegetarian", "vegan"):
            veg = [r for r in records if r.vegetarian is True]
            if veg:
                records = veg + [r for r in records if r.vegetarian is None]
            else:
                self.degraded(
                    "No explicitly tagged vegetarian venues in collected data; showing all venues - "
                    "confirm menu options with each restaurant."
                )

        if provider.startswith("OpenStreetMap Overpass"):
            self.ok(f"{len(records)} restaurant records collected from {provider}")
        else:
            self.degraded(f"Overpass unavailable; restaurants collected via {provider}.")
        return records
