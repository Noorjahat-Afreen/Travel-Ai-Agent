"""Destination Discovery Agent.

Coordinates Nominatim geocoding, Wikipedia verification summaries and the
curated India reference dataset to produce a trusted destination profile.
"""
from __future__ import annotations

import logging

from services import india_reference, nominatim, wikipedia
from schemas.trip import DestinationInfo
from schemas.common import SourceInfo
from agents.base import BaseAgent

logger = logging.getLogger(__name__)


class DestinationDiscoveryAgent(BaseAgent):
    name = "Destination Discovery Agent"
    description = "Geocodes cities and collects verified destination descriptions."

    async def run(self, city: str) -> tuple[DestinationInfo | None, list[dict]]:
        geo = await nominatim.geocode_city(city)
        curated = india_reference.find_curated(city)
        by_name = india_reference.find_curated_by_name(city)
        if by_name and not curated:
            curated = [by_name]

        state = ""
        description = None
        wiki_url = None
        source_name, source_url = "OpenStreetMap Nominatim", "https://nominatim.openstreetmap.org"

        if curated:
            # Curated coordinates are OSM-sourced reference facts.
            state = curated[0]["state"]
            wiki_url = india_reference.WIKI + curated[0].get("wiki", curated[0]["name"].replace(" ", "_"))
            source_url = wiki_url
        if geo:
            state = state or geo.get("state", "")

        # City-level description first (the destination is the city, not a single POI),
        # then fall back to the flagship curated attraction's Wikipedia article.
        wiki = await wikipedia.summary(city)
        if wiki is None and curated:
            wiki = await wikipedia.summary(curated[0].get("wiki", curated[0]["name"]))
        if wiki:
            description = wiki["extract"]
            wiki_url = wiki["url"]
            source_name, source_url = "Wikipedia (CC BY-SA)", wiki["url"]
            await self._index_wiki(city, wiki, state)
        elif curated:
            description = (
                f"{city.title()} is known for " + ", ".join(i["name"] for i in curated[:4]) + ". "
                + curated[0]["blurb"]
            )

        if geo is None and not curated:
            self.failed(f"Could not geocode '{city}' via Nominatim; no curated reference found.")
            return None, curated

        lat = (geo["lat"] if geo else None) or (curated[0]["lat"] if curated else None)
        lon = (geo["lon"] if geo else None) or (curated[0]["lon"] if curated else None)
        if lat is None or lon is None:
            self.failed("No coordinates available for destination.")
            return None, curated

        display_name = (geo["name"] if geo else None) or (city.title() if city.islower() else city)
        self.ok(f"Destination resolved: {display_name}" + (f" ({state})" if state else ""))
        return (
            DestinationInfo(
                name=display_name,
                city=city.title() if city.islower() else city,
                state=state,
                lat=float(lat),
                lon=float(lon),
                description=description,
                wiki_url=wiki_url,
                source=SourceInfo(name=source_name, url=source_url),
            ),
            curated,
        )

    async def _index_wiki(self, city: str, wiki: dict, state: str) -> None:
        try:
            from database.engine import SessionLocal
            from services import rag

            def _work() -> None:
                with SessionLocal() as db:
                    rag.ingest_wiki_summary(
                        db,
                        ref=rag.slug(f"{wiki['title']} {city}"),
                        title=f"{wiki['title']} ({city}, {state})" if state else wiki["title"],
                        extract=wiki["extract"],
                        url=wiki["url"],
                    )

            import asyncio

            await asyncio.to_thread(_work)
        except Exception as exc:  # noqa: BLE001
            logger.warning("wiki RAG ingest skipped: %s", exc)

    async def geocode_origin(self, city: str) -> dict | None:
        geo = await nominatim.geocode_city(city)
        if geo:
            self.ok(f"Origin geocoded: {geo['name']}")
        else:
            self.degraded(f"Origin '{city}' could not be geocoded - transport estimates use city names only.")
        return geo
