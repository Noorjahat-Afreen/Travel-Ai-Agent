"""Create all tables and seed reference data (idempotent, safe to re-run)."""
from __future__ import annotations

import logging

from sqlalchemy.orm import Session

from database.engine import Base, engine, SessionLocal
from models import *  # noqa: F401,F403  (register all models on Base.metadata)
from models import DataSource
from services import india_reference
from services.rag import ingest_curated_destinations

logger = logging.getLogger(__name__)

SEED_PROVIDERS = [
    DataSource(
        name="OpenStreetMap Nominatim",
        base_url="https://nominatim.openstreetmap.org",
        usage_policy="https://operations.osmfoundation.org/policies/nominatim/",
    ),
    DataSource(
        name="OpenStreetMap Overpass",
        base_url="https://overpass-api.de",
        usage_policy="https://dev.overpass-api.de/overpass-doc/",
    ),
    DataSource(
        name="Open-Meteo",
        base_url="https://open-meteo.com",
        usage_policy="https://open-meteo.com/en/terms",
    ),
    DataSource(
        name="Wikipedia REST API",
        base_url="https://en.wikipedia.org/api/rest_v1",
        usage_policy="https://www.mediawiki.org/wiki/API:REST_api",
    ),
    DataSource(
        name="OSRM public router",
        base_url="https://router.project-osrm.org",
        usage_policy="https://github.com/Project-OSRM/osrm-backend/wiki",
    ),
    DataSource(
        name="Photon by Komoot",
        base_url="https://photon.komoot.io",
        usage_policy="https://photon.komoot.io",
    ),
]


def init_db() -> None:
    """Create tables and seed static reference data. Safe to call repeatedly."""
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        _seed_providers(db)
        india_reference.seed_destinations(db)
        ingest_curated_destinations(db)
    logger.info("Database ready at %s", settings_db_path())


def settings_db_path() -> str:
    from core.config import settings

    return settings.db_url


def _seed_providers(db: Session) -> None:
    for provider in SEED_PROVIDERS:
        existing = db.query(DataSource).filter(DataSource.name == provider.name).first()
        if existing is None:
            db.add(provider)
    db.commit()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    init_db()
    print("database initialised")
