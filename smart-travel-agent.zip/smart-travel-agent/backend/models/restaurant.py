"""Restaurants / cafes collected from public OSM data (never fabricated)."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from database.engine import Base
from models.user import utcnow


class Restaurant(Base):
    __tablename__ = "restaurants"
    __table_args__ = (UniqueConstraint("name", "city", "lat", "lon", name="uq_restaurant_place"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    plan_id: Mapped[int | None] = mapped_column(ForeignKey("travel_plans.id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(200), index=True)
    city: Mapped[str] = mapped_column(String(120), index=True)
    cuisine: Mapped[str | None] = mapped_column(String(200), nullable=True)   # OSM cuisine tags, ";" separated
    address: Mapped[str | None] = mapped_column(String(400), nullable=True)
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    website: Mapped[str | None] = mapped_column(String(400), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(60), nullable=True)
    vegetarian: Mapped[bool | None] = mapped_column(Boolean, nullable=True)   # only when tagged
    kind: Mapped[str] = mapped_column(String(30), default="restaurant")       # restaurant|cafe|fast_food
    source_name: Mapped[str] = mapped_column(String(80), default="OpenStreetMap Overpass")
    source_url: Mapped[str] = mapped_column(String(400), default="")
    retrieved_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
