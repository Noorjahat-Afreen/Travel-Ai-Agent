"""RAG document store: normalised destination knowledge used for retrieval.

Lightweight SQLite-backed retrieval (BM25 ranking computed at query time).
Optional dense embeddings are only used when a suitable local model
(sentence-transformers) is installed - see services/rag.py.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import JSON, DateTime, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from database.engine import Base
from models.user import utcnow


class RAGDocument(Base):
    __tablename__ = "rag_documents"

    id: Mapped[int] = mapped_column(primary_key=True)
    doc_type: Mapped[str] = mapped_column(String(40), index=True)   # destination|attraction|wiki
    ref_id: Mapped[str] = mapped_column(String(200), index=True)    # stable key, e.g. "jaipur"
    title: Mapped[str] = mapped_column(String(220))
    content: Mapped[str] = mapped_column(Text)
    meta: Mapped[dict | None] = mapped_column(JSON, nullable=True)  # source urls, tags, coords
    embedding: Mapped[bytes | None] = mapped_column(nullable=True)  # optional vector blob
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
