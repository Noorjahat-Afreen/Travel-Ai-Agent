"""Transport options: deep links to legitimate providers (no fabricated fares)."""
from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Boolean, Date, DateTime, Float, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from database.engine import Base
from models.user import utcnow


class TransportOption(Base):
    __tablename__ = "transport_options"

    id: Mapped[int] = mapped_column(primary_key=True)
    plan_id: Mapped[int | None] = mapped_column(ForeignKey("travel_plans.id"), nullable=True, index=True)
    mode: Mapped[str] = mapped_column(String(20))                 # train|bus|flight|car
    provider: Mapped[str] = mapped_column(String(120))
    summary: Mapped[str] = mapped_column(String(400), default="")
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)   # e.g. distance/duration estimate source
    deep_link: Mapped[str] = mapped_column(String(600))
    origin_city: Mapped[str] = mapped_column(String(120), default="")
    destination_city: Mapped[str] = mapped_column(String(120), default="")
    travel_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    # Estimates are clearly separated from any provider-supplied price.
    is_estimate: Mapped[bool] = mapped_column(Boolean, default=False)
    estimated_cost_inr: Mapped[float | None] = mapped_column(Float, nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    source_name: Mapped[str] = mapped_column(String(80), default="Provider website")
    source_url: Mapped[str] = mapped_column(String(400), default="")
    retrieved_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
