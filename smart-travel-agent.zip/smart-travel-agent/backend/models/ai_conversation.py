"""AI conversation history (chatbot messages + tool metadata)."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import JSON, DateTime, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from database.engine import Base
from models.user import utcnow


class AIConversation(Base):
    __tablename__ = "ai_conversations"

    id: Mapped[int] = mapped_column(primary_key=True)
    session_id: Mapped[str] = mapped_column(String(64), index=True)
    role: Mapped[str] = mapped_column(String(16))                 # user|assistant
    content: Mapped[str] = mapped_column(Text)
    # Optional structured context: which tools ran, which sources were used.
    tool_metadata: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    mode: Mapped[str] = mapped_column(String(20), default="local")  # gemini|local
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
