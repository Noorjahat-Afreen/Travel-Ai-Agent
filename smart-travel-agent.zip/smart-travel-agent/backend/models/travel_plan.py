"""Travel plans created by the AI planner or saved manually."""
from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import JSON, DateTime, Date, Float, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from database.engine import Base
from models.user import utcnow


class TravelPlan(Base):
    __tablename__ = "travel_plans"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    session_id: Mapped[str | None] = mapped_column(String(64), index=True)

    origin_city: Mapped[str] = mapped_column(String(120))
    destination_city: Mapped[str] = mapped_column(String(120), index=True)
    origin_lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    origin_lon: Mapped[float | None] = mapped_column(Float, nullable=True)
    dest_lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    dest_lon: Mapped[float | None] = mapped_column(Float, nullable=True)

    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date] = mapped_column(Date)
    travellers: Mapped[int] = mapped_column(Integer)
    budget_inr: Mapped[float] = mapped_column(Float)
    transport_mode: Mapped[str] = mapped_column(String(20))
    trip_type: Mapped[str] = mapped_column(String(40), default="leisure")
    interests: Mapped[list | None] = mapped_column(JSON, nullable=True)
    hotel_preference: Mapped[str] = mapped_column(String(40), default="any")
    food_preference: Mapped[str] = mapped_column(String(40), default="any")

    status: Mapped[str] = mapped_column(String(20), default="planned")  # planned|completed|archived
    title: Mapped[str] = mapped_column(String(200), default="")
    # Full generated plan snapshot (JSON) so a saved trip can be re-rendered offline.
    plan_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    ai_mode: Mapped[str] = mapped_column(String(20), default="local")  # gemini|local

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
