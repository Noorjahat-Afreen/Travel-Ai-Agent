"""Tourist attractions collected from OSM / Wikipedia (never fabricated)."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Float, ForeignKey, JSON, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from database.engine import Base
from models.user import utcnow


class Attraction(Base):
    __tablename__ = "attractions"
    __table_args__ = (UniqueConstraint("name", "city", "lat", "lon", name="uq_attraction_place"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    plan_id: Mapped[int | None] = mapped_column(ForeignKey("travel_plans.id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(200), index=True)
    city: Mapped[str] = mapped_column(String(120), index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    types: Mapped[list | None] = mapped_column(JSON, nullable=True)           # e.g. ["historic","museum"]
    distance_from_center_km: Mapped[float | None] = mapped_column(Float, nullable=True)
    wiki_url: Mapped[str | None] = mapped_column(String(400), nullable=True)
    website: Mapped[str | None] = mapped_column(String(400), nullable=True)
    source_name: Mapped[str] = mapped_column(String(80), default="OpenStreetMap Overpass")
    source_url: Mapped[str] = mapped_column(String(400), default="")
    retrieved_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
