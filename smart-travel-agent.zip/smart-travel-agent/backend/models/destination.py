"""Destinations discovered via Nominatim / Wikipedia / curated reference data."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import JSON, DateTime, Float, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from database.engine import Base
from models.user import utcnow


class Destination(Base):
    __tablename__ = "destinations"
    __table_args__ = (UniqueConstraint("name", "city", "state", name="uq_destination_place"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    city: Mapped[str] = mapped_column(String(120), index=True)
    state: Mapped[str] = mapped_column(String(120), default="")
    country: Mapped[str] = mapped_column(String(80), default="India")
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    tags: Mapped[list | None] = mapped_column(JSON, nullable=True)   # e.g. ["heritage","hill-station"]
    wiki_url: Mapped[str | None] = mapped_column(String(400), nullable=True)
    image_key: Mapped[str | None] = mapped_column(String(80), nullable=True)  # bundled asset key
    source_name: Mapped[str] = mapped_column(String(80), default="OpenStreetMap Nominatim")
    source_url: Mapped[str] = mapped_column(String(400), default="https://nominatim.openstreetmap.org")
    retrieved_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
