"""Hotels / accommodation collected from public OSM data (never fabricated)."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Float, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from database.engine import Base
from models.user import utcnow


class Hotel(Base):
    __tablename__ = "hotels"
    __table_args__ = (UniqueConstraint("name", "city", "lat", "lon", name="uq_hotel_place"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    plan_id: Mapped[int | None] = mapped_column(ForeignKey("travel_plans.id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(200), index=True)
    city: Mapped[str] = mapped_column(String(120), index=True)
    address: Mapped[str | None] = mapped_column(String(400), nullable=True)
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    category: Mapped[str | None] = mapped_column(String(40), nullable=True)   # hotel|guest_house|hostel|resort
    stars: Mapped[int | None] = mapped_column(Integer, nullable=True)         # only when tagged in OSM
    price_level: Mapped[int | None] = mapped_column(Integer, nullable=True)   # 1..4 only when tagged
    website: Mapped[str | None] = mapped_column(String(400), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(60), nullable=True)
    source_name: Mapped[str] = mapped_column(String(80), default="OpenStreetMap Overpass")
    source_url: Mapped[str] = mapped_column(String(400), default="")
    retrieved_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
