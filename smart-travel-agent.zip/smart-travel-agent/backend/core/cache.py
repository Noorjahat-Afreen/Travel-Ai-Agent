"""In-process TTL cache used to avoid unnecessary external API calls.

Respects provider usage policies (Nominatim / Overpass) by never repeating an
identical request inside the TTL window. Decorates async functions:

    @cached(ttl=3600, name="geocode")
    async def geocode_city(city: str) -> dict: ...
"""
from __future__ import annotations

import asyncio
import functools
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass
class _Entry:
    value: Any
    expires_at: float
    created_at: float = field(default_factory=time.time)


class TTLCache:
    """Small async-safe TTL cache with hit/miss statistics."""

    def __init__(self, max_entries: int = 512) -> None:
        self._store: dict[str, _Entry] = {}
        self._max_entries = max_entries
        self._lock = asyncio.Lock()
        self.hits = 0
        self.misses = 0

    async def get(self, key: str) -> Any | None:
        async with self._lock:
            entry = self._store.get(key)
            if entry is None:
                self.misses += 1
                return None
            if entry.expires_at < time.time():
                del self._store[key]
                self.misses += 1
                return None
            self.hits += 1
            return entry.value

    async def set(self, key: str, value: Any, ttl: int) -> None:
        async with self._lock:
            if len(self._store) >= self._max_entries:
                # Drop expired entries first, then the oldest ones.
                now = time.time()
                for k, e in list(self._store.items()):
                    if e.expires_at < now:
                        del self._store[k]
                while len(self._store) >= self._max_entries:
                    oldest = min(self._store.items(), key=lambda kv: kv[1].expires_at)
                    del self._store[oldest[0]]
            self._store[key] = _Entry(value=value, expires_at=time.time() + ttl)

    def stats(self) -> dict:
        return {"hits": self.hits, "misses": self.misses, "entries": len(self._store)}


cache = TTLCache()


def _make_key(name: str, args: tuple, kwargs: dict) -> str:
    payload = json.dumps({"a": args, "k": kwargs}, default=str, sort_keys=True)
    digest = hashlib.sha1(payload.encode()).hexdigest()[:16]
    return f"{name}:{digest}"


def cached(ttl: int | None = None, name: str | None = None) -> Callable:
    """Decorator: cache the (awaitable) result of an async function for `ttl` seconds."""

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            key = _make_key(name or func.__qualname__, args, kwargs)
            hit = await cache.get(key)
            if hit is not None:
                return hit
            value = await func(*args, **kwargs)
            await cache.set(key, value, ttl if ttl is not None else 3600)
            return value

        wrapper.cache_clear = cache._store.clear  # type: ignore[attr-defined]
        return wrapper

    return decorator
