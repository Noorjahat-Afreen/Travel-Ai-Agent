"""Central application configuration.

All secrets are read from environment variables (see .env.example).
Never hardcode API keys in source files.
"""
from __future__ import annotations

import os
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

# Project layout
BACKEND_DIR = Path(__file__).resolve().parent.parent          # backend/
PROJECT_DIR = BACKEND_DIR.parent                              # smart-travel-agent/
DATA_DIR = PROJECT_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
FRONTEND_DIST_DIR = PROJECT_DIR / "frontend" / "dist"


class Settings(BaseSettings):
    """Environment-driven settings (loaded from backend/.env when present)."""

    model_config = SettingsConfigDict(
        env_file=(BACKEND_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- Application ---
    app_name: str = "AI Smart Travel Agent - India"
    app_version: str = "1.0.0"
    env: str = "dev"
    api_port: int = 8000
    log_level: str = "INFO"

    # --- Security ---
    # Comma separated list of allowed browser origins ("*" for local development).
    cors_origins: str = "http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000,http://127.0.0.1:3000"
    # Simple per-IP rate limit (requests per minute).
    rate_limit_rpm: int = 120

    # --- AI (Google Gemini via LangChain) ---
    # Set GEMINI_API_KEY in backend/.env. The application degrades gracefully
    # to "local intelligence mode" when the key is missing.
    gemini_api_key: str = ""
    gemini_model: str = "gemini-2.0-flash"
    gemini_temperature: float = 0.3
    llm_timeout_seconds: int = 45

    # --- Database ---
    # SQLite for local development; switch to postgresql+psycopg:// for deployment.
    db_url: str = f"sqlite:///{DATA_DIR / 'travel_agent.db'}"

    # --- External APIs ---
    request_timeout: int = 20
    request_retries: int = 2
    user_agent: str = (
        "SmartTravelAgent-India/1.0 (B.Tech CSE-AIML major project; "
        "educational use; respects OSM Nominatim & Overpass usage policies)"
    )
    # Nominatim public API policy: max 1 request/second with a descriptive UA.
    nominatim_min_interval: float = 1.1
    overpass_mirrors: str = (
        "https://maps.mail.ru/osm/tools/overpass/api/interpreter,"
        "https://overpass-api.de/api/interpreter,"
        "https://overpass.private.coffee/api/interpreter"
    )

    # --- Domain tuning ---
    poi_radius_km: float = 12.0
    poi_limit: int = 30
    max_trip_days: int = 30
    # Open-Meteo free forecast horizon (days ahead available from today).
    forecast_horizon_days: int = 16
    cache_ttl_seconds: int = 3600
    weather_cache_ttl_seconds: int = 1800

    @property
    def cors_origin_list(self) -> list[str]:
        raw = self.cors_origins.strip()
        if raw == "*":
            return ["*"]
        return [o.strip() for o in raw.split(",") if o.strip()]

    @property
    def overpass_mirror_list(self) -> list[str]:
        return [m.strip() for m in self.overpass_mirrors.split(",") if m.strip()]


settings = Settings()

# Fail-safe default: if a key is smuggled via process env (e.g. CI), honour it.
if not settings.gemini_api_key and os.environ.get("GEMINI_API_KEY"):
    settings.gemini_api_key = os.environ["GEMINI_API_KEY"]
