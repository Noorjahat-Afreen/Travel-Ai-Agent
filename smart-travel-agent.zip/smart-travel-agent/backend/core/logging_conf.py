"""Application logging configuration.

Logs must never contain API keys, tokens or other secrets. External service
responses are logged at DEBUG level with truncation.
"""
from __future__ import annotations

import logging
import sys

from core.config import settings

_CONFIGURED = False

# Field names that must never be written to logs even if present in payloads.
REDACTED_FIELDS = {"api_key", "key", "token", "password", "authorization", "secret"}


def configure_logging() -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(settings.log_level)
    # Quieten noisy third-party loggers.
    for noisy in ("httpx", "httpcore", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    _CONFIGURED = True


def redact(payload: dict | None) -> dict:
    """Return a copy of a dict with secret-looking keys removed."""
    if not payload:
        return {}
    return {k: ("***" if k.lower() in REDACTED_FIELDS else v) for k, v in payload.items()}
