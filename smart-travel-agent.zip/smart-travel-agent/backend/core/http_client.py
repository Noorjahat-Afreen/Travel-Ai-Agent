"""Shared async HTTP client for all external API integrations.

Provides timeouts, bounded retries and consistent User-Agent headers, as
required by Nominatim / Overpass / Wikipedia usage policies.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

import httpx

from core.config import settings
from core.logging_conf import redact

logger = logging.getLogger(__name__)


class ExternalAPIError(RuntimeError):
    """Raised when an external provider fails after retries."""

    def __init__(self, provider: str, detail: str) -> None:
        self.provider = provider
        self.detail = detail
        super().__init__(f"{provider} request failed: {detail}")


_client: httpx.AsyncClient | None = None
_client_loop_id: int | None = None


def get_client() -> httpx.AsyncClient:
    """Return the shared client, recreating it when the event loop changed.

    Async clients are bound to the loop that created them; test harnesses and
    scripts may use several loops, so we detect a loop switch and rebuild.
    """
    global _client, _client_loop_id
    loop = asyncio.get_running_loop()
    loop_id = id(loop)
    if _client is not None and _client_loop_id != loop_id:
        _client = None  # loop changed: the old client's connections are unusable
    if _client is None or _client.is_closed:
        _client = httpx.AsyncClient(
            timeout=httpx.Timeout(settings.request_timeout, connect=8.0),
            headers={"User-Agent": settings.user_agent, "Accept-Language": "en"},
            follow_redirects=True,
        )
        _client_loop_id = loop_id
    return _client


async def close_client() -> None:
    global _client, _client_loop_id
    if _client is not None and not _client.is_closed:
        try:
            await _client.aclose()
        except Exception:  # noqa: BLE001
            pass
    _client = None
    _client_loop_id = None


async def request_json(
    provider: str,
    method: str,
    url: str,
    *,
    params: dict | None = None,
    data: dict | None = None,
    headers: dict | None = None,
    retries: int | None = None,
    timeout: int | None = None,
) -> Any:
    """Perform an HTTP request and parse a JSON body, with retries and logging.

    Raises ExternalAPIError after exhausting attempts. Never logs secrets.
    """
    attempts = retries if retries is not None else settings.request_retries
    attempt = 0
    last_error: str = ""
    while attempt <= attempts:
        attempt += 1
        try:
            response = await get_client().request(
                method,
                url,
                params=params,
                data=data,
                headers=headers,
                timeout=timeout or settings.request_timeout,
            )
            if response.status_code in (429, 502, 503, 504):
                last_error = f"HTTP {response.status_code} (rate limited or upstream busy)"
                logger.warning("[%s] %s - retrying (%d/%d)", provider, last_error, attempt, attempts + 1)
                await asyncio.sleep(min(2 ** attempt, 6))
                continue
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as exc:
            last_error = f"HTTP {exc.response.status_code}: {exc.response.text[:120]}"
            # Non-retryable client error (except 429 handled above) - fail fast.
            if exc.response.status_code < 500 and exc.response.status_code != 429:
                break
        except (httpx.TimeoutException, httpx.TransportError) as exc:
            last_error = f"{type(exc).__name__}: {str(exc)[:120]}"
        except ValueError as exc:
            last_error = f"invalid JSON response: {str(exc)[:120]}"
            break
        await asyncio.sleep(min(2 ** attempt, 6))
    logger.error("[%s] giving up after %d attempt(s): %s | params=%s",
                 provider, attempt, last_error, redact(params))
    raise ExternalAPIError(provider, last_error)
