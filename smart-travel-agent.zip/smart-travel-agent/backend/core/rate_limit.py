"""Lightweight per-IP token-bucket rate limiter (FastAPI middleware).

Protects the backend from abusive request volume without external
infrastructure. Returns HTTP 429 with a Retry-After header when exceeded.
"""
from __future__ import annotations

import time
from collections import defaultdict

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from core.config import settings

_BUCKETS: dict[str, dict] = defaultdict(dict)


def check_rate_limit(client_ip: str, rpm: int | None = None, *, now: float | None = None) -> bool:
    """Token-bucket check. Returns True if the request is ALLOWED.

    Exposed as a pure function so it can be unit tested deterministically.
    """
    rpm = rpm or settings.rate_limit_rpm
    current = now if now is not None else time.time()
    bucket = _BUCKETS[client_ip]
    window_start = bucket.get("window_start", current)
    count = bucket.get("count", 0)
    if current - window_start >= 60:
        window_start, count = current, 0
    count += 1
    bucket.update(window_start=window_start, count=count)
    return count <= rpm


class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, rpm: int | None = None) -> None:  # type: ignore[no-untyped-def]
        super().__init__(app)
        self.rpm = rpm or settings.rate_limit_rpm

    async def dispatch(self, request: Request, call_next):  # type: ignore[no-untyped-def]
        client_ip = request.client.host if request.client else "unknown"
        if not check_rate_limit(client_ip, self.rpm):
            return JSONResponse(
                status_code=429,
                content={"detail": "Too many requests. Please retry in a moment."},
                headers={"Retry-After": "60"},
            )
        return await call_next(request)


def reset_rate_limiter() -> None:
    _BUCKETS.clear()
