"""Retrieval-Augmented Generation over collected destination knowledge.

Lightweight SQLite-backed retrieval:
- Documents (destination facts + Wikipedia summaries) live in rag_documents.
- Ranking uses BM25 implemented in pure Python (no heavy infrastructure).
- Dense embeddings are used ONLY if an optional local model
  (sentence-transformers) is importable - never a remote embedding API.

Generated answers must cite the metadata (title/source) of retrieved docs;
see agents/ for usage.
"""
from __future__ import annotations

import json
import logging
import math
import re
from collections import Counter

from sqlalchemy.orm import Session

from database.engine import SessionLocal
from models import RAGDocument

logger = logging.getLogger(__name__)

_TOKEN_RE = re.compile(r"[a-z0-9]+")

# Optional dense-embedding support (guarded import; absent by default).
try:  # pragma: no cover - depends on optional package
    from sentence_transformers import SentenceTransformer  # type: ignore

    _EMBEDDER: SentenceTransformer | None = None  # lazily initialised
    EMBEDDINGS_AVAILABLE = True
except Exception:  # noqa: BLE001
    EMBEDDINGS_AVAILABLE = False


def slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


# ----------------------------------------------------------------- ingestion
def ingest_curated_destinations(db: Session | None = None) -> int:
    """Index curated destination facts into rag_documents (idempotent)."""
    from services import india_reference

    own = False
    if db is None:
        db, own = SessionLocal(), True
    added = 0
    try:
        for item in india_reference.CURATED_DESTINATIONS:
            ref = slug(f"{item['name']} {item['city']}")
            exists = db.query(RAGDocument).filter(RAGDocument.ref_id == ref).first()
            if exists:
                continue
            content = (
                f"{item['name']} is in {item['city']}, {item['state']}, India. "
                f"{item['blurb']} Category: {item['category']}. Tags: {', '.join(item.get('tags', []))}."
            )
            db.add(
                RAGDocument(
                    doc_type="destination",
                    ref_id=ref,
                    title=f"{item['name']} ({item['city']}, {item['state']})",
                    content=content,
                    meta={
                        "lat": item["lat"],
                        "lon": item["lon"],
                        "city": item["city"],
                        "state": item["state"],
                        "category": item["category"],
                        "wiki_url": india_reference.WIKI + item.get("wiki", item["name"].replace(" ", "_")),
                        "image_key": item.get("image_key", ""),
                        "source": "Curated reference data + Wikipedia link",
                    },
                )
            )
            added += 1
        db.commit()
    finally:
        if own:
            db.close()
    return added


def ingest_wiki_summary(db: Session, ref: str, title: str, extract: str, url: str, extra_meta: dict | None = None) -> None:
    """Attach a Wikipedia summary as an additional (higher-authority) document."""
    ref = slug(ref)
    existing = db.query(RAGDocument).filter(RAGDocument.ref_id == ref, RAGDocument.doc_type == "wiki").first()
    if existing:
        existing.content = f"{title}: {extract[:1200]}"
        return
    db.add(
        RAGDocument(
            doc_type="wiki",
            ref_id=ref,
            title=title,
            content=f"{title}: {extract[:1200]}",
            meta={"wiki_url": url, "source": "Wikipedia (CC BY-SA)", **(extra_meta or {})},
        )
    )
    db.commit()


# ----------------------------------------------------------------- retrieval
def _tokenize(text: str) -> list[str]:
    return _TOKEN_RE.findall(text.lower())


class _BM25Index:
    """Minimal BM25 (Okapi) implementation over in-memory document tokens."""

    def __init__(self, docs: list[dict]) -> None:
        self.docs = docs
        self.doc_tokens = [_tokenize(f"{d['title']} {d['content']}") for d in docs]
        self.doc_len = [len(t) for t in self.doc_tokens]
        self.n = len(docs)
        self.avg_len = (sum(self.doc_len) / self.n) if self.n else 0.0
        self.k1, self.b = 1.5, 0.75
        df: Counter = Counter()
        for tokens in self.doc_tokens:
            df.update(set(tokens))
        self.idf = {
            term: math.log((self.n - f + 0.5) / (f + 0.5) + 1.0) for term, f in df.items()
        }

    def search(self, query: str, k: int = 5) -> list[dict]:
        if not self.n:
            return []
        q_tokens = _tokenize(query)
        scores: list[float] = []
        for tokens, dl in zip(self.doc_tokens, self.doc_len):
            score = 0.0
            counts = Counter(tokens)
            for term in q_tokens:
                if term not in counts:
                    continue
                tf = counts[term]
                idf = self.idf.get(term, 0.0)
                denom = tf + self.k1 * (1 - self.b + self.b * dl / (self.avg_len or 1.0))
                score += idf * (tf * (self.k1 + 1)) / denom
            scores.append(score)
        ranked = sorted(zip(self.docs, scores), key=lambda p: p[1], reverse=True)
        return [doc for doc, s in ranked[:k] if s > 0]

    def embed_search(self, query: str, k: int = 5) -> list[dict]:  # pragma: no cover
        global _EMBEDDER
        if not EMBEDDINGS_AVAILABLE:
            return []
        if _EMBEDDER is None:
            _EMBEDDER = SentenceTransformer("all-MiniLM-L6-v2")
        import numpy as np

        doc_vecs = _EMBEDDER.encode([d["content"] for d in self.docs], normalize_embeddings=True)
        q_vec = _EMBEDDER.encode([query], normalize_embeddings=True)[0]
        sims = np.asarray(doc_vecs) @ np.asarray(q_vec)
        order = sims.argsort()[::-1][:k]
        return [self.docs[i] for i in order if sims[i] > 0.05]


_corpus_cache: dict[str, tuple[int, _BM25Index]] = {"": (0, None)}  # type: ignore[assignment]


def _load_corpus(db: Session) -> _BM25Index:
    rows = db.query(RAGDocument).all()
    docs = [
        {
            "id": r.id,
            "ref": r.ref_id,
            "title": r.title,
            "content": r.content,
            "doc_type": r.doc_type,
            "meta": r.meta or {},
        }
        for r in rows
    ]
    return _BM25Index(docs)


def retrieve(query: str, k: int = 5, db: Session | None = None) -> list[dict]:
    """Retrieve the top-k relevant documents for a query (BM25; embeddings when available)."""
    own = False
    if db is None:
        db, own = SessionLocal(), True
    try:
        count = db.query(RAGDocument).count()
        cached_entry = _corpus_cache.get("idx")
        if cached_entry is None or cached_entry[0] != count:
            index = _load_corpus(db)
            _corpus_cache["idx"] = (count, index)
        else:
            index = cached_entry[1]
        if index.n == 0:
            return []
        if EMBEDDINGS_AVAILABLE:
            try:  # pragma: no cover
                embedded = index.embed_search(query, k=k)
                if embedded:
                    return embedded
            except Exception as exc:  # noqa: BLE001
                logger.warning("embedding retrieval failed, using BM25: %s", exc)
        return index.search(query, k=k)
    finally:
        if own:
            db.close()


def context_for_answer(query: str, k: int = 4) -> str:
    """Render retrieved documents as a citation-ready context block."""
    docs = retrieve(query, k=k)
    if not docs:
        return ""
    lines = []
    for d in docs:
        url = (d.get("meta") or {}).get("wiki_url", "")
        lines.append(f"- [{d['title']}] {d['content'][:300]}{' Source: ' + url if url else ''}")
    return "\n".join(lines)


def doc_count(db: Session | None = None) -> int:
    own = False
    if db is None:
        db, own = SessionLocal(), True
    try:
        return db.query(RAGDocument).count()
    finally:
        if own:
            db.close()
