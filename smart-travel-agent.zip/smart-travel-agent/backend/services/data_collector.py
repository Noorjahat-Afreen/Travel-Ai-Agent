"""Central data collection service.

Normalises provider payloads (Overpass / Photon / Nominatim / Wikipedia /
Open-Meteo) into one consistent format, attaches source attribution and
retrieval timestamps, and persists records to the database with de-duplication.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timezone

from sqlalchemy.orm import Session

from core.config import settings
from models import Attraction, DataSource, Destination, Hotel, Restaurant, TransportOption, WeatherRecord
from schemas.common import BookingLink, PlaceRecord, SourceInfo
from schemas.trip import TransportOptionOut
from services import booking_links, osrm

logger = logging.getLogger(__name__)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _addr(tags: dict) -> str | None:
    parts = [
        tags.get("addr:housenumber", ""),
        tags.get("addr:street", ""),
        tags.get("addr:suburb", ""),
        tags.get("addr:city", tags.get("addr:town", "")),
        tags.get("addr:postcode", ""),
    ]
    addr = ", ".join(p.strip() for p in parts if p and p.strip())
    return addr or None


def element_to_place(
    element: dict,
    category: str,
    city: str,
    provider: str,
    center_lat: float | None = None,
    center_lon: float | None = None,
) -> PlaceRecord | None:
    """Convert a raw Overpass/Photon element into a normalised PlaceRecord."""
    tags = element.get("tags") or {}
    name = tags.get("name") or tags.get("name:en")
    if not name:
        return None
    lat = element.get("lat") or (element.get("center") or {}).get("lat")
    lon = element.get("lon") or (element.get("center") or {}).get("lon")
    if lat is None or lon is None:
        return None

    osm_value = tags.get("osm_value") or (
        tags.get("tourism") or tags.get("amenity") or tags.get("historic") or category
    )
    distance = None
    if center_lat is not None and center_lon is not None:
        distance = osrm.haversine_km(center_lat, center_lon, float(lat), float(lon))

    veg: bool | None = None
    diet = tags.get("diet:vegetarian")
    if diet == "only":
        veg = True
    elif diet in ("yes", "no"):
        veg = diet == "yes"

    stars = None
    if tags.get("stars", "").isdigit():
        stars = min(int(tags["stars"]), 5)
    price_level = None
    if tags.get("price_level", "").isdigit():
        price_level = min(int(tags["price_level"]), 4)

    website = tags.get("website") or tags.get("contact:website") or tags.get("url")
    if website and not website.startswith("http"):
        website = "https://" + website

    types: list[str] = [t for t in (tags.get("tourism"), tags.get("historic"), tags.get("amenity")) if t]

    rec = PlaceRecord(
        name=name.strip(),
        category=str(osm_value) if osm_value else category,
        lat=float(lat),
        lon=float(lon),
        city=tags.get("addr:city") or city,
        address=_addr(tags),
        cuisine=tags.get("cuisine"),
        vegetarian=veg,
        website=website,
        phone=tags.get("phone") or tags.get("contact:phone"),
        price_level=price_level,
        stars=stars,
        types=types,
        distance_km=distance,
        source=SourceInfo(name=provider, url="https://www.openstreetmap.org", retrieved_at=_utcnow()),
    )
    return _attach_links(rec, city)


def _attach_links(rec: PlaceRecord, city: str) -> PlaceRecord:
    rec.map_link = booking_links.osm_link(rec.lat, rec.lon).url
    if rec.category in ("hotel", "guest_house", "hostel", "resort", "apartment", "motel"):
        from datetime import date as _date, timedelta as _timedelta

        tomorrow = _date.today() + _timedelta(days=1)
        day_after = _date.today() + _timedelta(days=2)
        rec.booking_links = booking_links.hotel_links(rec.city or city, tomorrow, day_after, 2)[:1]
        if rec.website:
            rec.booking_links.append(
                BookingLink(label="Hotel website", url=rec.website, provider="Website", kind="website")
            )
    elif rec.category in ("restaurant", "cafe", "fast_food", "food_court"):
        rec.booking_links = [booking_links.restaurant_explore_link(rec.name, rec.city or city)]
        if rec.website:
            rec.booking_links.append(
                BookingLink(label="Website", url=rec.website, provider="Website", kind="website")
            )
    else:
        rec.booking_links = [booking_links.attraction_search_link(rec.name, rec.city or city)]
    rec.directions_link = booking_links.directions_link(rec.lat, rec.lon, city).url
    return rec


def normalise_elements(
    elements: list[dict],
    category: str,
    city: str,
    provider: str,
    center: tuple[float, float] | None = None,
) -> list[PlaceRecord]:
    seen: set[tuple] = set()
    records: list[PlaceRecord] = []
    for el in elements:
        rec = element_to_place(el, category, city, provider, *(center or (None, None)))
        if rec is None:
            continue
        key = (rec.name.lower(), round(rec.lat, 3), round(rec.lon, 3))
        if key in seen:
            continue
        seen.add(key)
        records.append(rec)
    records.sort(key=lambda r: (r.distance_km is None, r.distance_km or 0))
    return records[: settings.poi_limit]


# ------------------------------------------------------------------ persistence
def upsert_hotels(db: Session, plan_id: int | None, city: str, records: list[PlaceRecord]) -> list[PlaceRecord]:
    from sqlalchemy.exc import IntegrityError

    for r in records:
        exists = (
            db.query(Hotel)
            .filter(Hotel.name == r.name, Hotel.city == city, Hotel.lat == r.lat, Hotel.lon == r.lon)
            .first()
        )
        if exists:
            if plan_id and exists.plan_id is None:
                exists.plan_id = plan_id
            continue
        try:
            db.add(
                Hotel(
                    plan_id=plan_id,
                    name=r.name,
                    city=city,
                    address=r.address,
                    lat=r.lat,
                    lon=r.lon,
                    category=r.category,
                    stars=r.stars,
                    price_level=r.price_level,
                    website=r.website,
                    phone=r.phone,
                    source_name=r.source.name,
                    source_url=r.source.url,
                )
            )
            db.flush()
        except IntegrityError:
            db.rollback()
    db.commit()
    return records


def upsert_restaurants(db: Session, plan_id: int | None, city: str, records: list[PlaceRecord]) -> list[PlaceRecord]:
    from sqlalchemy.exc import IntegrityError

    for r in records:
        exists = (
            db.query(Restaurant)
            .filter(Restaurant.name == r.name, Restaurant.city == city, Restaurant.lat == r.lat)
            .first()
        )
        if exists:
            continue
        try:
            db.add(
                Restaurant(
                    plan_id=plan_id,
                    name=r.name,
                    city=city,
                    cuisine=r.cuisine,
                    address=r.address,
                    lat=r.lat,
                    lon=r.lon,
                    website=r.website,
                    phone=r.phone,
                    vegetarian=r.vegetarian,
                    kind=r.category if r.category in ("restaurant", "cafe", "fast_food") else "restaurant",
                    source_name=r.source.name,
                    source_url=r.source.url,
                )
            )
            db.flush()
        except IntegrityError:
            db.rollback()
    db.commit()
    return records


def upsert_attractions(db: Session, plan_id: int | None, city: str, records: list[PlaceRecord]) -> list[PlaceRecord]:
    from sqlalchemy.exc import IntegrityError

    for r in records:
        exists = (
            db.query(Attraction)
            .filter(Attraction.name == r.name, Attraction.city == city, Attraction.lat == r.lat)
            .first()
        )
        if exists:
            continue
        try:
            db.add(
                Attraction(
                    plan_id=plan_id,
                    name=r.name,
                    city=city,
                    description=r.description,
                    lat=r.lat,
                    lon=r.lon,
                    types=r.types,
                    distance_from_center_km=r.distance_km,
                    website=r.website,
                    source_name=r.source.name,
                    source_url=r.source.url,
                )
            )
            db.flush()
        except IntegrityError:
            db.rollback()
    db.commit()
    return records


def save_destination(db: Session, info: dict) -> Destination | None:
    if not info.get("name"):
        return None
    existing = (
        db.query(Destination)
        .filter(Destination.name == info["name"], Destination.city == info.get("city", info["name"]))
        .first()
    )
    if existing:
        return existing
    row = Destination(
        name=info["name"],
        city=info.get("city", info["name"]),
        state=info.get("state", ""),
        lat=info["lat"],
        lon=info["lon"],
        description=info.get("description"),
        tags=info.get("tags"),
        wiki_url=info.get("wiki_url"),
        source_name=info.get("source_name", "OpenStreetMap Nominatim"),
        source_url=info.get("source_url", "https://nominatim.openstreetmap.org"),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


def save_weather(db: Session, plan_id: int | None, city: str, lat: float, lon: float, days: list[dict]) -> int:
    saved = 0
    for d in days:
        exists = (
            db.query(WeatherRecord)
            .filter(WeatherRecord.city == city, WeatherRecord.forecast_date == date.fromisoformat(d["date"]))
            .first()
        )
        if exists:
            continue
        db.add(
            WeatherRecord(
                plan_id=plan_id,
                city=city,
                lat=lat,
                lon=lon,
                forecast_date=date.fromisoformat(d["date"]),
                temp_min_c=d.get("temp_min_c"),
                temp_max_c=d.get("temp_max_c"),
                precipitation_probability=d.get("precipitation_probability"),
                precipitation_mm=d.get("precipitation_mm"),
                condition=d.get("condition", ""),
                source_name=d.get("source_name", "Open-Meteo"),
                source_url=d.get("source_url", "https://open-meteo.com"),
            )
        )
        saved += 1
    db.commit()
    return saved


def save_transport_options(db: Session, plan_id: int | None, options: list[TransportOptionOut]) -> None:
    for o in options:
        db.add(
            TransportOption(
                plan_id=plan_id,
                mode=o.mode,
                provider=o.provider,
                summary=o.summary,
                detail=o.detail,
                deep_link=o.deep_link,
                origin_city=o.origin_city,
                destination_city=o.destination_city,
                travel_date=o.travel_date,
                is_estimate=o.is_estimate,
                estimated_cost_inr=o.estimated_cost_inr,
                notes=o.notes,
                source_name=o.source.name,
                source_url=o.source.url,
            )
        )
    db.commit()


def mark_provider(db: Session, name: str, ok: bool) -> None:
    row = db.query(DataSource).filter(DataSource.name == name).first()
    if row:
        row.last_used_at = _utcnow()
        row.status = "active" if ok else "degraded"
        db.commit()
