"""Google Gemini integration via LangChain.

Security: GEMINI_API_KEY is read from backend/.env only. It is never exposed
to the React frontend and never written to logs or the database.

Graceful degradation: when the key is missing/invalid the platform switches to
"local intelligence mode" - deterministic agents built on real collected data
with clearly labelled AI-unavailable notices (see agents/base.py).
"""
from __future__ import annotations

import base64
import logging
from functools import lru_cache

from services.rag import context_for_answer

logger = logging.getLogger(__name__)


@lru_cache(maxsize=1)
def get_chat_model():
    """Return a LangChain ChatGoogleGenerativeAI model, or None when unavailable."""
    from core.config import settings

    if not settings.gemini_api_key:
        logger.info("GEMINI_API_KEY not set - running in local intelligence mode")
        return None
    try:
        from langchain_google_genai import ChatGoogleGenerativeAI

        return ChatGoogleGenerativeAI(
            model=settings.gemini_model,
            google_api_key=settings.gemini_api_key,
            temperature=settings.gemini_temperature,
            timeout=settings.llm_timeout_seconds,
            max_retries=1,
        )
    except Exception as exc:  # noqa: BLE001
        logger.error("failed to initialise Gemini model: %s", type(exc).__name__)
        return None


def llm_status() -> dict:
    model = get_chat_model()
    from core.config import settings

    return {
        "available": model is not None,
        "mode": "gemini" if model else "local",
        "model": settings.gemini_model if model else "",
        "note": (
            "Google Gemini is active (key present in backend environment)."
            if model
            else "AI model offline: set GEMINI_API_KEY in backend/.env to enable Gemini features. "
            "The app currently uses deterministic local intelligence over real collected data."
        ),
    }


async def structured_output(schema, prompt: str, *, system: str | None = None):
    """Ask Gemini for a validated Pydantic object. Returns None when unavailable/failed."""
    model = get_chat_model()
    if model is None:
        return None
    try:
        bound = model.with_structured_output(schema)
        messages = []
        if system:
            from langchain_core.messages import SystemMessage

            messages.append(SystemMessage(content=system))
        from langchain_core.messages import HumanMessage

        messages.append(HumanMessage(content=prompt))
        return await bound.ainvoke(messages)
    except Exception as exc:  # noqa: BLE001
        logger.warning("structured_output failed (%s): %s", type(exc).__name__, str(exc)[:160])
        return None


async def chat_text(prompt: str, *, system: str | None = None, history: list | None = None) -> str | None:
    """Free-form chat completion. Returns None when unavailable/failed."""
    model = get_chat_model()
    if model is None:
        return None
    try:
        from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

        messages: list = []
        if system:
            messages.append(SystemMessage(content=system))
        for h in history or []:
            role = h.get("role")
            content = h.get("content", "")
            if role == "user":
                messages.append(HumanMessage(content=content))
            elif role == "assistant":
                messages.append(AIMessage(content=content))
        messages.append(HumanMessage(content=prompt))
        response = await model.ainvoke(messages)
        return getattr(response, "content", None) or None
    except Exception as exc:  # noqa: BLE001
        logger.warning("chat_text failed (%s): %s", type(exc).__name__, str(exc)[:160])
        return None


RAG_SYSTEM_SUFFIX = (
    "You may use the following RETRIEVED CONTEXT from our collected database. "
    "Cite document titles you used. If the context does not contain the answer, "
    "say 'details unavailable in collected data' instead of inventing facts.\n\n"
)


async def chat_text_with_rag(prompt: str, retrieval_query: str | None = None, *, system: str | None = None) -> str | None:
    """Chat completion grounded with BM25-retrieved destination documents."""
    query = retrieval_query or prompt
    context = context_for_answer(query)
    sys_prompt = (system or "") + ("\n\n" + RAG_SYSTEM_SUFFIX + context if context else "")
    return await chat_text(prompt, system=sys_prompt)


async def identify_landmark(image_bytes: bytes, mime_type: str, hints: str = ""):
    """Vision call: ask Gemini to identify a landmark, or admit uncertainty.

    Returns a dict (landmark, city, state, country, confidence, rationale)
    or None when the model is unavailable/failed.
    """
    model = get_chat_model()
    if model is None:
        return None
    try:
        from langchain_core.messages import HumanMessage

        b64 = base64.b64encode(image_bytes).decode()
        prompt = (
            "You are a landmark recognition expert for India. Identify the landmark in this photograph. "
            "Respond with JSON having keys: landmark (string), city (string), state (string), "
            "country (string), confidence (0..1 float), rationale (one sentence). "
            "If you are NOT confident it is a specific famous landmark, set landmark='' and "
            f"confidence below 0.3. {hints}"
        )
        message = HumanMessage(
            content=[
                {"type": "text", "text": prompt},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:{mime_type};base64,{b64}"},
                },
            ]
        )
        response = await model.ainvoke([message])
        import json as _json
        import re as _re

        raw = getattr(response, "content", "")
        if isinstance(raw, list):  # some providers return blocks
            raw = "".join(str(part) for part in raw)
        match = _re.search(r"\{.*\}", str(raw), _re.DOTALL)
        if not match:
            return None
        data = _json.loads(match.group(0))
        data["confidence"] = float(data.get("confidence", 0.0))
        return data
    except Exception as exc:  # noqa: BLE001
        logger.warning("identify_landmark failed (%s): %s", type(exc).__name__, str(exc)[:160])
        return None
