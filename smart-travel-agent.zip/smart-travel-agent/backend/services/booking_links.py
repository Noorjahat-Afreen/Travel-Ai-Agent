"""External booking / search deep links for legitimate providers.

Rules honoured here:
- Only documented public URL formats of the providers are used.
- We NEVER invent fares, availability or inventory.
- The app never claims a booking happened; links open the provider website
  in a new tab where the user books directly.
"""
from __future__ import annotations

from datetime import date
from urllib.parse import quote

from schemas.common import BookingLink
from services import india_reference

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def _redbus_date(d: date) -> str:
    return f"{d.strftime('%d')}-{MONTHS[d.month - 1]}-{d.year}"


# ---------------------------------------------------------------- transport
def train_links(origin_city: str, dest_city: str, travel_date: date) -> list[BookingLink]:
    o = india_reference.station_code(origin_city)
    d = india_reference.station_code(dest_city)
    links: list[BookingLink] = []
    if o and d:
        links.append(
            BookingLink(
                label="Search Train Tickets",
                url=(
                    "https://www.irctc.co.in/nget/train-search?"
                    f"journeyDate={travel_date.isoformat()}&fromStation={o}&toStation={d}"
                ),
                provider="IRCTC (Indian Railways)",
                kind="train",
            )
        )
        links.append(
            BookingLink(
                label=f"Train route {o} → {d} info",
                url=f"https://erail.in/trains-between-stations/{o}-{origin_city.upper().replace(' ', '-')}/{d}-{dest_city.upper().replace(' ', '-')}",
                provider="erail.in (schedule info)",
                kind="info",
            )
        )
    else:
        links.append(
            BookingLink(
                label="Search Train Tickets (choose stations on site)",
                url="https://www.irctc.co.in/nget/train-search",
                provider="IRCTC (Indian Railways)",
                kind="train",
            )
        )
    return links


def bus_links(origin_city: str, dest_city: str, travel_date: date) -> list[BookingLink]:
    return [
        BookingLink(
            label="Book Bus Now",
            url=(
                "https://www.redbus.in/search?"
                f"fromCityName={quote(origin_city)}&toCityName={quote(dest_city)}"
                f"&onward={_redbus_date(travel_date)}"
            ),
            provider="redBus",
            kind="bus",
        ),
        BookingLink(
            label="State & private bus operators",
            url=f"https://www.google.com/search?q={quote('bus booking ' + origin_city + ' to ' + dest_city)}",
            provider="Google Search",
            kind="info",
        ),
    ]


def flight_links(origin_city: str, dest_city: str, travel_date: date, travellers: int = 1) -> list[BookingLink]:
    o_code = india_reference.airport_code(origin_city)
    d_code = india_reference.airport_code(dest_city)
    links = [
        BookingLink(
            label="Search Flights",
            url=(
                "https://www.google.com/travel/flights?q="
                + quote(f"flights from {origin_city} to {dest_city} on {travel_date.isoformat()}")
                + "&curr=INR"
            ),
            provider="Google Flights",
            kind="flight",
        )
    ]
    if o_code and d_code:
        links.append(
            BookingLink(
                label=f"Search {o_code} → {d_code} flights",
                url=(
                    "https://www.makemytrip.com/flight/search?itinerary="
                    f"{o_code}-{d_code}-{travel_date.strftime('%d/%m/%Y')}&tripType=O&pClass=E&adults={travellers}"
                ),
                provider="MakeMyTrip",
                kind="flight",
            )
        )
        links.append(
            BookingLink(
                label="Airline & fare comparison",
                url=f"https://www.skyscanner.co.in/transport/flights/{o_code.lower()}/{d_code.lower()}/{travel_date.strftime('%y%m%d')}/",
                provider="Skyscanner India",
                kind="flight",
            )
        )
    return links


def car_links(origin_city: str, dest_city: str) -> list[BookingLink]:
    return [
        BookingLink(
            label="Get Driving Directions",
            url=(
                "https://www.google.com/maps/dir/?api=1&origin="
                f"{quote(f'{origin_city},India')}&destination={quote(f'{dest_city},India')}&travelmode=driving"
            ),
            provider="Google Maps",
            kind="car",
        ),
        BookingLink(
            label="Self-drive car rentals",
            url=f"https://www.google.com/search?q={quote('self drive car rental ' + origin_city)}",
            provider="Google Search",
            kind="info",
        ),
    ]


# ---------------------------------------------------------------- hotels
def hotel_links(city: str, check_in: date, check_out: date, guests: int) -> list[BookingLink]:
    return [
        BookingLink(
            label="Book Hotel Now",
            url=(
                "https://www.booking.com/searchresults.html?ss=" + quote(city)
                + f"&checkin={check_in.isoformat()}&checkout={check_out.isoformat()}"
                + f"&group_adults={max(guests, 1)}&no_rooms=1&lang=en-us"
            ),
            provider="Booking.com",
            kind="hotel",
        ),
        BookingLink(
            label="Hotels on MakeMyTrip",
            url=f"https://www.makemytrip.com/hotels/hotel-listing/?searchText={quote(city)}",
            provider="MakeMyTrip",
            kind="hotel",
        ),
        BookingLink(
            label="View hotels on map",
            url=f"https://www.google.com/maps/search/{quote('hotels in ' + city)}",
            provider="Google Maps",
            kind="map",
        ),
    ]


# ---------------------------------------------------------------- places
def restaurant_explore_link(name: str, city: str) -> BookingLink:
    q = f"{name} restaurant {city}" if name else f"restaurants in {city}"
    return BookingLink(
        label="Explore Restaurant",
        url=f"https://www.google.com/maps/search/?api=1&query={quote(q)}",
        provider="Google Maps",
        kind="map",
    )


def directions_link(lat: float, lon: float, origin: str | None = None) -> BookingLink:
    url = f"https://www.google.com/maps/dir/?api=1&destination={lat},{lon}"
    if origin:
        url += f"&origin={quote(f'{origin},India')}"
    return BookingLink(label="Get Directions", url=url, provider="Google Maps", kind="map")


def osm_link(lat: float, lon: float) -> BookingLink:
    return BookingLink(
        label="Open on OpenStreetMap",
        url=f"https://www.openstreetmap.org/?mlat={lat}&mlon={lon}#map=17/{lat}/{lon}",
        provider="OpenStreetMap",
        kind="map",
    )


def wiki_search_link(topic: str) -> BookingLink:
    return BookingLink(
        label="Read on Wikipedia",
        url=f"https://en.wikipedia.org/wiki/Special:Search?search={quote(topic)}",
        provider="Wikipedia",
        kind="info",
    )


def attraction_search_link(name: str, city: str) -> BookingLink:
    return BookingLink(
        label="Find on Map",
        url=f"https://www.google.com/maps/search/?api=1&query={quote(f'{name} {city}')}",
        provider="Google Maps",
        kind="map",
    )


def all_transport_links(origin: str, dest: str, travel_date: date, travellers: int = 1) -> list[BookingLink]:
    links: list[BookingLink] = []
    links += train_links(origin, dest, travel_date)
    links += bus_links(origin, dest, travel_date)
    links += flight_links(origin, dest, travel_date, travellers)
    links += car_links(origin, dest)
    return links
