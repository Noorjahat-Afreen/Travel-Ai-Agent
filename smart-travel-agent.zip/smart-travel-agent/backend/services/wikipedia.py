"""Wikipedia REST API service - verified destination descriptions.

Attribution: text under CC BY-SA; the article URL is always returned with the
summary so the UI can show the source link.
"""
from __future__ import annotations

import logging
from urllib.parse import quote

from core.cache import cached
from core.http_client import ExternalAPIError, request_json

logger = logging.getLogger(__name__)

REST_SUMMARY = "https://en.wikipedia.org/api/rest_v1/page/summary/"


@cached(ttl=86400, name="wikipedia.summary")
async def summary(title: str) -> dict | None:
    """Fetch a page summary. Returns dict(title, extract, url, thumbnail) or None."""
    url = REST_SUMMARY + quote(title.strip().replace(" ", "_"))
    try:
        payload = await request_json("wikipedia", "GET", url, retries=1)
    except ExternalAPIError:
        return None
    if payload.get("type") not in ("standard", "disambiguation"):
        return None
    if not payload.get("extract"):
        return None
    return {
        "title": payload.get("title", title),
        "extract": payload["extract"],
        "url": payload.get("content_urls", {}).get("desktop", {}).get("page", url.replace(REST_SUMMARY, WIKI_BASE)),
        "thumbnail": (payload.get("thumbnail") or {}).get("source"),
        "source": "Wikipedia (CC BY-SA)",
    }


WIKI_BASE = "https://en.wikipedia.org/wiki/"


async def summary_for_city(city: str, state: str = "") -> dict | None:
    for title in filter(None, [city, f"{city}, {state}" if state else "", f"{city}, India"]):
        result = await summary(title)
        if result and "may refer to" not in result["extract"][:60].lower():
            return result
    return None


async def health() -> bool:
    try:
        return await summary("India") is not None
    except Exception:  # noqa: BLE001
        return False
