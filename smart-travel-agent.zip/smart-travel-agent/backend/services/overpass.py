"""OpenStreetMap Overpass POI search with mirror rotation + Photon fallback.

Only public, documented APIs are used and results are cached. Zero records are
invented: if both providers fail, callers receive an empty list plus an error
note which the UI renders as "details unavailable in collected data".
"""
from __future__ import annotations

import logging
from urllib.parse import quote

from core.cache import cached
from core.http_client import ExternalAPIError, request_json

logger = logging.getLogger(__name__)

_SELECTOR_MAP = {
    "hotel": '["tourism"~"^(hotel|guest_house|hostel|resort|apartment|motel)$"]',
    "restaurant": '["amenity"~"^(restaurant|cafe|fast_food|food_court)$"]',
    "attraction": '["tourism"~"^(attraction|viewpoint|museum|monument|gallery|zoo|theme_park)$"]',
    "historic": '["historic"~"^(monument|castle|memorial|ruins|archaeological_site|fort)$"]',
    "worship": '["amenity"="place_of_worship"]',
}


def _build_query(lat: float, lon: float, radius_m: int, selector: str, limit: int) -> str:
    q = (
        f'[out:json][timeout:25];'
        f'('
        f'node{selector}(around:{radius_m},{lat},{lon});'
        f'way{selector}(around:{radius_m},{lat},{lon});'
        f');'
        f'out center {limit};'
    )
    return q


@cached(ttl=21600, name="overpass.search")
async def search_pois(
    lat: float,
    lon: float,
    category: str,
    radius_km: float | None = None,
    limit: int = 40,
) -> tuple[list[dict], str]:
    """Search POIs by category around a point.

    Returns (raw_elements, provider_used). Raw elements are Overpass-style dicts
    with at least: lat, lon, tags, type. Falls back to Photon on failure.
    """
    from core.config import settings

    radius_m = int((radius_km or settings.poi_radius_km) * 1000)
    selector = _SELECTOR_MAP.get(category)
    if selector is None:
        raise ValueError(f"unknown POI category: {category}")
    body = _build_query(lat, lon, radius_m, selector, limit)

    from core.config import settings as s

    errors: list[str] = []
    for mirror in s.overpass_mirror_list:
        try:
            payload = await request_json(
                "overpass", "POST", mirror, data={"data": body}, retries=0, timeout=30
            )
            elements = payload.get("elements", [])
            logger.info("overpass %s/%s -> %d elements", category, mirror.split('/')[2], len(elements))
            return elements, f"OpenStreetMap Overpass ({mirror.split('/')[2]})"
        except ExternalAPIError as exc:
            errors.append(f"{mirror.split('/')[2]}: {exc.detail[:80]}")
    logger.warning("overpass failed for %s, trying Photon fallback: %s", category, errors)

    # Documented fallback provider: Photon (Komoot) OSM search.
    try:
        photon = await photon_search(lat, lon, category, limit)
        if photon:
            return photon, "Photon (OpenStreetMap data via Komoot)"
    except ExternalAPIError as exc:
        errors.append(f"photon: {exc.detail[:80]}")
    logger.error("all POI providers failed for %s: %s", category, errors)
    return [], "unavailable"


async def photon_search(lat: float, lon: float, category: str, limit: int) -> list[dict]:
    """Photon POI fallback (returns Overpass-shaped dicts for uniform handling)."""
    from core.config import settings

    tag_map = {
        "hotel": ["tourism:hotel", "tourism:guest_house", "tourism:hostel"],
        "restaurant": ["amenity:restaurant", "amenity:cafe"],
        "attraction": ["tourism:attraction", "tourism:museum", "tourism:viewpoint"],
        "historic": ["historic:monument", "historic:castle"],
        "worship": ["amenity:place_of_worship"],
    }
    tags = tag_map.get(category, [])
    results: list[dict] = []
    for tag in tags:
        url = (
            f"https://photon.komoot.io/api/?lat={lat}&lon={lon}&limit={min(limit, 15)}"
            f"&osm_tag={tag}&lang=en"
        )
        try:
            payload = await request_json("photon", "GET", url, retries=0, timeout=12)
        except ExternalAPIError:
            continue
        for feature in payload.get("features", []):
            props = feature.get("properties", {})
            geom = feature.get("geometry", {}).get("coordinates", [None, None])
            if len(geom) < 2 or geom[0] is None:
                continue
            if props.get("osm_key") not in ("tourism", "amenity", "historic"):
                continue
            name = props.get("name")
            if not name:
                continue
            results.append(
                {
                    "lat": geom[1],
                    "lon": geom[0],
                    "type": "node",
                    "tags": {
                        "name": name,
                        "osm_key": props.get("osm_key", ""),
                        "osm_value": props.get("osm_value", ""),
                        "website": props.get("website", ""),
                        "phone": props.get("phone", ""),
                        "cuisine": props.get("cuisine", ""),
                        "street": " ".join(
                            filter(None, [props.get("street"), props.get("housenumber")])
                        ),
                        "city": props.get("city", ""),
                        "postcode": props.get("postcode", ""),
                    },
                }
            )
    return results[:limit]


@cached(ttl=21600, name="overpass.nearby")
async def nearby_attractions(lat: float, lon: float, radius_km: float = 8) -> tuple[list[dict], str]:
    elements, provider = await search_pois(lat, lon, "attraction", radius_km, 30)
    if not elements:
        elements2, provider2 = await search_pois(lat, lon, "historic", radius_km, 20)
        return elements + elements2, provider if not elements2 else provider2
    return elements, provider
