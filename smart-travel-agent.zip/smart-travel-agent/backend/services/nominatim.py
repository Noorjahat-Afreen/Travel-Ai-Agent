"""OpenStreetMap Nominatim geocoding service.

Usage policy respected: descriptive User-Agent, max ~1 request/second,
caching to avoid repeated lookups.
https://operations.osmfoundation.org/policies/nominatim/
"""
from __future__ import annotations

import asyncio
import logging
import time
from urllib.parse import quote

from core.cache import cached
from core.http_client import ExternalAPIError, request_json

logger = logging.getLogger(__name__)

_last_request_ts: float = 0.0
_throttle_lock = asyncio.Lock()


async def _throttle() -> None:
    """Keep >= settings.nominatim_min_interval seconds between requests."""
    global _last_request_ts
    async with _throttle_lock:
        from core.config import settings

        wait = settings.nominatim_min_interval - (time.time() - _last_request_ts)
        if wait > 0:
            await asyncio.sleep(wait)
        _last_request_ts = time.time()


@cached(ttl=86400, name="nominatim.geocode")
async def geocode_city(city: str) -> dict | None:
    """Geocode an Indian city/locality. Returns a normalised dict or None.

    Keys: name, display_name, state, lat, lon, osm_type, osm_id, source.
    """
    await _throttle()
    url = (
        "https://nominatim.openstreetmap.org/search?"
        f"q={quote(city)}, India&format=json&addressdetails=1&limit=3&countrycodes=in"
    )
    try:
        results = await request_json("nominatim", "GET", url, retries=1)
    except ExternalAPIError:
        return None
    if not results:
        return None
    best = _pick_best(results)
    if best is None:
        return None
    address = best.get("address", {})
    name = (
        address.get("city")
        or address.get("town")
        or address.get("village")
        or address.get("county")
        or best.get("name")
        or city
    )
    return {
        "name": name,
        "display_name": best.get("display_name", ""),
        "state": address.get("state", ""),
        "lat": float(best["lat"]),
        "lon": float(best["lon"]),
        "osm_type": best.get("osm_type", ""),
        "osm_id": best.get("osm_id"),
        "type": best.get("type", ""),
        "source": "OpenStreetMap Nominatim",
        "source_url": "https://nominatim.openstreetmap.org/ui/search.html?q=" + quote(city),
    }


def _pick_best(results: list[dict]) -> dict | None:
    """Prefer city-scale results (city/town/municipality) over streets."""
    preferred_types = {"city", "town", "municipality", "village", "administrative"}
    for r in results:
        if r.get("type") in preferred_types or r.get("class") == "place":
            return r
    return results[0] if results else None


@cached(ttl=86400, name="nominatim.geocode_place")
async def geocode_place(place: str) -> dict | None:
    """Geocode a landmark/POI name (used by the vision agent)."""
    await _throttle()
    url = (
        "https://nominatim.openstreetmap.org/search?"
        f"q={quote(place)}&format=json&limit=1&countrycodes=in&extratags=1"
    )
    try:
        results = await request_json("nominatim", "GET", url, retries=1)
    except ExternalAPIError:
        return None
    if not results:
        return None
    r = results[0]
    address = r.get("address", {})
    return {
        "name": r.get("name") or place,
        "display_name": r.get("display_name", ""),
        "state": address.get("state", ""),
        "lat": float(r["lat"]),
        "lon": float(r["lon"]),
        "source": "OpenStreetMap Nominatim",
    }


async def health() -> bool:
    try:
        await _throttle()
        url = "https://nominatim.openstreetmap.org/search?q=Jaipur&format=json&limit=1&countrycodes=in"
        await request_json("nominatim", "GET", url, retries=0)
        return True
    except Exception:  # noqa: BLE001
        return False
