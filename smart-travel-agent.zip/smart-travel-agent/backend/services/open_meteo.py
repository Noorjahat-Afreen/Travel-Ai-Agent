"""Open-Meteo forecast service (free, no API key required).

https://open-meteo.com/en/docs - the free daily forecast API supports a
horizon of ~16 days. Requests beyond that horizon are honestly reported as
unavailable instead of guessed.
"""
from __future__ import annotations

import logging
from datetime import date, timedelta

from core.cache import cached
from core.http_client import ExternalAPIError, request_json

logger = logging.getLogger(__name__)

FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

# WMO weather interpretation codes -> human readable text (official Open-Meteo mapping).
WMO = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Depositing rime fog",
    51: "Light drizzle", 53: "Moderate drizzle", 55: "Dense drizzle",
    56: "Light freezing drizzle", 57: "Dense freezing drizzle",
    61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
    66: "Light freezing rain", 67: "Heavy freezing rain",
    71: "Slight snowfall", 73: "Moderate snowfall", 75: "Heavy snowfall", 77: "Snow grains",
    80: "Slight rain showers", 81: "Moderate rain showers", 82: "Violent rain showers",
    85: "Slight snow showers", 86: "Heavy snow showers",
    95: "Thunderstorm", 96: "Thunderstorm with slight hail", 99: "Thunderstorm with heavy hail",
}


@cached(ttl=1800, name="open_meteo.forecast")
async def forecast(lat: float, lon: float, start: date, end: date) -> dict:
    """Daily forecast between two dates (inclusive).

    Returns {"available": bool, "days": [...], "note": str, "source": ...}.
    Days outside the API-supported horizon are omitted with a clear note.
    """
    from core.config import settings

    today = date.today()
    horizon_end = today + timedelta(days=settings.forecast_horizon_days)
    eff_start, eff_end = max(start, today), min(end, horizon_end)

    base = {
        "available": False,
        "days": [],
        "note": "",
        "source_name": "Open-Meteo",
        "source_url": "https://open-meteo.com/en/docs",
    }
    if eff_start > eff_end:
        if start > horizon_end:
            base["note"] = (
                f"Open-Meteo free forecasts cover {today.isoformat()} to {horizon_end.isoformat()} only; "
                "your travel dates are beyond that horizon. Check again closer to departure."
            )
        else:
            base["note"] = "Requested dates are in the past; no forecast can be provided."
        return base

    params = {
        "latitude": lat,
        "longitude": lon,
        "daily": (
            "temperature_2m_max,temperature_2m_min,precipitation_sum,"
            "precipitation_probability_max,weathercode"
        ),
        "timezone": "auto",
        "start_date": eff_start.isoformat(),
        "end_date": eff_end.isoformat(),
    }
    try:
        payload = await request_json("open-meteo", "GET", FORECAST_URL, params=params, retries=1)
    except ExternalAPIError as exc:
        base["note"] = f"Weather provider unavailable: {exc.detail[:120]}"
        return base

    daily = payload.get("daily", {})
    dates: list[str] = daily.get("time", [])
    days: list[dict] = []
    for i, d in enumerate(dates):
        code = daily.get("weathercode", [None] * len(dates))[i]
        days.append(
            {
                "date": d,
                "temp_min_c": daily.get("temperature_2m_min", [None])[i],
                "temp_max_c": daily.get("temperature_2m_max", [None])[i],
                "precipitation_probability": daily.get("precipitation_probability_max", [None])[i],
                "precipitation_mm": daily.get("precipitation_sum", [None])[i],
                "condition": WMO.get(code, "Unknown"),
            }
        )
    base.update(available=True, days=days)
    if start != eff_start or end != eff_end:
        base["note"] = (
            f"Forecast shown for the supported window {eff_start.isoformat()} to {eff_end.isoformat()}. "
            f"Your selected range was {start.isoformat()} to {end.isoformat()}."
        )
    return base
