"""CSV / Excel export service (pandas + openpyxl)."""
from __future__ import annotations

import io
from datetime import date

import pandas as pd

from schemas.trip import TripPlanResponse


def _place_rows(records) -> list[dict]:
    return [
        {
            "Name": r.name,
            "Category": r.category,
            "City": r.city,
            "Address": r.address or "",
            "Latitude": r.lat,
            "Longitude": r.lon,
            "Website": r.website or "",
            "Cuisine": r.cuisine or "",
            "Vegetarian": "" if r.vegetarian is None else ("Yes" if r.vegetarian else "No"),
            "Source": r.source.name,
            "Source URL": r.source.url,
        }
        for r in records
    ]


def trip_workbook(plan: TripPlanResponse) -> dict[str, pd.DataFrame]:
    o = plan.overview
    overview = pd.DataFrame(
        [
            ["Title", plan.title or f"{o.origin_city} to {o.destination_city}"],
            ["Origin", o.origin_city],
            ["Destination", o.destination_city],
            ["Departure", o.start_date.isoformat()],
            ["Return", o.end_date.isoformat()],
            ["Days", o.days],
            ["Nights", o.nights],
            ["Travellers", o.travellers],
            ["Budget (INR)", o.budget_inr],
            ["Budget per person (INR)", round(o.budget_per_person_inr, 2)],
            ["Transport mode", o.transport_mode],
            ["Trip type", o.trip_type],
            ["AI mode", plan.ai_mode],
            ["Generated at", plan.generated_at.isoformat()],
        ],
        columns=["Field", "Value"],
    )

    itinerary_rows = []
    for day in plan.itinerary:
        for act in day.activities:
            itinerary_rows.append(
                {
                    "Day": day.day_number,
                    "Date": day.date.isoformat(),
                    "Period": act.period,
                    "Activity": act.title,
                    "Place": act.place_name or "",
                    "Notes": act.note,
                }
            )
    itinerary = pd.DataFrame(itinerary_rows) if itinerary_rows else pd.DataFrame(columns=["Day", "Date", "Period", "Activity", "Place", "Notes"])

    budget_rows = [
        {"Category": c.category, "Estimated (INR)": round(c.estimated_inr, 2), "Note": c.note, "Is estimate": c.is_estimate}
        for c in plan.budget.categories
    ]
    budget = pd.DataFrame(budget_rows)

    weather = pd.DataFrame(
        [
            {
                "Date": w.date.isoformat(),
                "Min (C)": w.temp_min_c,
                "Max (C)": w.temp_max_c,
                "Rain probability (%)": w.precipitation_probability,
                "Rain (mm)": w.precipitation_mm,
                "Condition": w.condition,
                "Source": w.source.name,
            }
            for w in plan.weather
        ]
    ) if plan.weather else pd.DataFrame(columns=["Date", "Min (C)", "Max (C)", "Rain probability (%)", "Rain (mm)", "Condition", "Source"])

    transport = pd.DataFrame(
        [
            {
                "Mode": t.mode,
                "Provider": t.provider,
                "Summary": t.summary,
                "Booking link": t.deep_link,
                "Estimate?": t.is_estimate,
                "Estimated fare (INR)": t.estimated_cost_inr,
                "Source": t.source.name,
            }
            for t in plan.transport_options
        ]
    )

    verification = pd.DataFrame(
        [[plan.verification.checked_records, "; ".join(f"{i.kind}: {i.record}" for i in plan.verification.issues[:20]), plan.verification.summary]],
        columns=["Checked records", "Issues", "Summary"],
    )

    return {
        "Overview": overview,
        "Itinerary": itinerary,
        "Budget": budget,
        "Hotels": pd.DataFrame(_place_rows(plan.hotels)),
        "Restaurants": pd.DataFrame(_place_rows(plan.restaurants)),
        "Attractions": pd.DataFrame(_place_rows(plan.attractions)),
        "Weather": weather,
        "Transport": transport,
        "Verification": verification,
    }


def to_csv_bytes(plan: TripPlanResponse) -> bytes:
    """Single-sheet CSV: overview + itinerary (most requested export)."""
    frames = trip_workbook(plan)
    parts = ["=== OVERVIEW ==="]
    ov = frames["Overview"]
    parts.extend(f"{k}: {v}" for k, v in ov.itertuples(index=False))
    parts.append("")
    parts.append("=== ITINERARY ===")
    if not frames["Itinerary"].empty:
        parts.append(frames["Itinerary"].to_csv(index=False))
    parts.append("=== BUDGET ===")
    if not frames["Budget"].empty:
        parts.append(frames["Budget"].to_csv(index=False))
    return ("\n".join(parts)).encode("utf-8")


def to_xlsx_bytes(plan: TripPlanResponse) -> bytes:
    buffer = io.BytesIO()
    frames = trip_workbook(plan)
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        for sheet, df in frames.items():
            df.to_excel(writer, sheet_name=sheet[:31], index=False)
    buffer.seek(0)
    return buffer.getvalue()
