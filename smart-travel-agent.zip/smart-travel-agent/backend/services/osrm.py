"""OSRM public routing service - road distance & duration estimates.

https://router.project-osrm.org - the public demo server is rate limited;
results are cached and always labelled as ESTIMATES in the UI.
"""
from __future__ import annotations

from core.cache import cached
from core.http_client import ExternalAPIError, request_json

BASE = "https://router.project-osrm.org/route/v1/driving"


@cached(ttl=86400, name="osrm.route")
async def road_route(
    origin_lat: float, origin_lon: float, dest_lat: float, dest_lon: float
) -> dict | None:
    """Return {distance_km, duration_hours, source, source_url} or None on failure."""
    url = f"{BASE}/{origin_lon},{origin_lat};{dest_lon},{dest_lat}?overview=false&alternatives=false"
    try:
        payload = await request_json("osrm", "GET", url, retries=1, timeout=15)
    except ExternalAPIError:
        return None
    routes = payload.get("routes") or []
    if not routes:
        return None
    r = routes[0]
    return {
        "distance_km": round(r["distance"] / 1000, 1),
        "duration_hours": round(r["duration"] / 3600, 1),
        "source": "OSRM (OpenStreetMap-based routing)",
        "source_url": "https://router.project-osrm.org",
    }


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance (offline fallback, exact to ~0.5%)."""
    import math

    r = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return round(2 * r * math.asin(math.sqrt(a)), 1)
