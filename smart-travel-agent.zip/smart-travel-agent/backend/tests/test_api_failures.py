"""API-failure resilience: providers down -> graceful degradation, no crashes."""
from __future__ import annotations

from datetime import date, timedelta


def test_plan_survives_total_provider_outage(client, no_external_calls):
    """Every provider failing must still yield a well-formed plan response."""
    start = date.today() + timedelta(days=10)
    r = client.post("/api/trips/plan", json={
        "origin_city": "Indore", "destination_city": "Jaipur",
        "start_date": start.isoformat(), "end_date": (start + timedelta(days=2)).isoformat(),
        "save_plan": False,
    })
    assert r.status_code == 200
    body = r.json()
    # Budget agent works offline (estimate mode).
    assert body["budget"]["total_estimated_inr"] > 0
    # Transport links are provider deep links (no live data needed).
    assert len(body["transport_options"]) >= 1
    # Agents honestly report degradation.
    degraded = [s for s in body["agent_statuses"] if s["degraded"]]
    assert degraded
    # Itinerary contains honest guidance instead of fabricated venues.
    assert len(body["itinerary"]) == 3
    assert any("details unavailable" in (a["description"] or "") or a["place_name"] is None
               for d in body["itinerary"] for a in d["activities"])


def test_hotels_endpoint_graceful_on_outage(client, no_external_calls):
    """POI outage still returns provider booking links (spec: labelled fallback)."""
    r = client.get("/api/hotels", params={"city": "Jaipur", "lat": 26.9, "lon": 75.8})
    assert r.status_code == 200
    body = r.json()
    assert body["hotels"] == []
    assert any(l["label"] == "Book Hotel Now" for l in body["booking_links"])


def test_weather_endpoint_graceful_on_outage(client, no_external_calls):
    r = client.get("/api/weather", params={"city": "Jaipur", "lat": 26.9, "lon": 75.8})
    assert r.status_code == 200
    body = r.json()
    assert body["available"] is False
    assert "unavailable" in body["note"]


def test_chat_survives_outage(client, no_external_calls):
    r = client.post("/api/chat", json={"session_id": "outage-test", "message": "hotels in Jaipur"})
    assert r.status_code == 200
    body = r.json()
    assert body["reply"]


def test_rate_limiter_blocks_after_limit():
    from core.rate_limit import check_rate_limit, reset_rate_limiter

    reset_rate_limiter()
    allowed = 0
    for i in range(7):
        if check_rate_limit("10.0.0.1", rpm=5, now=1000.0 + i):
            allowed += 1
    assert allowed == 5
    # A new window resets the bucket.
    assert check_rate_limit("10.0.0.1", rpm=5, now=2000.0)
    reset_rate_limiter()


def test_cache_ttl_expiry():
    import asyncio

    from core.cache import TTLCache

    async def scenario():
        c = TTLCache()
        await c.set("k", {"v": 1}, ttl=1)
        assert await c.get("k") == {"v": 1}
        c._store["k"].expires_at = 0  # force expiry
        assert await c.get("k") is None

    asyncio.run(scenario())


def test_redaction_removes_secrets():
    from core.logging_conf import redact

    payload = {"api_key": "super-secret", "city": "Jaipur", "token": "abc", "q": "hotels"}
    safe = redact(payload)
    assert safe["api_key"] == "***" and safe["token"] == "***"
    assert safe["city"] == "Jaipur" and safe["q"] == "hotels"
