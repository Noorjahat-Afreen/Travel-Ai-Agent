"""Database operation tests: CRUD, constraints, deduplication."""
from __future__ import annotations

from datetime import date, timedelta

import pytest
from sqlalchemy.exc import IntegrityError

from models import AIConversation, Destination, Hotel, SavedRecommendation, TravelPlan
from schemas.common import PlaceRecord, SourceInfo
from services import data_collector


def test_travel_plan_crud(db_session):
    row = TravelPlan(
        session_id="dbtest", origin_city="Indore", destination_city="Jaipur",
        start_date=date.today(), end_date=date.today() + timedelta(days=2),
        travellers=2, budget_inr=20000, transport_mode="train",
    )
    db_session.add(row)
    db_session.commit()
    db_session.refresh(row)
    assert row.id is not None
    assert row.created_at is not None
    row.status = "completed"
    db_session.commit()
    fetched = db_session.get(TravelPlan, row.id)
    assert fetched.status == "completed"
    db_session.delete(fetched)
    db_session.commit()
    assert db_session.get(TravelPlan, row.id) is None


def test_hotel_unique_constraint(db_session):
    db_session.add(Hotel(name="Dup Hotel", city="Jaipur", lat=1.0, lon=2.0, source_name="test"))
    db_session.commit()
    db_session.add(Hotel(name="Dup Hotel", city="Jaipur", lat=1.0, lon=2.0, source_name="test"))
    with pytest.raises(IntegrityError):
        db_session.commit()
    db_session.rollback()
    db_session.query(Hotel).filter(Hotel.name == "Dup Hotel").delete()
    db_session.commit()


def test_upsert_hotels_deduplicates(db_session):
    src = SourceInfo(name="test", url="https://test")
    records = [
        PlaceRecord(name="Dedup Hotel", lat=26.9, lon=75.8, city="Jaipur", source=src),
        PlaceRecord(name="Dedup Hotel", lat=26.9, lon=75.8, city="Jaipur", source=src),  # duplicate
    ]
    data_collector.upsert_hotels(db_session, None, "Jaipur", records)
    count = (
        db_session.query(Hotel)
        .filter(Hotel.name == "Dedup Hotel", Hotel.lat == 26.9, Hotel.lon == 75.8)
        .count()
    )
    assert count == 1
    db_session.query(Hotel).filter(Hotel.name == "Dedup Hotel").delete()
    db_session.commit()


def test_weather_records_saved(db_session):
    days = [
        {"date": (date.today() + timedelta(days=i)).isoformat(), "temp_min_c": 10.0, "temp_max_c": 20.0,
         "precipitation_probability": 5, "precipitation_mm": 0, "condition": "Clear sky"}
        for i in range(3)
    ]
    saved = data_collector.save_weather(db_session, None, "DbTestCity", 26.9, 75.8, days)
    assert saved == 3
    # second save is idempotent
    saved_again = data_collector.save_weather(db_session, None, "DbTestCity", 26.9, 75.8, days)
    assert saved_again == 0
    db_session.query().filter()  # no-op clarity
    from models import WeatherRecord

    db_session.query(WeatherRecord).filter(WeatherRecord.city == "DbTestCity").delete()
    db_session.commit()


def test_destination_persist_and_reuse(db_session):
    row = data_collector.save_destination(db_session, {
        "name": "Persist Test Fort", "city": "Persistville", "state": "Test Pradesh",
        "lat": 10.0, "lon": 20.0, "description": "A test fort.",
    })
    assert row is not None
    again = data_collector.save_destination(db_session, {
        "name": "Persist Test Fort", "city": "Persistville", "lat": 10.0, "lon": 20.0,
    })
    assert again.id == row.id
    db_session.delete(again)
    db_session.commit()


def test_conversation_and_recommendations(db_session):
    db_session.add(AIConversation(session_id="dbtest-chat", role="user", content="hi"))
    db_session.commit()
    assert db_session.query(AIConversation).filter(AIConversation.session_id == "dbtest-chat").count() == 1

    rec = SavedRecommendation(session_id="dbtest", kind="restaurant", ref_name="Test Cafe", payload={})
    db_session.add(rec)
    db_session.commit()
    assert rec.id is not None
    db_session.delete(rec)
    db_session.query(AIConversation).filter(AIConversation.session_id == "dbtest-chat").delete()
    db_session.commit()


def test_destinations_seeded(db_session):
    count = db_session.query(Destination).count()
    assert count >= 100
