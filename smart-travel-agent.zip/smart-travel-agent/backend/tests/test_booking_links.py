"""Booking deep-link generation tests - URL formats must match provider specs."""
from __future__ import annotations

from datetime import date

from services import booking_links


def test_train_link_with_station_codes():
    links = booking_links.train_links("Indore", "Jaipur", date(2026, 12, 10))
    primary = links[0]
    assert "irctc.co.in/nget/train-search" in primary.url
    assert "fromStation=INDB" in primary.url
    assert "toStation=JP" in primary.url
    assert "journeyDate=2026-12-10" in primary.url
    assert primary.provider.startswith("IRCTC")
    assert primary.kind == "train"


def test_train_link_without_codes_falls_back_to_generic():
    links = booking_links.train_links("Atlantis", "Narnia", date(2026, 12, 10))
    assert links[0].url == "https://www.irctc.co.in/nget/train-search"


def test_bus_redbus_link_format():
    links = booking_links.bus_links("Indore", "Jaipur", date(2026, 12, 10))
    url = links[0].url
    assert url.startswith("https://www.redbus.in/search?")
    assert "fromCityName=Indore" in url
    assert "toCityName=Jaipur" in url
    assert "onward=10-Dec-2026" in url


def test_flight_links_google_and_mmt():
    links = booking_links.flight_links("Delhi", "Mumbai", date(2026, 12, 10), travellers=3)
    google = links[0]
    assert google.url.startswith("https://www.google.com/travel/flights?q=")
    assert "Delhi" in google.url and "Mumbai" in google.url
    mmt = next(l for l in links if l.provider == "MakeMyTrip")
    assert "itinerary=DEL-BOM-10/12/2026" in mmt.url
    assert "adults=3" in mmt.url


def test_hotel_booking_link_contains_dates_and_guests():
    links = booking_links.hotel_links("Jaipur", date(2026, 12, 10), date(2026, 12, 12), 4)
    booking = links[0]
    assert "booking.com/searchresults.html" in booking.url
    assert "ss=Jaipur" in booking.url
    assert "checkin=2026-12-10" in booking.url
    assert "checkout=2026-12-12" in booking.url
    assert "group_adults=4" in booking.url


def test_car_directions_link():
    links = booking_links.car_links("Indore", "Jaipur")
    url = links[0].url
    assert url.startswith("https://www.google.com/maps/dir/?api=1&origin=")
    assert "destination=Jaipur%2CIndia" in url or "destination=Jaipur,India" in url.replace("%2C", ",%2C")


def test_directions_link_with_coordinates():
    link = booking_links.directions_link(26.9124, 75.7873, origin="Indore")
    assert "destination=26.9124,75.7873" in link.url
    assert "origin=Indore%2CIndia" in link.url


def test_osm_link():
    link = booking_links.osm_link(26.9124, 75.7873)
    assert "#map=17/26.9124/75.7873" in link.url


def test_all_transport_links_contains_all_modes():
    links = booking_links.all_transport_links("Indore", "Jaipur", date(2026, 12, 10))
    kinds = {l.kind for l in links}
    assert {"train", "bus", "flight", "car"} <= kinds


def test_every_link_is_https_and_absolute():
    links = booking_links.all_transport_links("Delhi", "Goa", date(2026, 12, 10))
    links += booking_links.hotel_links("Goa", date(2026, 12, 10), date(2026, 12, 14), 2)
    for l in links:
        assert l.url.startswith("https://"), l.url
