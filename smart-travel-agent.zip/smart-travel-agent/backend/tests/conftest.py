"""Shared pytest fixtures.

Environment is prepared BEFORE importing the app so settings pick up the
temporary test database. External providers are mocked at module boundaries -
unit tests never touch the network.
"""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

import pytest

BACKEND_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND_DIR))

# Isolated test DB + disabled AI key (tests must not depend on secrets).
_TEST_DB = Path(tempfile.mkdtemp(prefix="sta-tests-")) / "test.db"
os.environ["DB_URL"] = f"sqlite:///{_TEST_DB}"
os.environ["GEMINI_API_KEY"] = ""
os.environ["RATE_LIMIT_RPM"] = "10000"

from fastapi.testclient import TestClient  # noqa: E402

from core.config import settings  # noqa: E402


@pytest.fixture(scope="session")
def client():
    from main import app

    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture()
def db_session():
    from database.engine import SessionLocal

    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


@pytest.fixture()
def fake_geo():
    """A deterministic geocoding result (Jaipur)."""
    return {
        "name": "Jaipur",
        "display_name": "Jaipur, Jaipur District, Rajasthan, India",
        "state": "Rajasthan",
        "lat": 26.9124,
        "lon": 75.7873,
        "osm_type": "relation",
        "osm_id": 1,
        "type": "city",
        "source": "OpenStreetMap Nominatim",
        "source_url": "https://nominatim.openstreetmap.org",
    }


@pytest.fixture()
def mock_providers(monkeypatch):
    """Patch every external provider with deterministic, realistic payloads."""
    import asyncio

    from services import nominatim, open_meteo, osrm as osrm_mod, overpass, wikipedia

    def run(coro_fn, *args, **kwargs):
        return coro_fn(*args, **kwargs)

    async def fake_geocode(city: str):
        return {
            "name": city.title() if city.islower() else city,
            "display_name": f"{city}, India",
            "state": "Rajasthan" if "jaipur" in city.lower() else "Test State",
            "lat": 26.9124,
            "lon": 75.7873,
            "type": "city",
            "source": "OpenStreetMap Nominatim",
            "source_url": "https://nominatim.openstreetmap.org",
        }

    async def fake_geocode_place(place: str):
        return {"name": place, "display_name": place, "state": "Rajasthan", "lat": 26.9, "lon": 75.8, "source": "test"}

    async def fake_summary(title: str):
        return {
            "title": title,
            "extract": f"Wikipedia summary of {title}. It is a well-known place in India with documented history.",
            "url": f"https://en.wikipedia.org/wiki/{title}",
            "thumbnail": None,
            "source": "Wikipedia (CC BY-SA)",
        }

    async def fake_search_pois(lat, lon, category, radius_km=None, limit=40):
        elements = []
        for i in range(1, 4):
            tags = {"name": f"Test {category.title()} {i}"}
            if category == "restaurant":
                tags.update({"cuisine": "north_indian", "diet:vegetarian": "yes" if i % 2 else "no"})
            if category == "hotel":
                tags.update({"website": f"https://hotel{i}.example.com", "stars": "3"})
            if category == "attraction":
                tags.update({"tourism": "attraction"})
            elements.append({"lat": lat + 0.01 * i, "lon": lon + 0.01 * i, "type": "node", "tags": tags})
        return elements, "OpenStreetMap Overpass (test)"

    async def fake_forecast(lat, lon, start, end):
        from datetime import timedelta

        days = []
        d = start
        while d <= end:
            days.append({
                "date": d.isoformat(),
                "temp_min_c": 18.0,
                "temp_max_c": 32.0,
                "precipitation_probability": 10.0,
                "precipitation_mm": 0.0,
                "condition": "Clear sky",
            })
            d += timedelta(days=1)
        return {"available": True, "days": days, "note": "", "source_name": "Open-Meteo", "source_url": "https://open-meteo.com"}

    async def fake_road(*args, **kwargs):
        return {"distance_km": 300.0, "duration_hours": 5.0, "source": "OSRM (test)", "source_url": "https://router.project-osrm.org"}

    monkeypatch.setattr(nominatim, "geocode_city", fake_geocode)
    monkeypatch.setattr(nominatim, "geocode_place", fake_geocode_place)
    monkeypatch.setattr(wikipedia, "summary", fake_summary)
    monkeypatch.setattr(overpass, "search_pois", fake_search_pois)
    monkeypatch.setattr(overpass, "nearby_attractions", fake_search_pois)
    monkeypatch.setattr(open_meteo, "forecast", fake_forecast)
    monkeypatch.setattr(osrm_mod, "road_route", fake_road)
    return True


@pytest.fixture()
def no_external_calls(monkeypatch):
    """Providers unreachable -> services return their honest 'unavailable' values
    (exactly what the real service functions do after catching provider errors)."""
    from services import nominatim, open_meteo, overpass, wikipedia

    async def geocode_fail(city):
        return None

    async def summary_fail(title):
        return None

    async def pois_fail(lat, lon, category, radius_km=None, limit=40):
        return [], "unavailable"

    async def forecast_fail(lat, lon, start, end):
        return {
            "available": False,
            "days": [],
            "note": "Weather provider unavailable: provider unreachable (test)",
            "source_name": "Open-Meteo",
            "source_url": "https://open-meteo.com",
        }

    monkeypatch.setattr(nominatim, "geocode_city", geocode_fail)
    monkeypatch.setattr(nominatim, "geocode_place", geocode_fail)
    monkeypatch.setattr(wikipedia, "summary", summary_fail)
    monkeypatch.setattr(overpass, "search_pois", pois_fail)
    monkeypatch.setattr(overpass, "nearby_attractions", pois_fail)
    monkeypatch.setattr(open_meteo, "forecast", forecast_fail)
    return True
