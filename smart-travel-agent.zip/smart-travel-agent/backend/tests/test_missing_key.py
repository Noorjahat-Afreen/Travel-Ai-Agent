"""Missing-API-key behaviour: the platform must degrade gracefully, never crash."""
from __future__ import annotations

import pytest

from services.llm import get_chat_model, llm_status


def test_llm_unavailable_without_key():
    from core.config import settings

    assert not settings.gemini_api_key
    assert get_chat_model() is None


def test_llm_status_reports_local_mode():
    status = llm_status()
    assert status["available"] is False
    assert status["mode"] == "local"
    assert "GEMINI_API_KEY" in status["note"]


def test_structured_output_returns_none_without_key():
    import asyncio

    from pydantic import BaseModel

    from services.llm import structured_output

    class _S(BaseModel):
        value: int

    result = asyncio.run(structured_output(_S, "give me a number"))
    assert result is None


def test_chat_agent_local_mode_label(client, mock_providers):
    r = client.post("/api/chat", json={"session_id": "nokey-test", "message": "hotels in Jaipur"})
    body = r.json()
    assert body["mode"] == "local"
    # Local mode still delivers real data cards.
    assert body["data_cards"]


def test_plan_notes_mention_local_mode(client, mock_providers):
    start = __import__("datetime").date.today() + __import__("datetime").timedelta(days=15)
    r = client.post("/api/trips/plan", json={
        "origin_city": "Indore", "destination_city": "Jaipur",
        "start_date": start.isoformat(), "end_date": (start + __import__("datetime").timedelta(days=2)).isoformat(),
        "save_plan": False,
    })
    body = r.json()
    assert body["ai_mode"] == "local"
    assert any("local intelligence mode" in n for n in body["notes"])


def test_gemini_mode_detection_with_key(monkeypatch):
    from core import config as config_module

    monkeypatch.setattr(config_module.settings, "gemini_api_key", "fake-key-for-detection", raising=False)
    status = llm_status()
    # Even with a fake key the model may fail to initialise offline; status must
    # report honestly rather than pretending.
    assert status["mode"] in ("gemini", "local")
    monkeypatch.setattr(config_module.settings, "gemini_api_key", "", raising=False)
