"""Trip request date validation tests."""
from __future__ import annotations

from datetime import date, timedelta

import pytest
from pydantic import ValidationError

from schemas.trip import TripRequest


def test_valid_request():
    req = TripRequest(
        origin_city="Indore",
        destination_city="Jaipur",
        start_date=date.today() + timedelta(days=5),
        end_date=date.today() + timedelta(days=8),
        travellers=2,
        budget_inr=30000,
    )
    assert req.days == 4
    assert req.nights == 3


def test_past_departure_rejected():
    with pytest.raises(ValidationError):
        TripRequest(
            origin_city="Indore",
            destination_city="Jaipur",
            start_date=date.today() - timedelta(days=1),
            end_date=date.today(),
        )


def test_return_before_departure_rejected():
    with pytest.raises(ValidationError):
        TripRequest(
            origin_city="Indore",
            destination_city="Jaipur",
            start_date=date.today() + timedelta(days=5),
            end_date=date.today() + timedelta(days=4),
        )


def test_duration_over_limit_rejected():
    with pytest.raises(ValidationError):
        TripRequest(
            origin_city="Indore",
            destination_city="Jaipur",
            start_date=date.today() + timedelta(days=1),
            end_date=date.today() + timedelta(days=60),
        )


def test_travellers_bounds():
    with pytest.raises(ValidationError):
        TripRequest(
            origin_city="Indore",
            destination_city="Jaipur",
            start_date=date.today() + timedelta(days=1),
            end_date=date.today() + timedelta(days=2),
            travellers=0,
        )
    with pytest.raises(ValidationError):
        TripRequest(
            origin_city="Indore",
            destination_city="Jaipur",
            start_date=date.today() + timedelta(days=1),
            end_date=date.today() + timedelta(days=2),
            travellers=25,
        )


def test_budget_bounds():
    with pytest.raises(ValidationError):
        TripRequest(
            origin_city="Indore",
            destination_city="Jaipur",
            start_date=date.today() + timedelta(days=1),
            end_date=date.today() + timedelta(days=2),
            budget_inr=100,
        )


def test_empty_city_rejected():
    with pytest.raises(ValidationError):
        TripRequest(
            origin_city="  ",
            destination_city="Jaipur",
            start_date=date.today() + timedelta(days=1),
            end_date=date.today() + timedelta(days=2),
        )
