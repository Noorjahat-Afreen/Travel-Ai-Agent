"""Budget Agent calculation tests (pure, deterministic)."""
from __future__ import annotations

from datetime import date, timedelta

import pytest

from agents.budget_agent import BudgetAgent, per_day_totals
from schemas.trip import FoodPreference, HotelPreference, TransportMode, TripRequest


def _request(**overrides) -> TripRequest:
    base = dict(
        origin_city="Indore",
        destination_city="Jaipur",
        start_date=date.today() + timedelta(days=10),
        end_date=date.today() + timedelta(days=13),
        travellers=2,
        budget_inr=50000,
        transport_mode=TransportMode.train,
        trip_type="heritage",
        interests=["heritage"],
        hotel_preference=HotelPreference.mid_range,
        food_preference=FoodPreference.vegetarian,
    )
    base.update(overrides)
    return TripRequest(**base)


def test_budget_totals_and_per_person():
    budget = BudgetAgent().compute(_request(), 600.0, [])
    assert budget.total_estimated_inr > 0
    expected_per_person = round(budget.total_estimated_inr / 2, 2)
    assert budget.per_person_inr == pytest.approx(expected_per_person)
    assert budget.within_budget is True
    # 10% emergency buffer must be its own category.
    buffer = next(c for c in budget.categories if c.category == "Emergency buffer")
    subtotal = sum(c.estimated_inr for c in budget.categories if c.category != "Emergency buffer")
    assert buffer.estimated_inr == pytest.approx(round(subtotal * 0.10))
    assert abs(budget.total_estimated_inr - (subtotal + buffer.estimated_inr)) < 1


def test_budget_categories_present():
    budget = BudgetAgent().compute(_request(), 600.0, [])
    names = {c.category for c in budget.categories}
    assert {"Transport", "Hotel", "Food", "Activities", "Local travel", "Emergency buffer"} <= names
    assert all(c.is_estimate for c in budget.categories)
    assert "NOT supplier prices" in budget.disclaimer
    assert len(budget.assumptions) >= 5


def test_budget_transport_scales_with_distance_and_travellers():
    one = BudgetAgent().compute(_request(travellers=1), 600.0, [])
    four = BudgetAgent().compute(_request(travellers=4), 600.0, [])
    t_one = next(c for c in one.categories if c.category == "Transport").estimated_inr
    t_four = next(c for c in four.categories if c.category == "Transport").estimated_inr
    assert t_four == pytest.approx(t_one * 4)


def test_budget_flight_more_expensive_than_train():
    air = BudgetAgent().compute(_request(transport_mode=TransportMode.flight), 600.0, [])
    rail = BudgetAgent().compute(_request(transport_mode=TransportMode.train), 600.0, [])
    air_transport = next(c for c in air.categories if c.category == "Transport")
    rail_transport = next(c for c in rail.categories if c.category == "Transport")
    assert air_transport.estimated_inr > rail_transport.estimated_inr


def test_budget_uses_osm_price_level_when_tagged():
    from schemas.common import PlaceRecord, SourceInfo

    src = SourceInfo(name="test")
    hotels = [
        PlaceRecord(name="H1", lat=26.9, lon=75.8, price_level=4, source=src),
        PlaceRecord(name="H2", lat=26.9, lon=75.8, price_level=4, source=src),
    ]
    budget = BudgetAgent().compute(_request(), 600.0, hotels)
    hotel_cat = next(c for c in budget.categories if c.category == "Hotel")
    luxury = BudgetAgent().compute(_request(), 600.0, [])
    hotel_plain = next(c for c in luxury.categories if c.category == "Hotel")
    assert hotel_cat.estimated_inr > hotel_plain.estimated_inr


def test_budget_over_budget_flag():
    budget = BudgetAgent().compute(_request(budget_inr=1000, travellers=6), 2000.0, [])
    assert budget.within_budget is False
    assert budget.total_estimated_inr > budget.user_budget_inr


def test_per_day_totals():
    budget = BudgetAgent().compute(_request(), 600.0, [])
    daily = per_day_totals(budget, 4)
    transport_daily = daily["Transport"]
    assert transport_daily == pytest.approx(
        round(next(c for c in budget.categories if c.category == "Transport").estimated_inr / 4)
    )


def test_budget_unknown_distance_assumption():
    budget = BudgetAgent().compute(_request(), None, [])
    assert any("500 km" in a for a in budget.assumptions)
