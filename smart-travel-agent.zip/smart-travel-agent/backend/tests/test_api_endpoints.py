"""End-to-end API endpoint tests (external providers mocked)."""
from __future__ import annotations

from datetime import date, timedelta

import pytest


def _plan_payload(days: int = 3) -> dict:
    start = date.today() + timedelta(days=10)
    return {
        "origin_city": "Indore",
        "destination_city": "Jaipur",
        "start_date": start.isoformat(),
        "end_date": (start + timedelta(days=days - 1)).isoformat(),
        "travellers": 2,
        "budget_inr": 40000,
        "transport_mode": "train",
        "trip_type": "heritage",
        "interests": ["heritage", "food"],
        "hotel_preference": "mid-range",
        "food_preference": "vegetarian",
        "session_id": "pytest-session-001",
        "save_plan": True,
    }


def test_health(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert body["database"] == "connected"
    assert body["ai_mode"] in ("local", "gemini")


def test_ai_status(client):
    r = client.get("/api/ai/status")
    assert r.status_code == 200
    body = r.json()
    assert body["available"] is False          # no GEMINI_API_KEY in tests
    assert body["mode"] == "local"
    assert body["rag_documents"] >= 100
    assert "GEMINI_API_KEY" in body["note"]


def test_dashboard_stats(client):
    r = client.get("/api/dashboard/stats")
    assert r.status_code == 200
    body = r.json()
    assert body["destinations"] >= 100
    assert isinstance(body["providers"], list) and len(body["providers"]) >= 5
    assert "recent_trips" in body


def test_explore_destinations_by_category(client):
    r = client.get("/api/explore/destinations", params={"category": "hill-station"})
    assert r.status_code == 200
    data = r.json()
    assert len(data) > 5
    assert all(d["category"] == "hill-station" for d in data)
    assert all(d["wiki_url"].startswith("https://en.wikipedia.org") for d in data)


def test_explore_states(client):
    r = client.get("/api/explore/states")
    assert r.status_code == 200
    states = {g["state"] for g in r.json()}
    assert "Rajasthan" in states and "Kerala" in states


def test_explore_search_curated(client, mock_providers):
    r = client.get("/api/explore/search", params={"q": "Manali"})
    assert r.status_code == 200
    body = r.json()
    assert body["matched_destination"]["city"] == "Manali"
    assert body["state"] == "Himachal Pradesh"
    assert body["description"]


def test_explore_search_live_geocode(client, mock_providers):
    r = client.get("/api/explore/search", params={"q": "Zirakpur"})
    assert r.status_code == 200
    body = r.json()
    assert body["lat"] is not None or body["matched_destination"]


def test_explore_search_unknown_is_honest(client, no_external_calls):
    r = client.get("/api/explore/search", params={"q": "Xyzville"})
    assert r.status_code == 200
    assert "details unavailable in collected data" in r.json()["description"]


def test_hotels_endpoint(client, mock_providers):
    r = client.get("/api/hotels", params={"city": "Jaipur"})
    assert r.status_code == 200
    body = r.json()
    assert len(body["hotels"]) >= 3
    h = body["hotels"][0]
    assert h["source"]["name"]
    assert any(l["label"] == "Book Hotel Now" for l in h["booking_links"])
    assert len(body["booking_links"]) >= 2


def test_restaurants_veg_tags(client, mock_providers):
    r = client.get("/api/restaurants", params={"city": "Jaipur"})
    assert r.status_code == 200
    body = r.json()
    assert len(body["restaurants"]) >= 3
    assert any(r["vegetarian"] is True for r in body["restaurants"])


def test_attractions_endpoint(client, mock_providers):
    r = client.get("/api/attractions", params={"city": "Jaipur"})
    assert r.status_code == 200
    body = r.json()
    assert len(body["attractions"]) >= 3


def test_places_unknown_city_404(client, no_external_calls):
    r = client.get("/api/hotels", params={"city": "Unknownville"})
    assert r.status_code == 404


def test_transport_endpoint(client, mock_providers):
    r = client.get("/api/transport/search", params={
        "origin": "Indore", "destination": "Jaipur", "travel_date": "2026-12-20", "travellers": 2,
    })
    assert r.status_code == 200
    body = r.json()
    modes = {o["mode"] for o in body["options"]}
    assert {"train", "bus", "flight", "car"} <= modes
    train = next(o for o in body["options"] if o["mode"] == "train")
    assert "IRCTC" in train["provider"] or "IRCTC" in train["deep_link"]
    assert body["road_estimate"] is not None


def test_transport_invalid_mode(client):
    r = client.get("/api/transport/search", params={"origin": "Agra", "destination": "Jaipur", "mode": "rocket"})
    assert r.status_code == 422


def test_weather_endpoint(client, mock_providers):
    r = client.get("/api/weather", params={"city": "Jaipur"})
    assert r.status_code == 200
    body = r.json()
    assert body["available"] is True
    assert len(body["days"]) == 5
    assert body["days"][0]["source"]["name"] == "Open-Meteo"


def test_weather_far_future_honest(client):
    r = client.get("/api/weather", params={"city": "Jaipur", "start": "2027-06-01", "end": "2027-06-05"})
    assert r.status_code == 200
    body = r.json()
    assert body["available"] is False
    assert "horizon" in body["note"]


# ---------------------------------------------------------------- trips lifecycle
def test_full_trip_lifecycle(client, mock_providers):
    # 1) generate plan
    r = client.post("/api/trips/plan", json=_plan_payload())
    assert r.status_code == 200
    plan = r.json()
    assert plan["overview"]["days"] == 3
    assert plan["destination_info"]["name"].lower() == "jaipur"
    assert len(plan["transport_options"]) >= 1
    assert len(plan["itinerary"]) == 3
    assert plan["budget"]["total_estimated_inr"] > 0
    assert plan["verification"]["checked_records"] > 0
    assert len(plan["agent_statuses"]) >= 8
    assert plan["saved"] is True and plan["trip_id"] is not None
    trip_id = plan["trip_id"]

    # 2) list
    r = client.get("/api/trips", params={"session_id": "pytest-session-001"})
    assert r.status_code == 200
    assert any(t["id"] == trip_id for t in r.json())

    # 3) fetch saved snapshot
    r = client.get(f"/api/trips/{trip_id}")
    assert r.status_code == 200
    assert r.json()["overview"]["destination_city"] == "Jaipur"

    # 4) update
    r = client.patch(f"/api/trips/{trip_id}", json={"title": "Renamed Trip", "status": "completed"})
    assert r.status_code == 200
    assert r.json()["title"] == "Renamed Trip"
    assert r.json()["status"] == "completed"

    # 5) exports
    r = client.get(f"/api/exports/trip/{trip_id}/csv")
    assert r.status_code == 200
    assert "OVERVIEW" in r.text
    r = client.get(f"/api/exports/trip/{trip_id}/xlsx")
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("application/vnd.openxmlformats")

    # 6) recommendations save/list
    r = client.post(f"/api/trips/{trip_id}/save-recommendation",
                    json={"kind": "hotel", "name": "Hotel Rangoli", "payload": {"lat": 26.9}})
    assert r.status_code == 200
    r = client.get(f"/api/trips/{trip_id}/recommendations")
    assert r.status_code == 200
    assert len(r.json()) == 1

    # 7) delete
    r = client.delete(f"/api/trips/{trip_id}")
    assert r.status_code == 200
    r = client.get(f"/api/trips/{trip_id}")
    assert r.status_code == 404


def test_plan_invalid_dates_rejected(client):
    payload = _plan_payload()
    payload["end_date"] = "2020-01-01"
    r = client.post("/api/trips/plan", json=payload)
    assert r.status_code == 422


def test_plan_unknown_city_honest_error(client, no_external_calls):
    payload = _plan_payload()
    payload["destination_city"] = "Nowhereville"  # not in curated data either
    r = client.post("/api/trips/plan", json=payload)
    assert r.status_code == 200
    body = r.json()
    assert body["destination_info"] is None
    assert any("not found" in n.lower() for n in body["notes"])


def test_get_missing_trip_404(client):
    assert client.get("/api/trips/999999").status_code == 404
    assert client.delete("/api/trips/999999").status_code == 404


# ---------------------------------------------------------------- chat
def test_chat_hotels_intent(client, mock_providers):
    r = client.post("/api/chat", json={"session_id": "pytest-chat-01", "message": "Find budget hotels in Jaipur"})
    assert r.status_code == 200
    body = r.json()
    assert body["mode"] == "local"
    assert any(c["kind"] == "hotels" for c in body["data_cards"])
    assert any(t == "find_hotels" for t in body["tool_trace"])


def test_chat_restaurants_intent(client, mock_providers):
    r = client.post("/api/chat", json={"session_id": "pytest-chat-01", "message": "Suggest restaurants in Udaipur"})
    assert r.status_code == 200
    body = r.json()
    assert any(c["kind"] == "restaurants" for c in body["data_cards"])


def test_chat_transport_compare_intent(client, mock_providers):
    r = client.post("/api/chat", json={"session_id": "pytest-chat-01", "message": "Compare train and flight options Delhi to Goa"})
    assert r.status_code == 200
    body = r.json()
    assert any(c["kind"] == "transport" for c in body["data_cards"])
    assert "irctc" in body["reply"].lower() or "provider" in body["reply"].lower()


def test_chat_weather_intent(client, mock_providers):
    r = client.post("/api/chat", json={"session_id": "pytest-chat-01", "message": "Weather in Shimla next week"})
    assert r.status_code == 200
    assert any(c["kind"] == "weather" for c in r.json()["data_cards"])


def test_chat_history_persisted_and_cleared(client, mock_providers):
    client.post("/api/chat", json={"session_id": "pytest-chat-hist", "message": "Hello there"})
    r = client.delete("/api/chat/history/pytest-chat-hist")
    assert r.status_code == 200
    assert r.json()["deleted_messages"] >= 2  # user + assistant


def test_chat_empty_message_rejected(client):
    r = client.post("/api/chat", json={"session_id": "pytest-chat-01", "message": ""})
    assert r.status_code == 422
