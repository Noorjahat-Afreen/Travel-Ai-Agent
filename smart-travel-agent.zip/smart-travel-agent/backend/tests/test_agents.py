"""Agent behaviour tests: itinerary, verification, recommendations, discovery."""
from __future__ import annotations

from datetime import date, timedelta

import pytest

from agents.attraction_agent import AttractionAgent
from agents.budget_agent import BudgetAgent
from agents.destination_agent import DestinationDiscoveryAgent
from agents.hotel_agent import HotelAgent
from agents.itinerary_agent import ItineraryAgent
from agents.recommendation_agent import RecommendationAgent
from agents.verification_agent import VerificationAgent
from schemas.common import PlaceRecord, SourceInfo
from schemas.trip import (
    FoodPreference,
    HotelPreference,
    TransportMode,
    TripRequest,
)


def _request(days=4, interests=("heritage",)) -> TripRequest:
    return TripRequest(
        origin_city="Indore",
        destination_city="Jaipur",
        start_date=date.today() + timedelta(days=10),
        end_date=date.today() + timedelta(days=10 + days - 1),
        travellers=2,
        budget_inr=50000,
        transport_mode=TransportMode.train,
        interests=list(interests),
        hotel_preference=HotelPreference.any,
        food_preference=FoodPreference.any,
    )


def _place(name="Amber Fort", lat=26.9, lon=75.8, distance=2.0, source="OpenStreetMap Overpass") -> PlaceRecord:
    return PlaceRecord(
        name=name, category="attraction", lat=lat, lon=lon, city="Jaipur",
        distance_km=distance, types=["attraction"], source=SourceInfo(name=source, url="https://test"),
        map_link="https://map", directions_link="https://dir",
    )


# ------------------------------------------------------------------ itinerary
def test_itinerary_day_count_and_first_last_titles():
    agent = ItineraryAgent()
    req = _request(days=4)
    attractions = [_place(f"Attr {i}", distance=1.0 + i) for i in range(5)]
    plan = agent.generate(req, 26.9, 75.8, attractions)
    assert len(plan) == 4
    assert "Arrival" in plan[0].title and "Jaipur" in plan[0].title
    assert "Departure" in plan[-1].title and "Indore" in plan[-1].title
    assert [d.day_number for d in plan] == [1, 2, 3, 4]


def test_itinerary_never_invents_clock_times():
    agent = ItineraryAgent()
    plan = agent.generate(_request(days=3), 26.9, 75.8, [_place(), _place("City Palace", distance=3)])
    for day in plan:
        for act in day.activities:
            assert not any(ch.isdigit() for ch in act.period)
            assert "Confirm opening hours" in act.note


def test_itinerary_geographic_ordering():
    agent = ItineraryAgent()
    far = _place("Far Place", lat=27.6, lon=76.8, distance=95.0)
    near = _place("Near Place", lat=26.95, lon=75.85, distance=2.0)
    mid = _place("Mid Place", lat=27.1, lon=76.0, distance=25.0)
    plan = agent.generate(_request(days=5), 26.9, 75.8, [far, mid, near])
    scheduled = [a.place_name for d in plan for a in d.activities if a.place_name]
    assert scheduled.index("Near Place") < scheduled.index("Mid Place") < scheduled.index("Far Place")


def test_itinerary_empty_data_is_honest():
    agent = ItineraryAgent()
    plan = agent.generate(_request(days=2), 26.9, 75.8, [])
    assert agent.status.degraded
    assert len(plan) == 2


# ------------------------------------------------------------------ verification
def test_verification_flags_missing_source_and_out_of_bounds():
    bad = PlaceRecord(name="No Source", lat=26.9, lon=75.8, source=SourceInfo(name=""))
    wild = PlaceRecord(name="Wild Coords", lat=999, lon=-999, source=SourceInfo(name="test"))
    report = VerificationAgent().verify([bad, wild], [], [], [], [])
    kinds = {i.kind for i in report.issues}
    assert "missing_source" in kinds or "suspicious" in kinds
    assert report.all_sourced is False


def test_verification_clean_plan_passes():
    ok = _place(source="OpenStreetMap Overpass")
    report = VerificationAgent().verify([ok], [], [], [], [])
    assert report.checked_records == 1
    assert report.all_sourced is True
    assert report.issues == []


# ------------------------------------------------------------------ recommendations
def test_recommendation_reasons_present_and_veg_priority():
    veg = PlaceRecord(name="Veg Place", lat=26.9, lon=75.8, cuisine="north_indian", vegetarian=True,
                      distance_km=1.0, source=SourceInfo(name="OSM"))
    meat = PlaceRecord(name="Meat Place", lat=26.9, lon=75.8, cuisine="mughlai", vegetarian=False,
                       distance_km=2.0, source=SourceInfo(name="OSM"))
    result = RecommendationAgent().recommend(
        _request(),
        [_place("Hotel One", distance=1.0)],
        [meat, veg],
        [_place("Attr One", distance=1.0)],
    )
    assert len(result.restaurants) == 2
    assert result.restaurants[0].record.name == "Veg Place"
    assert "vegetarian" in result.restaurants[0].reason.lower()
    assert all(item.reason.strip() for item in result.restaurants + result.hotels + result.attractions)


def test_recommendation_interest_matching():
    heritage = _place("Heritage Palace", distance=1.0)
    heritage.types = ["historic", "palace"]
    random = _place("Zoo", distance=1.0)
    result = RecommendationAgent().recommend(_request(interests=("heritage",)), [], [], [random, heritage])
    assert result.attractions[0].record.name == "Heritage Palace"
    assert "interests" in result.attractions[0].reason.lower()


# ------------------------------------------------------------------ discovery / hotels
async def test_destination_agent_builds_city_profile(fake_geo, monkeypatch):
    from services import nominatim, wikipedia

    async def fake_geo_city(city):
        return fake_geo

    async def fake_summary(title):
        return {"title": title, "extract": f"{title} is a city in Rajasthan.",
                "url": f"https://en.wikipedia.org/wiki/{title}", "thumbnail": None, "source": "Wikipedia (CC BY-SA)"}

    monkeypatch.setattr(nominatim, "geocode_city", fake_geo_city)
    monkeypatch.setattr(wikipedia, "summary", fake_summary)

    info, curated = await DestinationDiscoveryAgent().run("Jaipur")
    assert info is not None
    assert info.name.lower() == "jaipur"          # city name, not a POI name
    assert info.state == "Rajasthan"
    assert "Jaipur" in info.description
    assert info.wiki_url.startswith("https://en.wikipedia.org")


async def test_destination_agent_fails_honestly_when_unfound(monkeypatch):
    from services import nominatim

    async def fail(city):
        return None

    monkeypatch.setattr(nominatim, "geocode_city", fail)
    info, curated = await DestinationDiscoveryAgent().run("Nowhereville")
    assert info is None
    assert curated == []


async def test_hotel_agent_normalises_records(monkeypatch):
    from services import overpass

    async def fake(lat, lon, category, radius_km=None, limit=40):
        assert category == "hotel"
        return (
            [
                {"lat": lat + 0.01, "lon": lon + 0.01, "type": "node",
                 "tags": {"name": "Hotel Test", "tourism": "hotel", "website": "hoteltest.com", "stars": "3"}},
                {"lat": lat + 0.02, "lon": lon + 0.02, "type": "node", "tags": {"tourism": "hotel"}},  # unnamed -> dropped
            ],
            "OpenStreetMap Overpass (test)",
        )

    monkeypatch.setattr(overpass, "search_pois", fake)
    records = await HotelAgent().run("Jaipur", 26.9, 75.8)
    assert len(records) == 1
    assert records[0].name == "Hotel Test"
    assert records[0].stars == 3
    assert records[0].website == "https://hoteltest.com"
    assert records[0].source.name == "OpenStreetMap Overpass (test)"
    assert records[0].booking_links[0].label == "Book Hotel Now"


async def test_attraction_agent_merges_curated_and_live(mock_providers):
    agent = AttractionAgent()
    from services import india_reference

    curated = india_reference.find_curated("Jaipur")
    records = await agent.run("Jaipur", 26.9, 75.8, curated=curated)
    names = {r.name for r in records}
    assert any("Hawa Mahal" in n for n in names)
    assert any(n.startswith("Test Attraction") for n in names)
    for r in records:
        assert r.source.name
