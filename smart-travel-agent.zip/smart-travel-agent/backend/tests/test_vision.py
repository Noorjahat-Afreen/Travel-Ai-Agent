"""Vision module tests: OpenCV pipeline, validation, uncertainty behaviour."""
from __future__ import annotations

import base64

import cv2
import numpy as np
import pytest

from agents.vision_agent import ImageValidationError, VisionAgent


def _image_bytes(width=640, height=480) -> bytes:
    img = np.zeros((height, width, 3), dtype=np.uint8)
    cv2.rectangle(img, (50, 50), (width - 50, height - 50), (140, 90, 40), -1)
    cv2.circle(img, (width // 2, height // 2), 80, (200, 120, 60), -1)
    ok, buf = cv2.imencode(".jpg", img)
    assert ok
    return buf.tobytes()


def test_preprocess_produces_features_and_images():
    agent = VisionAgent()
    processed, features, image = agent.preprocess(_image_bytes())
    assert features.width == 640 and features.height == 480
    assert 0 <= features.edge_density <= 1
    assert features.brightness >= 0
    assert features.sharpness > 0
    assert len(features.dominant_colors) == 4
    assert all(c.startswith("#") for c in features.dominant_colors)
    for key in ("original", "grayscale", "edges"):
        assert processed.model_dump()[key].startswith("data:image/")


def test_large_image_is_resized():
    agent = VisionAgent()
    _, features, _ = agent.preprocess(_image_bytes(width=2400, height=1800))
    assert max(features.width, features.height) == 1024


def test_invalid_mime_rejected():
    agent = VisionAgent()
    with pytest.raises(ImageValidationError):
        agent.validate(_image_bytes(), "image/gif")


def test_empty_image_rejected():
    agent = VisionAgent()
    with pytest.raises(ImageValidationError):
        agent.validate(b"", "image/jpeg")


def test_corrupt_image_rejected():
    agent = VisionAgent()
    with pytest.raises(ImageValidationError):
        agent.preprocess(b"not-an-image")


async def test_identify_without_key_is_honest():
    agent = VisionAgent()
    result = await agent.identify(_image_bytes(), "image/jpeg")
    assert result.identified is False
    assert "GEMINI_API_KEY" in result.note
    assert agent.status.degraded


async def test_low_confidence_landmark_is_not_shown():
    """With a stubbed vision model returning low confidence, the agent must not guess."""
    import agents.vision_agent as va

    async def fake_low_confidence(image_bytes, mime_type, hints=""):
        return {"landmark": "Maybe Taj Mahal", "city": "", "state": "", "country": "India",
                "confidence": 0.2, "rationale": "unsure"}

    original_identify = va.identify_landmark
    original_model = va.get_chat_model
    va.identify_landmark = fake_low_confidence
    va.get_chat_model = lambda: object()  # pretend a model is configured
    try:
        agent = VisionAgent()
        result = await agent.identify(_image_bytes(), "image/jpeg")
        assert result.identified is False
        assert result.confidence == pytest.approx(0.2)
        assert "not identify" in result.note
    finally:
        va.identify_landmark = original_identify
        va.get_chat_model = original_model


def test_vision_endpoint_invalid_upload(client):
    r = client.post("/api/vision/analyze",
                    files={"image": ("x.txt", b"hello", "text/plain")})
    assert r.status_code == 422
    assert "unsupported image type" in r.json()["detail"]


def test_vision_endpoint_local_mode(client):
    r = client.post("/api/vision/analyze",
                    files={"image": ("test.jpg", _image_bytes(), "image/jpeg")})
    assert r.status_code == 200
    body = r.json()
    assert body["ai_mode"] == "local"
    assert body["landmark"]["identified"] is False
    assert body["features"]["width"] == 640
    assert body["processed"]["original"].startswith("data:image/jpeg")
    assert any("never guesses" in n for n in body["notes"])
