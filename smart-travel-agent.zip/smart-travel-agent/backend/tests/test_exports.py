"""Export service tests: CSV and Excel content integrity."""
from __future__ import annotations

import io

import openpyxl

from schemas.common import PlaceRecord, SourceInfo
from schemas.trip import (
    BudgetBreakdown,
    BudgetCategory,
    ItineraryActivity,
    ItineraryDay,
    TripOverview,
)
from datetime import date, datetime

from services.export_service import to_csv_bytes, to_xlsx_bytes


def _plan():
    overview = TripOverview(
        origin_city="Indore", destination_city="Jaipur",
        start_date=date(2026, 12, 10), end_date=date(2026, 12, 12),
        days=3, nights=2, travellers=2, budget_inr=30000, budget_per_person_inr=15000,
        transport_mode="train", trip_type="heritage",
    )
    src = SourceInfo(name="OpenStreetMap Overpass", url="https://test")
    place = PlaceRecord(name="Test Hotel", lat=26.9, lon=75.8, city="Jaipur", source=src)
    itinerary = [
        ItineraryDay(
            day_number=1, date=date(2026, 12, 10), title="Arrival",
            activities=[ItineraryActivity(period="Morning", title="Travel", place_name=None)],
        )
    ]
    from datetime import datetime as dt

    from schemas.trip import TripPlanResponse

    return TripPlanResponse(
        trip_id=1,
        title="Indore → Jaipur",
        overview=overview,
        hotels=[place],
        itinerary=itinerary,
        budget=BudgetBreakdown(
            total_estimated_inr=10000, per_person_inr=5000, within_budget=True, user_budget_inr=30000,
            categories=[BudgetCategory(category="Hotel", estimated_inr=5000)],
            assumptions=["Test assumption"],
        ),
        generated_at=dt(2026, 11, 24, 10, 0, 0),
    )


def test_csv_contains_sections():
    content = to_csv_bytes(_plan()).decode()
    assert "=== OVERVIEW ===" in content
    assert "=== ITINERARY ===" in content
    assert "Indore" in content
    assert "Jaipur" in content


def test_xlsx_has_all_sheets_and_data():
    data = to_xlsx_bytes(_plan())
    wb = openpyxl.load_workbook(io.BytesIO(data))
    expected = {"Overview", "Itinerary", "Budget", "Hotels", "Restaurants", "Attractions", "Weather", "Transport", "Verification"}
    assert expected <= set(wb.sheetnames)
    ws = wb["Hotels"]
    rows = list(ws.iter_rows(values_only=True))
    assert rows[0][0] == "Name"
    assert any("Test Hotel" == (r[0] if r else None) for r in rows[1:])
    ws_b = wb["Budget"]
    assert any("Hotel" == (r[0] if r else None) for r in ws_b.iter_rows(values_only=True))


def test_xlsx_is_valid_zip():
    data = to_xlsx_bytes(_plan())
    assert data[:2] == b"PK"  # zip magic bytes
