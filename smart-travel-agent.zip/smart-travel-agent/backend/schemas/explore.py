"""Explore-India schemas."""
from __future__ import annotations

from pydantic import BaseModel, Field


class ExploreDestination(BaseModel):
    key: str
    name: str
    city: str
    state: str
    lat: float
    lon: float
    tags: list[str] = Field(default_factory=list)
    blurb: str = ""
    wiki_url: str = ""
    image_key: str = ""
    category: str = "popular"   # popular|historical|hill-station|beach|religious|nature


class StateGroup(BaseModel):
    state: str
    destinations: list[ExploreDestination]


class ExploreSearchResult(BaseModel):
    query: str
    matched_destination: ExploreDestination | None = None
    geocoded_name: str = ""
    state: str = ""
    lat: float | None = None
    lon: float | None = None
    description: str | None = None
    wiki_url: str = ""
    source: str = ""
    curated_alternatives: list[ExploreDestination] = Field(default_factory=list)
