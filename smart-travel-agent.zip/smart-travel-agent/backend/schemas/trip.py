"""Trip planning request/response schemas."""
from __future__ import annotations

from datetime import date, datetime
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from core.config import settings
from schemas.common import (
    AgentStatus,
    BookingLink,
    PlaceRecord,
    RecommendationSet,
    SourceInfo,
    VerificationReport,
)


class TransportMode(str, Enum):
    train = "train"
    bus = "bus"
    flight = "flight"
    car = "car"
    any_mode = "any"


class TripType(str, Enum):
    leisure = "leisure"
    family = "family"
    adventure = "adventure"
    religious = "religious"
    honeymoon = "honeymoon"
    business = "business"
    heritage = "heritage"


class HotelPreference(str, Enum):
    any = "any"
    budget = "budget"
    mid_range = "mid-range"
    luxury = "luxury"
    homestay = "homestay"


class FoodPreference(str, Enum):
    any = "any"
    vegetarian = "vegetarian"
    vegan = "vegan"
    local = "local"
    continental = "continental"


class TripRequest(BaseModel):
    origin_city: str = Field(min_length=2, max_length=100)
    destination_city: str = Field(min_length=2, max_length=100)
    start_date: date
    end_date: date
    travellers: int = Field(default=2, ge=1, le=20)
    budget_inr: float = Field(default=30000, ge=1000, le=10_000_000)
    transport_mode: TransportMode = TransportMode.any_mode
    trip_type: TripType = TripType.leisure
    interests: list[str] = Field(default_factory=list)
    hotel_preference: HotelPreference = HotelPreference.any
    food_preference: FoodPreference = FoodPreference.any
    session_id: str | None = None
    save_plan: bool = True

    @field_validator("origin_city", "destination_city")
    @classmethod
    def strip_city(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("city name must not be empty")
        return v

    @model_validator(mode="after")
    def validate_dates(self) -> "TripRequest":
        today = date.today()
        if self.end_date < self.start_date:
            raise ValueError("return date must be on or after the departure date")
        if self.start_date < today:
            raise ValueError("departure date cannot be in the past")
        if (self.end_date - self.start_date).days + 1 > settings.max_trip_days:
            raise ValueError(f"trip duration cannot exceed {settings.max_trip_days} days")
        return self

    @property
    def days(self) -> int:
        return (self.end_date - self.start_date).days + 1

    @property
    def nights(self) -> int:
        return max((self.end_date - self.start_date).days, 0)


class TripOverview(BaseModel):
    origin_city: str
    destination_city: str
    start_date: date
    end_date: date
    days: int
    nights: int
    travellers: int
    budget_inr: float
    budget_per_person_inr: float
    transport_mode: str
    trip_type: str


class DestinationInfo(BaseModel):
    name: str
    city: str
    state: str = ""
    country: str = "India"
    lat: float
    lon: float
    description: str | None = None
    wiki_url: str | None = None
    source: SourceInfo


class BudgetCategory(BaseModel):
    category: str
    estimated_inr: float
    note: str = ""
    is_estimate: bool = True


class BudgetBreakdown(BaseModel):
    total_estimated_inr: float
    per_person_inr: float
    within_budget: bool
    user_budget_inr: float
    categories: list[BudgetCategory]
    assumptions: list[str]
    disclaimer: str = (
        "All amounts are algorithmic estimates, NOT supplier prices. "
        "Confirm real prices on provider websites via the booking links."
    )


class WeatherDay(BaseModel):
    date: date
    temp_min_c: float | None = None
    temp_max_c: float | None = None
    precipitation_probability: float | None = None
    precipitation_mm: float | None = None
    condition: str = ""
    source: SourceInfo


class TransportOptionOut(BaseModel):
    mode: str
    provider: str
    summary: str
    detail: str | None = None
    deep_link: str
    origin_city: str = ""
    destination_city: str = ""
    travel_date: date | None = None
    is_estimate: bool = False
    estimated_cost_inr: float | None = None
    notes: str | None = None
    source: SourceInfo
    booking_links: list[BookingLink] = Field(default_factory=list)


class ItineraryActivity(BaseModel):
    period: str          # Morning / Afternoon / Evening - never fabricated clock times
    title: str
    description: str = ""
    place_name: str | None = None
    lat: float | None = None
    lon: float | None = None
    map_link: str = ""
    note: str = "Suggested order only. Confirm opening hours and timings with the venue or provider."


class ItineraryDay(BaseModel):
    day_number: int
    date: date
    title: str
    theme: str = ""
    activities: list[ItineraryActivity]
    travel_note: str | None = None
    is_ai_generated: bool = False


class TripPlanResponse(BaseModel):
    trip_id: int | None = None
    title: str = ""
    ai_mode: str = "local"                    # "gemini" | "local"
    overview: TripOverview
    destination_info: DestinationInfo | None = None
    transport_options: list[TransportOptionOut] = Field(default_factory=list)
    hotels: list[PlaceRecord] = Field(default_factory=list)
    restaurants: list[PlaceRecord] = Field(default_factory=list)
    attractions: list[PlaceRecord] = Field(default_factory=list)
    weather: list[WeatherDay] = Field(default_factory=list)
    weather_available: bool = True
    weather_note: str = ""
    budget: BudgetBreakdown
    itinerary: list[ItineraryDay] = Field(default_factory=list)
    recommendations: RecommendationSet = Field(default_factory=RecommendationSet)
    verification: VerificationReport = Field(default_factory=VerificationReport)
    agent_statuses: list[AgentStatus] = Field(default_factory=list)
    map_center: dict = Field(default_factory=dict)
    saved: bool = False
    notes: list[str] = Field(default_factory=list)
    generated_at: datetime = Field(default_factory=datetime.now)


class TripPlanSummary(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    origin_city: str
    destination_city: str
    start_date: date
    end_date: date
    travellers: int
    budget_inr: float
    transport_mode: str
    status: str
    ai_mode: str
    created_at: datetime


class TripUpdateIn(BaseModel):
    title: str | None = None
    status: str | None = Field(default=None, pattern="^(planned|completed|archived)$")
