"""Shared Pydantic schemas: sources, agent status, places, booking links."""
from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field

MISSING = "details unavailable in collected data"


class SourceInfo(BaseModel):
    """Attribution for every collected record."""

    name: str
    url: str = ""
    retrieved_at: datetime | None = None


class BookingLink(BaseModel):
    """Actionable external link. The app never claims a booking is completed."""

    label: str
    url: str
    provider: str
    kind: Literal["hotel", "train", "bus", "flight", "car", "map", "website", "info"]


class AgentStatus(BaseModel):
    """Transparency: what each specialised agent actually returned."""

    agent: str
    status: Literal["ok", "degraded", "error", "skipped"] = "ok"
    message: str = ""
    degraded: bool = False


class PlaceRecord(BaseModel):
    """Normalised record for any point of interest (hotel/restaurant/attraction/destination)."""

    name: str
    category: str = ""                      # hotel / guest_house / restaurant / cafe / attraction / ...
    lat: float
    lon: float
    city: str = ""
    address: str | None = None
    description: str | None = None
    cuisine: str | None = None
    vegetarian: bool | None = None
    website: str | None = None
    phone: str | None = None
    price_level: int | None = None          # 1..4 when tagged by the provider
    stars: int | None = None                # when tagged by the provider
    types: list[str] = Field(default_factory=list)
    distance_km: float | None = None
    source: SourceInfo
    map_link: str = ""
    directions_link: str = ""
    booking_links: list[BookingLink] = Field(default_factory=list)


class RecommendationItem(BaseModel):
    record: PlaceRecord
    reason: str


class RecommendationSet(BaseModel):
    hotels: list[RecommendationItem] = Field(default_factory=list)
    restaurants: list[RecommendationItem] = Field(default_factory=list)
    attractions: list[RecommendationItem] = Field(default_factory=list)


class VerificationIssue(BaseModel):
    record: str
    kind: str                 # missing_source | missing_field | suspicious | note
    detail: str


class VerificationReport(BaseModel):
    checked_records: int = 0
    issues: list[VerificationIssue] = Field(default_factory=list)
    all_sourced: bool = True
    summary: str = ""


def osm_place_link(lat: float, lon: float, name: str = "") -> str:
    q = f"{name} {lat} {lon}" if name else f"{lat} {lon}"
    return f"https://www.openstreetmap.org/?mlat={lat}&mlon={lon}#map=17/{lat}/{lon}"


def directions_link(lat: float, lon: float, origin: str = "") -> str:
    from urllib.parse import quote

    dest = f"{lat},{lon}"
    if origin:
        return f"https://www.google.com/maps/dir/?api=1&origin={quote(origin)}&destination={dest}"
    return f"https://www.google.com/maps/dir/?api=1&destination={dest}"
