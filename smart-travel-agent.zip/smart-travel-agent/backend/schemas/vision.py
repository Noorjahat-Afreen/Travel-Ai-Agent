"""Computer-vision landmark analysis schemas."""
from __future__ import annotations

from pydantic import BaseModel, Field

from schemas.common import PlaceRecord, SourceInfo


class LandmarkResult(BaseModel):
    identified: bool
    landmark: str = ""
    confidence: float | None = None     # 0..1 when the AI model provides it
    city: str = ""
    state: str = ""
    country: str = "India"
    rationale: str = ""
    note: str = ""


class ProcessedImages(BaseModel):
    original: str            # base64 data URI
    grayscale: str
    edges: str               # Canny edge map


class ImageFeatures(BaseModel):
    width: int
    height: int
    edge_density: float      # fraction of edge pixels (0..1)
    brightness: float        # mean 0..255
    contrast: float          # stddev
    sharpness: float         # variance of Laplacian
    dominant_colors: list[str] = Field(default_factory=list)


class VisionAnalysisResponse(BaseModel):
    ai_mode: str                                  # gemini | local
    landmark: LandmarkResult
    description: str | None = None
    wiki_url: str | None = None
    source: SourceInfo | None = None
    processed: ProcessedImages
    features: ImageFeatures
    nearby_hotels: list[PlaceRecord] = Field(default_factory=list)
    nearby_restaurants: list[PlaceRecord] = Field(default_factory=list)
    nearby_attractions: list[PlaceRecord] = Field(default_factory=list)
    map_link: str = ""
    notes: list[str] = Field(default_factory=list)
