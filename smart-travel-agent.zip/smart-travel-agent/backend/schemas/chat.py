"""Chatbot schemas."""
from __future__ import annotations

from pydantic import BaseModel, Field

from schemas.common import SourceInfo


class ChatMessageIn(BaseModel):
    session_id: str = Field(min_length=6, max_length=64)
    message: str = Field(min_length=1, max_length=2000)


class DataCard(BaseModel):
    """Structured real-data cards rendered by the UI alongside the reply."""

    title: str
    kind: str  # hotels | restaurants | attractions | weather | transport | budget | itinerary | info
    items: list[dict] = Field(default_factory=list)


class ChatResponse(BaseModel):
    reply: str
    mode: str  # gemini | local
    sources: list[SourceInfo] = Field(default_factory=list)
    data_cards: list[DataCard] = Field(default_factory=list)
    suggestions: list[str] = Field(default_factory=list)
    tool_trace: list[str] = Field(default_factory=list)
    error: str | None = None
