"""FastAPI application entrypoint - AI Smart Travel Agent for India.

Run:  uvicorn main:app --host 0.0.0.0 --port 8000  (from the backend/ folder)
Also serves the built React frontend from ../frontend/dist when present
(single-service deployment, e.g. Render free tier).
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from api.routes import chat, dashboard, exports, explore, health, places, transport, trips, vision, weather
from core.config import FRONTEND_DIST_DIR, settings
from core.logging_conf import configure_logging
from core.rate_limit import RateLimitMiddleware
from database.init_db import init_db

configure_logging()
logger = logging.getLogger("main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    from services.llm import llm_status

    status = llm_status()
    logger.info("Startup complete | AI mode: %s | %s", status["mode"], status["note"])
    from core.http_client import close_client

    yield
    await close_client()
    logger.info("Shutdown complete")


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description=(
        "Multi-agent AI travel planning platform for India. Data sources: OpenStreetMap "
        "(Nominatim + Overpass), Wikipedia, Open-Meteo, OSRM. AI: Google Gemini via LangChain "
        "with graceful local fallback. The app never invents prices or availability."
    ),
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
)

# --- Security & performance middleware -----------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)
app.add_middleware(GZipMiddleware, minimum_size=1024)
app.add_middleware(RateLimitMiddleware)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):  # pragma: no cover
    logger.error("unhandled error on %s: %s - %s", request.url.path, type(exc).__name__, str(exc)[:200])
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error. Please retry; if it persists check backend logs."},
    )


# --- API routes ------------------------------------------------------------
app.include_router(health.router, prefix="/api")
app.include_router(dashboard.router, prefix="/api")
app.include_router(explore.router, prefix="/api")
app.include_router(places.router, prefix="/api")
app.include_router(transport.router, prefix="/api")
app.include_router(weather.router, prefix="/api")
app.include_router(trips.router, prefix="/api")
app.include_router(chat.router, prefix="/api")
app.include_router(vision.router, prefix="/api")
app.include_router(exports.router, prefix="/api")

# --- Static React frontend (single-service deployments) --------------------
if FRONTEND_DIST_DIR.exists():
    assets_dir = FRONTEND_DIST_DIR / "assets"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=assets_dir), name="spa-assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa_fallback(full_path: str):  # pragma: no cover
        """Serve built frontend for client-side routes (SPA fallback)."""
        candidate = FRONTEND_DIST_DIR / full_path
        if full_path and candidate.is_file():
            return FileResponse(candidate)
        return FileResponse(FRONTEND_DIST_DIR / "index.html")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=settings.api_port, reload=False)
