"""AI travel chatbot endpoints."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException

from agents.chat_agent import ChatAgent
from schemas.chat import ChatMessageIn, ChatResponse

router = APIRouter(prefix="/chat", tags=["chat"])


@router.post("", response_model=ChatResponse)
async def chat(payload: ChatMessageIn) -> ChatResponse:
    agent = ChatAgent()
    try:
        return await agent.respond(payload.session_id, payload.message)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"chat pipeline error: {type(exc).__name__}") from exc


@router.delete("/history/{session_id}")
def clear_history(session_id: str) -> dict:
    agent = ChatAgent()
    deleted = agent.clear_history(session_id)
    return {"session_id": session_id, "deleted_messages": deleted}
