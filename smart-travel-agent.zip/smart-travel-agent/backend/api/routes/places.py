"""POI search endpoints: hotels, restaurants, attractions (live collected data)."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, HTTPException, Query

from agents.attraction_agent import AttractionAgent
from agents.hotel_agent import HotelAgent
from agents.restaurant_agent import RestaurantAgent
from services import booking_links, nominatim

router = APIRouter(tags=["places"])


async def _geocode(city: str, lat: float | None, lon: float | None):
    if lat is not None and lon is not None:
        return {"name": city, "lat": lat, "lon": lon, "state": ""}
    geo = await nominatim.geocode_city(city)
    if not geo:
        raise HTTPException(status_code=404, detail=f"Could not geocode '{city}'. Check the spelling or try a nearby city.")
    return geo


@router.get("/hotels")
async def hotels(
    city: str = Query(min_length=2, max_length=80),
    lat: float | None = None,
    lon: float | None = None,
    check_in: date | None = None,
    check_out: date | None = None,
    guests: int = Query(default=2, ge=1, le=20),
    preference: str = Query(default="any"),
):
    geo = await _geocode(city, lat, lon)
    records = await HotelAgent().run(city, geo["lat"], geo["lon"], preference=preference)
    ci = check_in or date.today() + __import__("datetime").timedelta(days=7)
    co = check_out or date.today() + __import__("datetime").timedelta(days=9)
    for r in records:
        r.booking_links = booking_links.hotel_links(city, ci, co, guests)
    return {
        "city": city,
        "center": {"lat": geo["lat"], "lon": geo["lon"]},
        "state": geo.get("state", ""),
        "hotels": [r.model_dump(mode="json") for r in records],
        "booking_links": [l.model_dump() for l in booking_links.hotel_links(city, ci, co, guests)],
    }


@router.get("/restaurants")
async def restaurants(
    city: str = Query(min_length=2, max_length=80),
    lat: float | None = None,
    lon: float | None = None,
    food_preference: str = Query(default="any"),
):
    geo = await _geocode(city, lat, lon)
    records = await RestaurantAgent().run(city, geo["lat"], geo["lon"], food_preference=food_preference)
    return {
        "city": city,
        "center": {"lat": geo["lat"], "lon": geo["lon"]},
        "state": geo.get("state", ""),
        "restaurants": [r.model_dump(mode="json") for r in records],
    }


@router.get("/attractions")
async def attractions(
    city: str = Query(min_length=2, max_length=80),
    lat: float | None = None,
    lon: float | None = None,
    interests: str = Query(default=""),
):
    geo = await _geocode(city, lat, lon)
    interest_list = [i.strip() for i in interests.split(",") if i.strip()]
    records = await AttractionAgent().run(city, geo["lat"], geo["lon"], interests=interest_list)
    await AttractionAgent().enrich_with_wiki(records, limit=3)
    return {
        "city": city,
        "center": {"lat": geo["lat"], "lon": geo["lon"]},
        "state": geo.get("state", ""),
        "attractions": [r.model_dump(mode="json") for r in records],
    }
