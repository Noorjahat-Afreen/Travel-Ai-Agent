"""Explore India - state-wise curated discovery + live search."""
from __future__ import annotations

from fastapi import APIRouter, Query

from schemas.explore import ExploreDestination, ExploreSearchResult, StateGroup
from services import india_reference, nominatim, wikipedia
from services.rag import slug

router = APIRouter(prefix="/explore", tags=["explore"])


def _to_dest(item: dict) -> ExploreDestination:
    return ExploreDestination(
        key=slug(f"{item['name']} {item['city']}"),
        name=item["name"],
        city=item["city"],
        state=item["state"],
        lat=item["lat"],
        lon=item["lon"],
        tags=item.get("tags", []),
        blurb=item["blurb"],
        wiki_url=india_reference.WIKI + item.get("wiki", item["name"].replace(" ", "_")),
        image_key=item.get("image_key", ""),
        category=item.get("category", "popular"),
    )


@router.get("/states", response_model=list[StateGroup])
def states() -> list[StateGroup]:
    groups: dict[str, list[ExploreDestination]] = {}
    for item in india_reference.CURATED_DESTINATIONS:
        groups.setdefault(item["state"], []).append(_to_dest(item))
    return [StateGroup(state=s, destinations=d) for s, d in sorted(groups.items())]


@router.get("/destinations", response_model=list[ExploreDestination])
def destinations(category: str | None = Query(default=None), state: str | None = Query(default=None)) -> list[ExploreDestination]:
    items = india_reference.CURATED_DESTINATIONS
    if category and category != "all":
        items = [i for i in items if i.get("category") == category]
    if state:
        items = [i for i in items if i["state"].lower() == state.lower()]
    return [_to_dest(i) for i in items]


@router.get("/search", response_model=ExploreSearchResult)
async def search(q: str = Query(min_length=2, max_length=80)) -> ExploreSearchResult:
    query = q.strip()
    alternatives: list[ExploreDestination] = []

    matched = None
    for item in india_reference.CURATED_DESTINATIONS:
        if query.lower() in item["city"].lower() or query.lower() in item["name"].lower():
            matched = _to_dest(item)
            break

    if matched:
        state = matched.state
        alternatives = [
            _to_dest(i)
            for i in india_reference.CURATED_DESTINATIONS
            if i["state"] == state and i is not item
        ][:6]
        wiki = await wikipedia.summary(matched.name if matched.name == query or len(query) > 4 else matched.city)
        description = None
        if wiki:
            description = wiki["extract"]
        elif matched.blurb:
            description = matched.blurb
        return ExploreSearchResult(
            query=query,
            matched_destination=matched,
            geocoded_name=matched.city,
            state=state,
            lat=matched.lat,
            lon=matched.lon,
            description=description,
            wiki_url=matched.wiki_url,
            source="Curated reference data + Wikipedia (CC BY-SA)",
            curated_alternatives=alternatives,
        )

    # Live geocoding for anything not in the curated set.
    geo = await nominatim.geocode_city(query)
    wiki = await wikipedia.summary(query)
    if geo is None and wiki is None:
        return ExploreSearchResult(
            query=query,
            description="details unavailable in collected data",
            source="No match in curated data, Nominatim or Wikipedia",
        )
    lat = float(geo["lat"]) if geo else None
    lon = float(geo["lon"]) if geo else None
    state = geo.get("state", "") if geo else ""
    # Nearby curated alternatives in the same state.
    if state:
        alternatives = [_to_dest(i) for i in india_reference.CURATED_DESTINATIONS if i["state"] == state][:6]
    return ExploreSearchResult(
        query=query,
        geocoded_name=(geo or {}).get("name", query),
        state=state,
        lat=lat,
        lon=lon,
        description=wiki["extract"] if wiki else None,
        wiki_url=wiki["url"] if wiki else (geo or {}).get("source_url", ""),
        source=(wiki["source"] if wiki else "OpenStreetMap Nominatim"),
        curated_alternatives=alternatives,
    )
