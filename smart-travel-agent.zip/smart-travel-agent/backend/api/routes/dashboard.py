"""Dashboard statistics - real application data only."""
from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from api.deps import get_db
from models import (
    AIConversation,
    Attraction,
    DataSource,
    Destination,
    Hotel,
    Restaurant,
    SavedRecommendation,
    TravelPlan,
    WeatherRecord,
)
from schemas.trip import TripPlanSummary
from services.llm import llm_status

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/stats")
def stats(db: Session = Depends(get_db)) -> dict:
    def count(model) -> int:
        return int(db.query(func.count(model.id)).scalar() or 0)

    recent = (
        db.query(TravelPlan)
        .order_by(TravelPlan.created_at.desc())
        .limit(6)
        .all()
    )
    providers = db.query(DataSource).all()
    return {
        "plans": count(TravelPlan),
        "destinations": count(Destination),
        "hotels": count(Hotel),
        "restaurants": count(Restaurant),
        "attractions": count(Attraction),
        "weather_records": count(WeatherRecord),
        "conversations": count(AIConversation),
        "saved_recommendations": count(SavedRecommendation),
        "providers": [
            {"name": p.name, "url": p.base_url, "status": p.status, "last_used": p.last_used_at.isoformat() if p.last_used_at else None}
            for p in providers
        ],
        "ai_mode": llm_status()["mode"],
        "recent_trips": [TripPlanSummary.model_validate(t).model_dump(mode="json") for t in recent],
    }
