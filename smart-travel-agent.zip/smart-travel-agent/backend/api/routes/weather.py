"""Weather endpoints (Open-Meteo)."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Query

from agents.weather_agent import WeatherAgent
from services import nominatim

router = APIRouter(prefix="/weather", tags=["weather"])


@router.get("")
async def weather(
    city: str = Query(min_length=2, max_length=80),
    lat: float | None = None,
    lon: float | None = None,
    start: date | None = None,
    end: date | None = None,
):
    from datetime import timedelta

    if lat is None or lon is None:
        geo = await nominatim.geocode_city(city)
        if not geo:
            return {"city": city, "available": False, "days": [], "note": f"Could not geocode '{city}'.", "center": None}
        lat, lon = geo["lat"], geo["lon"]
        state = geo.get("state", "")
    else:
        state = ""

    start = start or date.today()
    end = end or start + timedelta(days=4)
    if end < start:
        end = start

    days, available, note = await WeatherAgent().run(city, lat, lon, start, end)
    return {
        "city": city,
        "state": state,
        "center": {"lat": lat, "lon": lon},
        "available": available,
        "note": note,
        "days": [d.model_dump(mode="json") for d in days],
    }
