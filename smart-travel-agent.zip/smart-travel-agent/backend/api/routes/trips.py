"""Travel plans: generate (multi-agent), list, view, update, delete."""
from __future__ import annotations

import asyncio

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from agents.master_agent import MasterTravelAgent
from api.deps import get_db
from models import SavedRecommendation, TravelPlan
from schemas.common import PlaceRecord, RecommendationSet
from schemas.trip import TripPlanResponse, TripPlanSummary, TripRequest, TripUpdateIn

router = APIRouter(prefix="/trips", tags=["trips"])


@router.post("/plan", response_model=TripPlanResponse)
async def create_plan(request: TripRequest) -> TripPlanResponse:
    """Run the full multi-agent pipeline for a travel request."""
    master = MasterTravelAgent()
    return await master.plan(request)


def _row_to_response(row: TravelPlan) -> TripPlanResponse:
    if not row.plan_json:
        raise HTTPException(status_code=404, detail="Plan snapshot missing for this trip.")
    return TripPlanResponse.model_validate(row.plan_json)


@router.get("", response_model=list[TripPlanSummary])
def list_trips(session_id: str | None = Query(default=None), limit: int = 50, db: Session = Depends(get_db)):
    query = db.query(TravelPlan)
    if session_id:
        query = query.filter(TravelPlan.session_id == session_id)
    rows = query.order_by(TravelPlan.created_at.desc()).limit(limit).all()
    return [TripPlanSummary.model_validate(r) for r in rows]


@router.get("/{trip_id}", response_model=TripPlanResponse)
def get_trip(trip_id: int, db: Session = Depends(get_db)):
    row = db.get(TravelPlan, trip_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Trip not found")
    return _row_to_response(row)


@router.patch("/{trip_id}", response_model=TripPlanSummary)
def update_trip(trip_id: int, payload: TripUpdateIn, db: Session = Depends(get_db)):
    row = db.get(TravelPlan, trip_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Trip not found")
    if payload.title:
        row.title = payload.title
        if row.plan_json:
            row.plan_json["title"] = payload.title
            from sqlalchemy.orm.attributes import flag_modified

            flag_modified(row, "plan_json")
    if payload.status:
        row.status = payload.status
    db.commit()
    db.refresh(row)
    return TripPlanSummary.model_validate(row)


@router.delete("/{trip_id}")
def delete_trip(trip_id: int, db: Session = Depends(get_db)):
    row = db.get(TravelPlan, trip_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Trip not found")
    db.delete(row)
    db.commit()
    return {"deleted": trip_id}


# ---------------------------------------------------------------- saved recommendations
@router.post("/{trip_id}/save-recommendation")
def save_recommendation(trip_id: int, payload: dict, db: Session = Depends(get_db)):
    row = db.get(TravelPlan, trip_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Trip not found")
    rec = SavedRecommendation(
        plan_id=trip_id,
        session_id=row.session_id,
        kind=payload.get("kind", "attraction"),
        ref_name=payload.get("name", ""),
        city=payload.get("city", row.destination_city),
        payload=payload.get("payload", {}),
        note=payload.get("note"),
    )
    db.add(rec)
    db.commit()
    db.refresh(rec)
    return {"id": rec.id, "kind": rec.kind, "name": rec.ref_name}


@router.get("/{trip_id}/recommendations", response_model=list[dict])
def list_recommendations(trip_id: int, db: Session = Depends(get_db)):
    rows = db.query(SavedRecommendation).filter(SavedRecommendation.plan_id == trip_id).all()
    return [
        {"id": r.id, "kind": r.kind, "name": r.ref_name, "city": r.city, "payload": r.payload, "note": r.note}
        for r in rows
    ]
