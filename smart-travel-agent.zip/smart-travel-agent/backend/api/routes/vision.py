"""Computer vision endpoint: upload -> OpenCV pipeline -> landmark recognition."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, File, HTTPException, UploadFile

from agents.vision_agent import ImageValidationError, VisionAgent
from schemas.common import SourceInfo
from schemas.vision import VisionAnalysisResponse
from services import booking_links, data_collector, nominatim, overpass, wikipedia

router = APIRouter(prefix="/vision", tags=["vision"])


@router.post("/analyze", response_model=VisionAnalysisResponse)
async def analyze(image: UploadFile = File(...)) -> VisionAnalysisResponse:
    agent = VisionAgent()
    image_bytes = await image.read()
    try:
        agent.validate(image_bytes, image.content_type or "")
        processed, features, _ = agent.preprocess(image_bytes)
        landmark = await agent.identify(image_bytes, image.content_type or "image/jpeg")
    except ImageValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    notes: list[str] = [
        "OpenCV pipeline: resize -> grayscale -> Gaussian blur -> Canny edges + K-means colour analysis."
    ]
    wiki_url = None
    description = None
    source: SourceInfo | None = None
    center: dict | None = None
    state = ""

    if landmark.identified:
        query = f"{landmark.landmark} {landmark.city}" if landmark.city else landmark.landmark
        wiki = await wikipedia.summary(landmark.landmark)
        if wiki:
            description = wiki["extract"]
            wiki_url = wiki["url"]
            source = SourceInfo(name="Wikipedia (CC BY-SA)", url=wiki["url"])
            notes.append("Historical overview sourced from Wikipedia (CC BY-SA).")
        geo = await nominatim.geocode_place(query)
        if geo:
            center = {"lat": geo["lat"], "lon": geo["lon"]}
            state = geo.get("state", "") or landmark.state
            notes.append("Landmark geocoded with OpenStreetMap Nominatim.")
        elif landmark.city:
            city_geo = await nominatim.geocode_city(landmark.city)
            if city_geo:
                center = {"lat": city_geo["lat"], "lon": city_geo["lon"]}
                state = city_geo.get("state", "")

    nearby_hotels, nearby_restaurants, nearby_attractions = [], [], []
    if center:
        city_label = landmark.city or "nearby landmark"
        hotel_elements, provider_h = await overpass.search_pois(center["lat"], center["lon"], "hotel", 6)
        nearby_hotels = data_collector.normalise_elements(
            hotel_elements, "hotel", city_label, provider_h, center=(center["lat"], center["lon"])
        )[:6]
        for r in nearby_hotels:
            r.booking_links = booking_links.hotel_links(city_label, date.today(), date.today(), 2)[:1]
        rest_elements, provider_r = await overpass.search_pois(center["lat"], center["lon"], "restaurant", 4)
        nearby_restaurants = data_collector.normalise_elements(
            rest_elements, "restaurant", city_label, provider_r, center=(center["lat"], center["lon"])
        )[:6]
        att_elements, provider_a = await overpass.search_pois(center["lat"], center["lon"], "attraction", 8)
        nearby_attractions = data_collector.normalise_elements(
            att_elements, "attraction", city_label, provider_a, center=(center["lat"], center["lon"])
        )[:6]

    map_link = ""
    if center:
        map_link = f"https://www.google.com/maps/search/?api=1&query={center['lat']},{center['lon']}"
    elif landmark.identified:
        map_link = f"https://www.google.com/maps/search/?api=1&query={landmark.landmark}"

    if not landmark.identified:
        notes.append("Uncertainty preserved: the app never guesses landmarks it cannot verify.")

    return VisionAnalysisResponse(
        ai_mode="gemini" if landmark.identified else "local",
        landmark=landmark,
        description=description,
        wiki_url=wiki_url,
        source=source,
        processed=processed,
        features=features,
        nearby_hotels=nearby_hotels,
        nearby_restaurants=nearby_restaurants,
        nearby_attractions=nearby_attractions,
        map_link=map_link,
        notes=notes,
    )
