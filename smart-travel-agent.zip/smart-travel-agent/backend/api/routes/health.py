"""Health & AI status endpoints."""
from __future__ import annotations

from fastapi import APIRouter
from sqlalchemy import text

from core.cache import cache
from core.config import settings
from database.engine import SessionLocal
from services.llm import llm_status
from services.rag import EMBEDDINGS_AVAILABLE, doc_count

router = APIRouter(tags=["health"])


@router.get("/health")
async def health() -> dict:
    db_ok = False
    try:
        with SessionLocal() as db:
            db.execute(text("SELECT 1"))
        db_ok = True
    except Exception:  # noqa: BLE001
        pass
    return {
        "status": "ok" if db_ok else "degraded",
        "app": settings.app_name,
        "version": settings.app_version,
        "database": "connected" if db_ok else "unavailable",
        "ai_mode": llm_status()["mode"],
    }


@router.get("/ai/status")
async def ai_status() -> dict:
    status = llm_status()
    status["rag_documents"] = doc_count()
    status["embeddings_available"] = EMBEDDINGS_AVAILABLE
    status["cache"] = cache.stats()
    return status
