"""CSV / Excel export endpoints for saved trips."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session

from api.deps import get_db
from models import TravelPlan
from schemas.trip import TripPlanResponse
from services.export_service import to_csv_bytes, to_xlsx_bytes

router = APIRouter(prefix="/exports", tags=["exports"])

CSV_MEDIA = "text/csv; charset=utf-8"
XLSX_MEDIA = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def _load_plan(db: Session, trip_id: int) -> TripPlanResponse:
    row = db.get(TravelPlan, trip_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Trip not found")
    if not row.plan_json:
        raise HTTPException(status_code=404, detail="No plan snapshot stored for this trip")
    return TripPlanResponse.model_validate(row.plan_json)


@router.get("/trip/{trip_id}/csv")
def export_csv(trip_id: int, db: Session = Depends(get_db)) -> Response:
    plan = _load_plan(db, trip_id)
    content = to_csv_bytes(plan)
    filename = f"trip-{trip_id}-{plan.overview.destination_city.lower()}.csv"
    return Response(
        content=content,
        media_type=CSV_MEDIA,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/trip/{trip_id}/xlsx")
def export_xlsx(trip_id: int, db: Session = Depends(get_db)) -> Response:
    plan = _load_plan(db, trip_id)
    content = to_xlsx_bytes(plan)
    filename = f"trip-{trip_id}-{plan.overview.destination_city.lower()}.xlsx"
    return Response(
        content=content,
        media_type=XLSX_MEDIA,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
