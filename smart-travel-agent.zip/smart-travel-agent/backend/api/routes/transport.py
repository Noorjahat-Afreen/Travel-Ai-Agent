"""Transport search: provider deep links + road distance estimates."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, HTTPException, Query

from agents.transport_agent import TransportAgent
from schemas.trip import TransportOptionOut
from services import nominatim

router = APIRouter(prefix="/transport", tags=["transport"])


@router.get("/search", response_model=dict)
async def search(
    origin: str = Query(min_length=2, max_length=80),
    destination: str = Query(min_length=2, max_length=80),
    travel_date: date | None = None,
    travellers: int = Query(default=2, ge=1, le=20),
    mode: str = Query(default="any"),
):
    if travel_date is None:
        from datetime import timedelta

        travel_date = date.today() + timedelta(days=7)
    if mode not in ("any", "train", "bus", "flight", "car"):
        raise HTTPException(status_code=422, detail="mode must be one of any|train|bus|flight|car")

    origin_geo = await nominatim.geocode_city(origin)
    dest_geo = await nominatim.geocode_city(destination)
    if dest_geo is None:
        raise HTTPException(status_code=404, detail=f"Could not geocode destination '{destination}'.")
    if origin_geo is None:
        origin_geo = {"lat": None, "lon": None, "name": origin}

    options = await TransportAgent().run(
        origin, destination, travel_date, travellers, mode, origin_geo, dest_geo
    )
    road = None
    if origin_geo.get("lat") and dest_geo.get("lat"):
        from services import osrm

        road = await osrm.road_route(origin_geo["lat"], origin_geo["lon"], dest_geo["lat"], dest_geo["lon"])
    return {
        "origin": origin,
        "destination": destination,
        "travel_date": travel_date.isoformat(),
        "travellers": travellers,
        "road_estimate": road,
        "options": [o.model_dump(mode="json") for o in options],
    }
