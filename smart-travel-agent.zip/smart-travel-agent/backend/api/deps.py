"""Shared FastAPI dependencies."""
from database.engine import get_db  # re-export  # noqa: F401
