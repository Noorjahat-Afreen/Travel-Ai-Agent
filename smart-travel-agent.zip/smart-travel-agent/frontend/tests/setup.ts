import "@testing-library/jest-dom/vitest";

// jsdom lacks IntersectionObserver (used by framer-motion whileInView).
class IOStub implements IntersectionObserver {
  readonly root: Element | null = null;
  readonly rootMargin: string = "";
  readonly thresholds: ReadonlyArray<number> = [];
  observe() {}
  unobserve() {}
  disconnect() {}
  takeRecords(): IntersectionObserverEntry[] {
    return [];
  }
}
if (typeof globalThis.IntersectionObserver === "undefined") {
  globalThis.IntersectionObserver = IOStub as unknown as typeof IntersectionObserver;
}

// jsdom lacks ResizeObserver (used by recharts ResponsiveContainer).
if (typeof globalThis.ResizeObserver === "undefined") {
  globalThis.ResizeObserver = class {
    observe() {}
    unobserve() {}
    disconnect() {}
  } as unknown as typeof ResizeObserver;
}

// jsdom: window.scrollTo is a "Not implemented" error source; stub it.
if (typeof window !== "undefined" && typeof window.scrollTo !== "function") {
  window.scrollTo = () => undefined;
}
Object.defineProperty(window, "scrollTo", { value: () => undefined, writable: true });

// jsdom lacks URL.createObjectURL
if (typeof URL.createObjectURL === "undefined") {
  URL.createObjectURL = (obj: Blob | MediaSource) => `blob:${String(obj).length}`;
}
if (typeof URL.revokeObjectURL === "undefined") {
  URL.revokeObjectURL = () => undefined;
}
