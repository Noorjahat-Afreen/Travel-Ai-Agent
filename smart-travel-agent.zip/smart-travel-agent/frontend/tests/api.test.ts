import { describe, expect, it } from "vitest";
import { api, getSessionId } from "@/services/api";
import { categoryStyle, photoFor } from "@/services/images";

describe("api client URL builder", () => {
  it("builds same-origin URLs with query params", () => {
    expect(api.exportCsvUrl(5)).toBe("/api/exports/trip/5/csv");
  });

  it("escapes and skips empty params (URL builder sanity)", () => {
    // Verify the endpoint helpers exist without performing network calls.
    expect(typeof api.exploreDestinations).toBe("function");
    expect(typeof api.transportSearch).toBe("function");
    expect(typeof api.weather).toBe("function");
  });
});

describe("session id", () => {
  it("persists a session id in localStorage", () => {
    const first = getSessionId();
    expect(first).toMatch(/^web-/);
    expect(getSessionId()).toBe(first);
  });
});

describe("image resolution", () => {
  it("maps known keys to bundled photos", () => {
    expect(photoFor("jaipur")).toBe("/images/jaipur-hawa-mahal.jpg");
    expect(photoFor("agra-taj-mahal")).toBe("/images/taj-mahal.jpg");
  });

  it("returns null for unknown keys so UI can fall back to a gradient", () => {
    expect(photoFor("nonexistent-place")).toBeNull();
  });

  it("provides themed fallback styles per category", () => {
    const beach = categoryStyle("beach");
    expect(beach.gradient).toContain("from-");
    expect(beach.emoji).toBeTruthy();
    expect(categoryStyle("unknown")?.gradient).toBeTruthy();
  });
});

describe("trip request validation (mirror of backend rules)", () => {
  const base = {
    origin_city: "Indore",
    destination_city: "Jaipur",
    start_date: "2026-12-10",
    end_date: "2026-12-13",
    travellers: 2,
    budget_inr: 40000,
    transport_mode: "train" as const,
    trip_type: "heritage",
    interests: ["heritage"],
    hotel_preference: "mid-range",
    food_preference: "vegetarian",
  };

  it("accepts a valid payload", () => {
    expect(base.start_date < base.end_date).toBe(true);
  });

  it("rejects end before start locally (mirrors backend 422)", () => {
    const bad = { ...base, start_date: "2026-12-20", end_date: "2026-12-10" };
    expect(new Date(bad.end_date) < new Date(bad.start_date)).toBe(true);
  });

  it("bounds travellers 1..20", () => {
    expect(Math.max(1, Math.min(20, 0))).toBe(1);
    expect(Math.max(1, Math.min(20, 99))).toBe(20);
  });
});
