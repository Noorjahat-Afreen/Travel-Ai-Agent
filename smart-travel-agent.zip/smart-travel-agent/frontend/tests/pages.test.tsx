import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter } from "react-router-dom";
import { beforeEach, describe, expect, it, vi } from "vitest";
import Home from "@/pages/Home";
import TripPlanner from "@/pages/TripPlanner";
import { TripPrefillProvider } from "@/context/TripPrefillContext";

// Mock the api module so tests never touch the network.
vi.mock("@/services/api", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/services/api")>();
  return {
    ...actual,
    api: {
      ...actual.api,
      dashboardStats: vi.fn().mockResolvedValue({
        plans: 2,
        destinations: 102,
        hotels: 60,
        restaurants: 60,
        attractions: 50,
        weather_records: 10,
        conversations: 5,
        saved_recommendations: 0,
        providers: [],
        ai_mode: "local",
        recent_trips: [],
      }),
      planTrip: vi.fn().mockResolvedValue({
        trip_id: 1,
        title: "Indore → Jaipur (4 days)",
        ai_mode: "local",
        overview: {
          origin_city: "Indore", destination_city: "Jaipur", start_date: "2026-12-10",
          end_date: "2026-12-13", days: 4, nights: 3, travellers: 2, budget_inr: 40000,
          budget_per_person_inr: 20000, transport_mode: "train", trip_type: "heritage",
        },
        destination_info: { name: "Jaipur", city: "Jaipur", state: "Rajasthan", country: "India", lat: 26.9, lon: 75.8, description: "Pink City", wiki_url: "https://en.wikipedia.org/wiki/Jaipur", source: { name: "Wikipedia", url: "" } },
        transport_options: [],
        hotels: [], restaurants: [], attractions: [],
        weather: [], weather_available: false, weather_note: "no forecast",
        budget: {
          total_estimated_inr: 20000, per_person_inr: 10000, within_budget: true, user_budget_inr: 40000,
          categories: [{ category: "Hotel", estimated_inr: 8000, note: "", is_estimate: true }],
          assumptions: [], disclaimer: "estimates",
        },
        itinerary: [], recommendations: { hotels: [], restaurants: [], attractions: [] },
        verification: { checked_records: 5, issues: [], all_sourced: true, summary: "clean" },
        agent_statuses: [{ agent: "Master Travel Agent", status: "ok", message: "done", degraded: false }],
        map_center: { lat: 26.9, lon: 75.8, name: "Jaipur" },
        saved: true, notes: [], generated_at: new Date().toISOString(),
      }),
    },
  };
});

function renderWithProviders(ui: React.ReactElement, { route = "/" } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <TripPrefillProvider>{ui}</TripPrefillProvider>
    </MemoryRouter>,
  );
}

describe("Home page", () => {
  it("renders hero and starts planning with prefilled cities", async () => {
    renderWithProviders(<Home />);
    expect(screen.getByRole("heading", { level: 1 })).toHaveTextContent(/Plan your entire India trip/i);
    // Destination input exists
    const destInput = screen.getByLabelText("Destination city");
    expect(destInput).toBeInTheDocument();
    await userEvent.type(destInput, "Udaipur");
    await userEvent.click(screen.getByRole("button", { name: /Explore/i }));
    // Navigation occurs (button triggers prefill + navigate) - input keeps value
    expect(destInput).toHaveValue("Udaipur");
  });

  it("shows live database statistics", async () => {
    renderWithProviders(<Home />);
    await waitFor(() => expect(screen.getByText("102")).toBeInTheDocument());
    expect(screen.getByText(/Destinations indexed/i)).toBeInTheDocument();
  });
});

describe("Trip Planner page", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders the planning form with default values", () => {
    renderWithProviders(<TripPlanner />, { route: "/trip-planner" });
    expect(screen.getByLabelText("Starting city")).toHaveValue("Indore");
    expect(screen.getByLabelText(/Destination/)).toHaveValue("Jaipur");
    expect(screen.getByRole("button", { name: /Generate Complete Trip Plan/i })).toBeInTheDocument();
  });

  it("submits the form and shows the plan overview", async () => {
    renderWithProviders(<TripPlanner />, { route: "/trip-planner" });
    await userEvent.click(screen.getByRole("button", { name: /Generate Complete Trip Plan/i }));
    await waitFor(() => expect(screen.getByText(/Trip Overview/i)).toBeInTheDocument());
    expect(screen.getByText("Indore → Jaipur (4 days)")).toBeInTheDocument();
  });

  it("rejects a return date before the departure date client-side", async () => {
    renderWithProviders(<TripPlanner />, { route: "/trip-planner" });
    const dep = screen.getByLabelText(/Departure date/i);
    const ret = screen.getByLabelText(/Return date/i);
    expect((ret as HTMLInputElement).min).toBe((dep as HTMLInputElement).value);
  });
});
