/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Official project palette (see project spec / About page)
        navy: {
          DEFAULT: "#102A43",
          soft: "#1B3B57",
          muted: "#3E5C76",
        },
        deepsea: "#174F67",
        teal: {
          DEFAULT: "#167D78",
          light: "#2AA198",
          dark: "#0F5F5B",
        },
        ink: "#182B3A",
        mist: "#F5F8FC",
        sand: "#EEF3F9",
      },
      fontFamily: {
        sans: [
          "Inter",
          "Segoe UI",
          "system-ui",
          "-apple-system",
          "Helvetica Neue",
          "Arial",
          "sans-serif",
        ],
        display: ["Georgia", "Cambria", "Times New Roman", "serif"],
      },
      boxShadow: {
        card: "0 2px 12px rgba(16, 42, 67, 0.08)",
        "card-hover": "0 10px 28px rgba(16, 42, 67, 0.16)",
        hero: "0 24px 64px rgba(16, 42, 67, 0.45)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-400px 0" },
          "100%": { backgroundPosition: "400px 0" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.5s ease-out both",
        shimmer: "shimmer 1.6s linear infinite",
      },
    },
  },
  plugins: [],
};
