/**
 * Central API client.
 *
 * - Local development: Vite proxies /api -> http://localhost:8000 (see vite.config.ts).
 * - Hosted gateway deployments: set VITE_API_GATEWAY_PORT so every request
 *   carries ?XTransformPort=<port> (used by reverse-proxy gateways that route
 *   by query param). Unset in normal local usage - requests stay same-origin.
 */
import type {
  ChatResponse,
  DashboardStats,
  ExploreDestination,
  ExploreSearchResult,
  TripPlanResponse,
  TripPlanSummary,
  TripRequest,
  VisionAnalysis,
} from "@/types";

const GATEWAY_PORT = (import.meta.env.VITE_API_GATEWAY_PORT as string | undefined) ?? "";
const BASE = "/api";

function buildUrl(path: string, params?: Record<string, string | number | undefined>): string {
  const search = new URLSearchParams();
  for (const [k, v] of Object.entries(params ?? {})) {
    if (v !== undefined && v !== null && v !== "") search.set(k, String(v));
  }
  if (GATEWAY_PORT) search.set("XTransformPort", GATEWAY_PORT);
  const qs = search.toString();
  return `${BASE}${path}${qs ? `?${qs}` : ""}`;
}

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, options: RequestInit = {}, params?: Record<string, string | number | undefined>): Promise<T> {
  const response = await fetch(buildUrl(path, params), {
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });
  if (!response.ok) {
    let detail = `Request failed (${response.status})`;
    try {
      const body = await response.json();
      if (body?.detail) detail = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
    } catch {
      /* keep default message */
    }
    throw new ApiError(response.status, detail);
  }
  return response.json() as Promise<T>;
}

export const api = {
  // --- system ---
  health: () => request<{ status: string; ai_mode: string; database: string }>("/health"),
  aiStatus: () => request<Record<string, unknown>>("/ai/status"),
  dashboardStats: () => request<DashboardStats>("/dashboard/stats"),

  // --- explore ---
  exploreStates: () => request<{ state: string; destinations: ExploreDestination[] }>("/explore/states"),
  exploreDestinations: (category?: string, state?: string) =>
    request<ExploreDestination[]>("/explore/destinations", {}, { category, state }),
  exploreSearch: (q: string) => request<ExploreSearchResult>("/explore/search", {}, { q }),

  // --- places ---
  hotels: <T = Record<string, unknown>>(
    city: string,
    extra?: { check_in?: string; check_out?: string; guests?: number; preference?: string },
  ) =>
    request<T>("/hotels", {}, { city, ...extra }),
  restaurants: <T = Record<string, unknown>>(city: string, food_preference?: string) =>
    request<T>("/restaurants", {}, { city, food_preference }),
  attractions: <T = Record<string, unknown>>(city: string, interests?: string) =>
    request<T>("/attractions", {}, { city, interests }),

  // --- transport & weather ---
  transportSearch: <T = Record<string, unknown>>(
    origin: string,
    destination: string,
    travel_date?: string,
    travellers = 2,
    mode = "any",
  ) =>
    request<T>("/transport/search", {}, { origin, destination, travel_date, travellers, mode }),
  weather: <T = Record<string, unknown>>(city: string, start?: string, end?: string) =>
    request<T>("/weather", {}, { city, start, end }),

  // --- trips ---
  planTrip: (payload: TripRequest) =>
    request<TripPlanResponse>("/trips/plan", { method: "POST", body: JSON.stringify(payload) }),
  listTrips: (sessionId?: string) => request<TripPlanSummary[]>("/trips", {}, { session_id: sessionId }),
  getTrip: (id: number) => request<TripPlanResponse>(`/trips/${id}`),
  updateTrip: (id: number, payload: { title?: string; status?: string }) =>
    request<TripPlanSummary>(`/trips/${id}`, { method: "PATCH", body: JSON.stringify(payload) }),
  deleteTrip: (id: number) => request<{ deleted: number }>(`/trips/${id}`, { method: "DELETE" }),
  saveRecommendation: (tripId: number, payload: Record<string, unknown>) =>
    request<Record<string, unknown>>(`/trips/${tripId}/save-recommendation`, {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  // --- chat ---
  chat: (sessionId: string, message: string) =>
    request<ChatResponse>("/chat", { method: "POST", body: JSON.stringify({ session_id: sessionId, message }) }),
  clearChatHistory: (sessionId: string) =>
    request<{ deleted_messages: number }>(`/chat/history/${sessionId}`, { method: "DELETE" }),

  // --- vision ---
  analyzeImage: async (file: File): Promise<VisionAnalysis> => {
    const form = new FormData();
    form.append("image", file);
    const response = await fetch(buildUrl("/vision/analyze"), { method: "POST", body: form });
    if (!response.ok) {
      const body = await response.json().catch(() => null);
      throw new ApiError(response.status, body?.detail ?? `Vision analysis failed (${response.status})`);
    }
    return response.json() as Promise<VisionAnalysis>;
  },

  // --- exports (direct download URLs) ---
  exportCsvUrl: (tripId: number) => buildUrl(`/exports/trip/${tripId}/csv`),
  exportXlsxUrl: (tripId: number) => buildUrl(`/exports/trip/${tripId}/xlsx`),
};

export function getSessionId(): string {
  const KEY = "sta-session-id";
  let id = localStorage.getItem(KEY);
  if (!id) {
    id = `web-${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
    localStorage.setItem(KEY, id);
  }
  return id;
}
