/**
 * Destination image resolution.
 *
 * Real photos live in /public/images (fetched from public web sources during
 * development). Destinations without a bundled photo render a themed gradient
 * fallback - never a broken image URL.
 */
const PHOTO_MAP: Record<string, string> = {
  // reference image_key -> bundled photo file
  delhi: "delhi-india-gate.jpg",
  "agra-taj-mahal": "taj-mahal.jpg",
  jaipur: "jaipur-hawa-mahal.jpg",
  goa: "goa-beach.jpg",
  alappuzha: "kerala-backwaters.jpg",
  manali: "manali.jpg",
  leh: "ladakh-leh.jpg",
  pangong: "ladakh-leh.jpg",
  nubra: "ladakh-leh.jpg",
  varanasi: "varanasi.jpg",
  udaipur: "udaipur.jpg",
  mumbai: "mumbai-gateway.jpg",
  darjeeling: "darjeeling.jpg",
  amritsar: "amritsar-golden-temple.jpg",
  rishikesh: "rishikesh.jpg",
  kolkata: "kolkata-victoria.jpg",
  hyderabad: "hyderabad-charminar.jpg",
  shimla: "shimla.jpg",
  gangtok: "gangtok.jpg",
  mysore: "mysore-palace.jpg",
};

const CATEGORY_STYLES: Record<string, { gradient: string; emoji: string }> = {
  historical: { gradient: "from-navy via-deepsea to-teal-dark", emoji: "🏛️" },
  "hill-station": { gradient: "from-deepsea via-teal to-teal-light", emoji: "🏔️" },
  beach: { gradient: "from-teal-dark via-teal to-sky-400", emoji: "🏖️" },
  religious: { gradient: "from-navy via-navy-muted to-deepsea", emoji: "🛕" },
  nature: { gradient: "from-teal-dark via-teal to-emerald-400", emoji: "🌿" },
  popular: { gradient: "from-navy-muted via-deepsea to-teal", emoji: "✨" },
};

export const HERO_IMAGE = "/images/taj-mahal.jpg";

export const FEATURED_PHOTOS: { key: string; file: string; title: string; city: string; state: string }[] = [
  { key: "agra-taj-mahal", file: "taj-mahal.jpg", title: "Taj Mahal", city: "Agra", state: "Uttar Pradesh" },
  { key: "jaipur", file: "jaipur-hawa-mahal.jpg", title: "Hawa Mahal", city: "Jaipur", state: "Rajasthan" },
  { key: "goa", file: "goa-beach.jpg", title: "Goa Beaches", city: "Panaji", state: "Goa" },
  { key: "alappuzha", file: "kerala-backwaters.jpg", title: "Alleppey Backwaters", city: "Alappuzha", state: "Kerala" },
  { key: "manali", file: "manali.jpg", title: "Manali", city: "Manali", state: "Himachal Pradesh" },
  { key: "leh", file: "ladakh-leh.jpg", title: "Pangong Lake", city: "Leh", state: "Ladakh" },
  { key: "varanasi", file: "varanasi.jpg", title: "Varanasi Ghats", city: "Varanasi", state: "Uttar Pradesh" },
  { key: "udaipur", file: "udaipur.jpg", title: "Udaipur", city: "Udaipur", state: "Rajasthan" },
  { key: "mumbai", file: "mumbai-gateway.jpg", title: "Gateway of India", city: "Mumbai", state: "Maharashtra" },
  { key: "amritsar", file: "amritsar-golden-temple.jpg", title: "Golden Temple", city: "Amritsar", state: "Punjab" },
  { key: "darjeeling", file: "darjeeling.jpg", title: "Darjeeling", city: "Darjeeling", state: "West Bengal" },
  { key: "hyderabad", file: "hyderabad-charminar.jpg", title: "Charminar", city: "Hyderabad", state: "Telangana" },
  { key: "mysore", file: "mysore-palace.jpg", title: "Mysore Palace", city: "Mysore", state: "Karnataka" },
];

export function photoFor(imageKey: string): string | null {
  const file = PHOTO_MAP[imageKey];
  return file ? `/images/${file}` : null;
}

export function categoryStyle(category: string): { gradient: string; emoji: string } {
  return CATEGORY_STYLES[category] ?? CATEGORY_STYLES.popular;
}
