/** Shared search-box state for the Hotels / Restaurants / Attractions pages. */
import { useState } from "react";

export interface CitySearchState {
  city: string;
  setCity: (c: string) => void;
  submitted: string;
  submit: () => void;
  reset: () => void;
}

export function useCitySearch(initial = ""): CitySearchState {
  const [city, setCity] = useState(initial);
  const [submitted, setSubmitted] = useState(initial);
  return {
    city,
    setCity,
    submitted,
    submit: () => setSubmitted(city.trim()),
    reset: () => {
      setCity("");
      setSubmitted("");
    },
  };
}
