import { Route, Routes, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import MainLayout from "@/layouts/MainLayout";
import ScrollToTop from "@/components/ScrollToTop";
import Home from "@/pages/Home";
import TripPlanner from "@/pages/TripPlanner";
import ExploreIndia from "@/pages/ExploreIndia";
import Transport from "@/pages/Transport";
import Hotels from "@/pages/Hotels";
import Restaurants from "@/pages/Restaurants";
import Attractions from "@/pages/Attractions";
import Chatbot from "@/pages/Chatbot";
import WeatherBudget from "@/pages/WeatherBudget";
import VisionPage from "@/pages/VisionPage";
import SavedTrips from "@/pages/SavedTrips";
import About from "@/pages/About";

function PageWrapper({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.28, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  );
}

export default function App() {
  const location = useLocation();
  return (
    <>
      <ScrollToTop />
      <MainLayout>
        <AnimatePresence mode="wait">
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={<PageWrapper><Home /></PageWrapper>} />
            <Route path="/trip-planner" element={<PageWrapper><TripPlanner /></PageWrapper>} />
            <Route path="/explore" element={<PageWrapper><ExploreIndia /></PageWrapper>} />
            <Route path="/transport" element={<PageWrapper><Transport /></PageWrapper>} />
            <Route path="/hotels" element={<PageWrapper><Hotels /></PageWrapper>} />
            <Route path="/restaurants" element={<PageWrapper><Restaurants /></PageWrapper>} />
            <Route path="/attractions" element={<PageWrapper><Attractions /></PageWrapper>} />
            <Route path="/assistant" element={<PageWrapper><Chatbot /></PageWrapper>} />
            <Route path="/weather-budget" element={<PageWrapper><WeatherBudget /></PageWrapper>} />
            <Route path="/vision" element={<PageWrapper><VisionPage /></PageWrapper>} />
            <Route path="/saved-trips" element={<PageWrapper><SavedTrips /></PageWrapper>} />
            <Route path="/about" element={<PageWrapper><About /></PageWrapper>} />
            <Route path="*" element={<PageWrapper><Home /></PageWrapper>} />
          </Routes>
        </AnimatePresence>
      </MainLayout>
    </>
  );
}
