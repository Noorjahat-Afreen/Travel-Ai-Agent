import { Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import type { BudgetBreakdown } from "@/types";

const COLORS = ["#167D78", "#174F67", "#2AA198", "#0F5F5B", "#3E5C76", "#B6C6D8"];

const inr = (n: number) => `₹${Math.round(n).toLocaleString("en-IN")}`;

export default function BudgetChart({ budget }: { budget: BudgetBreakdown }) {
  const data = budget.categories.map((c) => ({ name: c.category, value: Math.max(c.estimated_inr, 0.01) }));
  return (
    <div className="h-64 w-full" aria-label="Budget breakdown chart">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie data={data} dataKey="value" nameKey="name" innerRadius={52} outerRadius={82} paddingAngle={3}>
            {data.map((_, i) => (
              <Cell key={i} fill={COLORS[i % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip formatter={(value: number | string) => inr(Number(value))} />
          <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

export function inrFormat(n: number): string {
  return inr(n);
}
