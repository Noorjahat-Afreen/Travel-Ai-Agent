import { motion } from "framer-motion";

interface Props {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
}

export default function PageHeader({ eyebrow, title, subtitle, icon }: Props) {
  return (
    <section className="bg-gradient-to-br from-navy via-navy-soft to-deepsea text-white">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 md:py-16">
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          {eyebrow && (
            <p className="mb-2 text-xs font-bold uppercase tracking-[0.2em] text-teal-light">{eyebrow}</p>
          )}
          <h1 className="flex items-center gap-3 text-3xl font-extrabold tracking-tight md:text-4xl">
            {icon && <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10">{icon}</span>}
            {title}
          </h1>
          {subtitle && <p className="mt-3 max-w-2xl text-sm leading-relaxed text-slate-300 md:text-base">{subtitle}</p>}
        </motion.div>
      </div>
    </section>
  );
}
