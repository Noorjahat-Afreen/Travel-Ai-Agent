import { Link } from "react-router-dom";
import { Compass, ExternalLink, Github } from "lucide-react";

const QUICK_LINKS = [
  { to: "/trip-planner", label: "AI Trip Planner" },
  { to: "/explore", label: "Explore India" },
  { to: "/transport", label: "Transport Search" },
  { to: "/hotels", label: "Hotels" },
  { to: "/restaurants", label: "Restaurants" },
  { to: "/attractions", label: "Attractions" },
  { to: "/assistant", label: "AI Travel Assistant" },
  { to: "/vision", label: "Photo Recognition" },
  { to: "/saved-trips", label: "Saved Trips" },
  { to: "/about", label: "About Project" },
];

const DATA_SOURCES = [
  { label: "OpenStreetMap", url: "https://www.openstreetmap.org" },
  { label: "Open-Meteo", url: "https://open-meteo.com" },
  { label: "Wikipedia", url: "https://en.wikipedia.org" },
  { label: "IRCTC", url: "https://www.irctc.co.in" },
  { label: "redBus", url: "https://www.redbus.in" },
  { label: "Booking.com", url: "https://www.booking.com" },
];

export default function Footer() {
  return (
    <footer className="mt-auto bg-navy text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/10">
              <Compass className="h-5 w-5 text-teal-light" />
            </span>
            <div>
              <p className="text-[15px] font-bold">AI Smart Travel Agent</p>
              <p className="text-[10px] font-semibold uppercase tracking-widest text-teal-light">India · B.Tech Major Project</p>
            </div>
          </div>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-slate-300">
            A multi-agent AI travel planner for destinations across India. Built with React, FastAPI, LangChain and
            Google Gemini. All prices and availability are confirmed on the provider websites we link to - we never
            invent them.
          </p>
        </div>

        <div>
          <h3 className="text-xs font-bold uppercase tracking-widest text-teal-light">Platform</h3>
          <ul className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            {QUICK_LINKS.map((l) => (
              <li key={l.to}>
                <Link to={l.to} className="text-slate-300 transition-colors hover:text-white">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-xs font-bold uppercase tracking-widest text-teal-light">Data Sources</h3>
          <ul className="mt-4 space-y-2 text-sm">
            {DATA_SOURCES.map((s) => (
              <li key={s.label}>
                <a
                  href={s.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-slate-300 transition-colors hover:text-white"
                >
                  {s.label} <ExternalLink className="h-3 w-3" />
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-slate-400 sm:flex-row sm:px-6">
          <p>
            B.Tech CSE (AI &amp; ML) Major Project · Data: OpenStreetMap contributors (ODbL) · Weather: Open-Meteo ·
            Summaries: Wikipedia (CC BY-SA)
          </p>
          <p className="flex items-center gap-1.5">
            <Github className="h-3.5 w-3.5" /> Educational use - verify live prices with providers
          </p>
        </div>
      </div>
    </footer>
  );
}
