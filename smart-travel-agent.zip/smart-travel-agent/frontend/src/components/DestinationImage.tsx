import { categoryStyle, photoFor } from "@/services/images";

interface Props {
  imageKey?: string;
  category?: string;
  alt: string;
  className?: string;
  emoji?: string;
}

/** Photo when bundled, otherwise a themed gradient fallback (never a broken URL). */
export default function DestinationImage({ imageKey, category = "popular", alt, className = "", emoji }: Props) {
  const photo = imageKey ? photoFor(imageKey) : null;
  const style = categoryStyle(category);
  if (photo) {
    return (
      <img
        src={photo}
        alt={alt}
        loading="lazy"
        className={`object-cover ${className}`}
        onError={(e) => {
          (e.target as HTMLImageElement).style.display = "none";
        }}
      />
    );
  }
  return (
    <div
      role="img"
      aria-label={alt}
      className={`flex items-center justify-center bg-gradient-to-br ${style.gradient} ${className}`}
    >
      <span className="text-3xl drop-shadow" aria-hidden>
        {emoji ?? style.emoji}
      </span>
    </div>
  );
}
