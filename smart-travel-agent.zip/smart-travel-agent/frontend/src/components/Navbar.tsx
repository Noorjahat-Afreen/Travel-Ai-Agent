import { useEffect, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import {
  Bot,
  Building2,
  Camera,
  CloudSun,
  Compass,
  Menu,
  MapPin,
  Landmark,
  Plane,
  Star,
  TrainFront,
  UtensilsCrossed,
  Wallet,
  X,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const NAV = [
  { to: "/", label: "Home", icon: Compass },
  { to: "/trip-planner", label: "AI Trip Planner", icon: MapPin },
  { to: "/explore", label: "Explore India", icon: Landmark },
  { to: "/transport", label: "Transport", icon: TrainFront },
  { to: "/hotels", label: "Hotels", icon: Building2 },
  { to: "/restaurants", label: "Restaurants", icon: UtensilsCrossed },
  { to: "/attractions", label: "Attractions", icon: Star },
  { to: "/assistant", label: "AI Assistant", icon: Bot },
  { to: "/weather-budget", label: "Weather & Budget", icon: CloudSun },
  { to: "/vision", label: "Photo Recognition", icon: Camera },
  { to: "/saved-trips", label: "Saved Trips", icon: Wallet },
  { to: "/about", label: "About Project", icon: Plane },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => setOpen(false), [location.pathname]);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-40 border-b transition-all duration-300 ${
        scrolled ? "border-slate-200 bg-white/95 shadow-card backdrop-blur" : "border-transparent bg-white"
      }`}
    >
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6" aria-label="Main navigation">
        <Link to="/" className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-navy text-white shadow-card">
            <Compass className="h-5 w-5 text-teal-light" />
          </span>
          <span className="leading-tight">
            <span className="block text-[15px] font-bold text-navy">Smart Travel Agent</span>
            <span className="block text-[10px] font-semibold uppercase tracking-widest text-teal">India · AI Powered</span>
          </span>
        </Link>

        <div className="hidden items-center gap-0.5 lg:flex">
          {NAV.slice(0, 8).map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `rounded-lg px-2.5 py-2 text-[13px] font-semibold transition-colors ${
                  isActive ? "bg-sand text-teal" : "text-navy-muted hover:bg-sand hover:text-navy"
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
          <div className="relative ml-1 flex items-center gap-1">
            <NavLink to="/weather-budget" className="btn-outline !px-3 !py-1.5 text-xs">Weather</NavLink>
            <NavLink to="/saved-trips" className="btn-primary !px-3.5 !py-1.5 text-xs">My Trips</NavLink>
            <button
              onClick={() => setOpen((v) => !v)}
              className="rounded-lg p-2 text-navy-muted hover:bg-sand"
              aria-expanded={open}
              aria-label="More pages"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <AnimatePresence>
              {open && (
                <motion.div
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 6 }}
                  className="absolute right-0 top-11 z-50 w-60 overflow-hidden rounded-xl border border-slate-200 bg-white p-2 shadow-card-hover"
                >
                  {NAV.slice(8).map((item) => (
                    <Link
                      key={item.to}
                      to={item.to}
                      className="flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-semibold text-navy hover:bg-sand"
                    >
                      <item.icon className="h-4 w-4 text-teal" /> {item.label}
                    </Link>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <button
          className="rounded-lg p-2 text-navy hover:bg-sand lg:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-label="Open navigation menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-slate-100 bg-white lg:hidden"
          >
            <div className="grid grid-cols-2 gap-1 px-4 py-3 sm:grid-cols-3">
              {NAV.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-semibold ${
                    location.pathname === item.to ? "bg-sand text-teal" : "text-navy hover:bg-sand"
                  }`}
                >
                  <item.icon className="h-4 w-4 text-teal" /> {item.label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
