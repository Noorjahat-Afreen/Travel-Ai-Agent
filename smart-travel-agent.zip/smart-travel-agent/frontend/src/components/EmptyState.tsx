import { AlertTriangle, Info, Inbox } from "lucide-react";

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="card flex flex-col items-center justify-center gap-2 px-6 py-14 text-center">
      <span className="flex h-12 w-12 items-center justify-center rounded-full bg-sand text-navy-muted">
        <Inbox className="h-6 w-6" />
      </span>
      <p className="font-semibold text-navy">{title}</p>
      {hint && <p className="max-w-md text-sm text-navy-muted">{hint}</p>}
    </div>
  );
}

export function ErrorBanner({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex items-start gap-3 rounded-xl2 border border-amber-300 bg-amber-50 p-4 text-amber-900">
      <AlertTriangle className="mt-0.5 h-5 w-5 flex-shrink-0" />
      <div className="flex-1">
        <p className="text-sm font-semibold">{message}</p>
        <p className="mt-0.5 text-xs opacity-80">
          If the problem persists, check that the FastAPI backend is running (port 8000) and external APIs are reachable.
        </p>
      </div>
      {onRetry && (
        <button onClick={onRetry} className="btn-outline !border-amber-400 !px-3 !py-1.5 text-xs !text-amber-800">
          Retry
        </button>
      )}
    </div>
  );
}

export function InfoNote({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2.5 rounded-xl2 border border-sky-200 bg-sky-50 p-3.5 text-sm text-sky-900">
      <Info className="mt-0.5 h-4 w-4 flex-shrink-0" />
      <div className="text-[13px] leading-relaxed">{children}</div>
    </div>
  );
}
