import { ExternalLink, ShieldCheck } from "lucide-react";
import type { BookingLink, SourceInfo } from "@/types";

const KIND_STYLE: Record<string, string> = {
  hotel: "bg-deepsea/10 text-deepsea",
  train: "bg-emerald-100 text-emerald-800",
  bus: "bg-orange-100 text-orange-800",
  flight: "bg-sky-100 text-sky-800",
  car: "bg-violet-100 text-violet-800",
  map: "bg-teal/10 text-teal",
  website: "bg-slate-100 text-slate-700",
  info: "bg-sand text-navy-muted",
};

export function SourceBadge({ source }: { source?: SourceInfo }) {
  if (!source?.name) return null;
  return (
    <span className="inline-flex items-center gap-1 text-[10.5px] font-medium text-navy-muted">
      <ShieldCheck className="h-3 w-3 text-teal" />
      Source:{" "}
      {source.url ? (
        <a href={source.url} target="_blank" rel="noopener noreferrer" className="underline decoration-dotted hover:text-teal">
          {source.name}
        </a>
      ) : (
        source.name
      )}
    </span>
  );
}

export function BookingButtons({ links, compact }: { links: BookingLink[]; compact?: boolean }) {
  if (!links.length) return null;
  const primary = links[0];
  const rest = links.slice(1);
  return (
    <div className={`flex flex-wrap items-center gap-2 ${compact ? "" : "mt-3"}`}>
      <a
        href={primary.url}
        target="_blank"
        rel="noopener noreferrer"
        className="btn-primary !px-3.5 !py-2 text-xs"
        title={`Opens ${primary.provider} in a new tab`}
      >
        {primary.label} <ExternalLink className="h-3.5 w-3.5" />
      </a>
      {rest.slice(0, compact ? 2 : 3).map((l) => (
        <a
          key={l.url + l.label}
          href={l.url}
          target="_blank"
          rel="noopener noreferrer"
          className={`chip ${KIND_STYLE[l.kind] ?? KIND_STYLE.info} hover:brightness-95`}
          title={`${l.label} - ${l.provider}`}
        >
          {l.label} <ExternalLink className="h-3 w-3" />
        </a>
      ))}
      {rest.length > (compact ? 2 : 3) && (
        <span className="text-[11px] text-navy-muted">+{rest.length - (compact ? 2 : 3)} more</span>
      )}
    </div>
  );
}
