import { Loader2 } from "lucide-react";

export { EmptyState, ErrorBanner, InfoNote } from "./EmptyState";

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-navy-muted" role="status">
      <Loader2 className="h-8 w-8 animate-spin text-teal" />
      {label && <p className="text-sm font-medium">{label}</p>}
    </div>
  );
}

export function SkeletonCard() {
  return (
    <div className="card overflow-hidden">
      <div className="skeleton h-36 w-full rounded-none" />
      <div className="space-y-2.5 p-4">
        <div className="skeleton h-4 w-3/4" />
        <div className="skeleton h-3 w-1/2" />
        <div className="skeleton h-3 w-2/3" />
      </div>
    </div>
  );
}

export function CardGridSkeleton({ count = 6 }: { count?: number }) {
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: count }).map((_, i) => (
        <SkeletonCard key={i} />
      ))}
    </div>
  );
}

export function PlanningProgress({ visible }: { visible: boolean }) {
  if (!visible) return null;
  const steps = [
    "Geocoding destination (Nominatim)",
    "Collecting hotels & restaurants (OpenStreetMap)",
    "Finding attractions & Wikipedia description",
    "Fetching weather forecast (Open-Meteo)",
    "Estimating budget & building itinerary",
  ];
  return (
    <div className="card p-6">
      <div className="flex items-center gap-3">
        <Loader2 className="h-6 w-6 animate-spin text-teal" />
        <div>
          <p className="font-bold text-navy">Multi-agent planning in progress…</p>
          <p className="text-xs text-navy-muted">
            The Master Travel Agent is coordinating specialised agents over live public APIs.
          </p>
        </div>
      </div>
      <ul className="mt-4 space-y-2">
        {steps.map((s, i) => (
          <li key={s} className="flex items-center gap-2 text-sm text-navy-muted" style={{ opacity: 1 - i * 0.15 }}>
            <span className="h-1.5 w-1.5 rounded-full bg-teal" /> {s}
          </li>
        ))}
      </ul>
    </div>
  );
}
