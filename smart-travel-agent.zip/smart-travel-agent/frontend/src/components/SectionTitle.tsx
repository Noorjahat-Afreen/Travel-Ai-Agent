interface Props {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
}

export default function SectionTitle({ title, subtitle, action }: Props) {
  return (
    <div className="mb-5 flex items-end justify-between gap-4">
      <div>
        <h2 className="text-xl font-bold text-navy md:text-2xl">{title}</h2>
        {subtitle && <p className="mt-1 text-sm text-navy-muted">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}
