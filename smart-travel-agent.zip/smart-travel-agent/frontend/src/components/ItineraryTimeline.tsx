import { Bus, Car, Map, Plane, TrainFront } from "lucide-react";
import type { ItineraryDay } from "@/types";

const PERIOD_STYLE: Record<string, string> = {
  Morning: "bg-amber-100 text-amber-800",
  Afternoon: "bg-sky-100 text-sky-800",
  Evening: "bg-indigo-100 text-indigo-800",
};

export default function ItineraryTimeline({ days }: { days: ItineraryDay[] }) {
  return (
    <ol className="relative space-y-6 border-l-2 border-slate-200 pl-6">
      {days.map((day) => (
        <li key={day.day_number} className="relative">
          <span className="absolute -left-[35px] flex h-7 w-7 items-center justify-center rounded-full bg-navy text-[11px] font-bold text-white ring-4 ring-mist">
            {day.day_number}
          </span>
          <div className="card p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-bold text-navy">{day.title}</h3>
              <span className="chip bg-sand text-navy-muted">
                {new Date(day.date).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
              </span>
            </div>
            {day.theme && <p className="mt-0.5 text-xs font-semibold uppercase tracking-wide text-teal">{day.theme}</p>}
            <ul className="mt-4 space-y-3">
              {day.activities.map((a, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className={`chip ${PERIOD_STYLE[a.period] ?? "bg-sand text-navy-muted"} w-20 justify-center`}>
                    {a.period}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-ink">
                      {a.title}
                      {a.place_name && a.map_link ? (
                        <a href={a.map_link} target="_blank" rel="noopener noreferrer" className="ml-2 text-xs font-semibold text-teal underline decoration-dotted">
                          view on map ↗
                        </a>
                      ) : null}
                    </p>
                    {a.description && <p className="mt-0.5 text-[13px] leading-relaxed text-navy-muted">{a.description}</p>}
                  </div>
                </li>
              ))}
            </ul>
            {day.travel_note && (
              <p className="mt-3 flex items-center gap-1.5 text-xs text-navy-muted">
                <Car className="h-3.5 w-3.5 text-teal" /> {day.travel_note}
              </p>
            )}
          </div>
        </li>
      ))}
    </ol>
  );
}

export const MODE_ICONS = { train: TrainFront, bus: Bus, flight: Plane, car: Car, map: Map };
