import { CheckCircle2, AlertTriangle, XCircle, MinusCircle } from "lucide-react";
import type { AgentStatus } from "@/types";

const ICONS = {
  ok: CheckCircle2,
  degraded: AlertTriangle,
  error: XCircle,
  skipped: MinusCircle,
};

const COLORS = {
  ok: "text-emerald-600",
  degraded: "text-amber-600",
  error: "text-rose-600",
  skipped: "text-slate-400",
};

export default function AgentStatusGrid({ statuses }: { statuses: AgentStatus[] }) {
  return (
    <div className="card p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="font-bold text-navy">Multi-agent execution trace</h3>
        <span className="chip bg-sand text-navy-muted">{statuses.length} agents</span>
      </div>
      <div className="grid gap-2.5 sm:grid-cols-2">
        {statuses.map((s) => {
          const Icon = ICONS[s.status] ?? ICONS.ok;
          return (
            <div key={s.agent} className="flex items-start gap-2.5 rounded-lg border border-slate-100 bg-mist/60 p-3">
              <Icon className={`mt-0.5 h-4 w-4 flex-shrink-0 ${COLORS[s.status] ?? COLORS.ok}`} />
              <div className="min-w-0">
                <p className="text-[13px] font-bold text-navy">{s.agent}</p>
                <p className="text-[12px] leading-relaxed text-navy-muted">{s.message || s.status}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
