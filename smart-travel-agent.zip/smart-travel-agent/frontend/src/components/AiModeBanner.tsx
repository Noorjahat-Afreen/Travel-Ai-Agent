import { Bot, Cpu, Sparkles } from "lucide-react";

/** Banner explaining which AI mode the platform is currently in (honest labelling). */
export default function AiModeBanner({ mode, note }: { mode: string; note?: string }) {
  const isGemini = mode === "gemini";
  return (
    <div
      className={`flex items-start gap-3 rounded-xl2 border p-4 ${
        isGemini ? "border-teal/40 bg-teal/5" : "border-slate-300 bg-white"
      }`}
    >
      <span className={`flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-xl ${isGemini ? "bg-teal text-white" : "bg-navy text-white"}`}>
        {isGemini ? <Sparkles className="h-4.5 w-4.5" /> : <Cpu className="h-4 w-4" />}
      </span>
      <div className="text-sm">
        <p className={`font-bold ${isGemini ? "text-teal-dark" : "text-navy"}`}>
          {isGemini ? "Google Gemini connected" : "Local intelligence mode"}
        </p>
        <p className="mt-0.5 text-[12.5px] leading-relaxed text-navy-muted">
          {note ??
            (isGemini
              ? "AI narratives, chat reasoning and landmark recognition are powered by Gemini via LangChain."
              : "GEMINI_API_KEY is not configured in backend/.env, so AI narrative features are disabled. All data below still comes from live public APIs (OpenStreetMap, Open-Meteo, Wikipedia) and deterministic agents - nothing is fabricated.")}
        </p>
      </div>
      <Bot className="ml-auto h-5 w-5 flex-shrink-0 text-navy-muted/50" />
    </div>
  );
}
