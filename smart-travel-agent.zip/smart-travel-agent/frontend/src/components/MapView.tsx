import { useMemo } from "react";
import { MapContainer, Marker, Popup, TileLayer } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { PlaceRecord } from "@/types";

export interface MapPoint {
  lat: number;
  lon: number;
  name: string;
  category: "hotel" | "restaurant" | "attraction" | "destination";
  detail?: string;
  link?: string;
}

const ICON_GLYPH: Record<string, string> = {
  hotel: "🛏️",
  restaurant: "🍽️",
  attraction: "📸",
  destination: "📍",
};

function makeIcon(category: string) {
  return L.divIcon({
    className: `map-marker map-marker-${category}`,
    html: `<span>${ICON_GLYPH[category] ?? "📍"}</span>`,
    iconSize: [30, 30],
    iconAnchor: [15, 15],
    popupAnchor: [0, -14],
  });
}

export default function MapView({
  center,
  points,
  height = 420,
}: {
  center: { lat: number; lon: number; name?: string };
  points: MapPoint[];
  height?: number;
}) {
  const markers = useMemo(
    () =>
      points.map((p, i) => (
        <Marker key={`${p.name}-${i}`} position={[p.lat, p.lon]} icon={makeIcon(p.category)}>
          <Popup>
            <b>{p.name}</b>
            {p.detail ? <div style={{ fontSize: 12, marginTop: 2 }}>{p.detail}</div> : null}
            {p.link ? (
              <a href={p.link} target="_blank" rel="noopener noreferrer" style={{ fontSize: 12, color: "#167D78" }}>
                Get Directions ↗
              </a>
            ) : null}
          </Popup>
        </Marker>
      )),
    [points],
  );

  return (
    <div className="overflow-hidden rounded-xl2 border border-slate-200" style={{ height }}>
      <MapContainer center={[center.lat, center.lon]} zoom={12} scrollWheelZoom style={{ height: "100%", width: "100%" }}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {markers}
      </MapContainer>
    </div>
  );
}
