import { BedDouble, MapPin, Navigation, ShieldCheck, Star, UtensilsCrossed, Landmark } from "lucide-react";
import type { PlaceRecord } from "@/types";
import { BookingButtons, SourceBadge } from "@/components/SourceBadge";

const MISSING = "details unavailable in collected data";

const ICONS = {
  hotel: BedDouble,
  restaurant: UtensilsCrossed,
  attraction: Landmark,
} as const;

export default function PlaceCard({
  record,
  kind,
  reason,
}: {
  record: PlaceRecord;
  kind: "hotel" | "restaurant" | "attraction";
  reason?: string;
}) {
  const Icon = ICONS[kind];
  const isRestaurant = kind === "restaurant";
  return (
    <article className="card card-hover flex h-full flex-col p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-sand text-deepsea">
            <Icon className="h-5 w-5" />
          </span>
          <div>
            <h3 className="font-bold leading-snug text-navy">{record.name}</h3>
            <p className="mt-0.5 text-xs font-medium capitalize text-navy-muted">
              {record.category.replace(/_/g, " ")}
              {record.stars ? ` · ${record.stars}★` : ""}
              {record.distance_km != null ? ` · ${record.distance_km} km from centre` : ""}
            </p>
          </div>
        </div>
        {isRestaurant && record.vegetarian === true && (
          <span className="chip bg-emerald-100 text-emerald-800">Veg tagged</span>
        )}
      </div>

      <p className="mt-3 flex items-start gap-1.5 text-[13px] leading-relaxed text-navy-muted">
        <MapPin className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-teal" />
        <span>{record.address || record.description || MISSING}</span>
      </p>
      {isRestaurant && record.cuisine && (
        <p className="mt-1.5 text-[13px] text-navy-muted">
          <span className="font-semibold text-navy">Cuisine:</span> {record.cuisine.replace(/;/g, ", ")}
        </p>
      )}
      {reason && (
        <p className="mt-2 rounded-lg bg-teal/5 p-2.5 text-[12.5px] leading-relaxed text-teal-dark">
          <span className="font-bold">Why recommended:</span> {reason}
        </p>
      )}

      <div className="mt-auto pt-3">
        <BookingButtons links={record.booking_links} />
        <div className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-1.5">
          <a
            href={record.directions_link}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-[11.5px] font-semibold text-deepsea hover:text-teal"
          >
            <Navigation className="h-3 w-3" /> Get Directions
          </a>
          <a
            href={record.map_link}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-[11.5px] font-semibold text-deepsea hover:text-teal"
          >
            <MapPin className="h-3 w-3" /> OpenStreetMap
          </a>
          <SourceBadge source={record.source} />
        </div>
      </div>
    </article>
  );
}

export function Stars({ value }: { value: number }) {
  return (
    <span className="inline-flex items-center gap-0.5 text-amber-500">
      {Array.from({ length: Math.min(value, 5) }).map((_, i) => (
        <Star key={i} className="h-3.5 w-3.5 fill-current" />
      ))}
    </span>
  );
}

export function VerifiedInline() {
  return (
    <span className="inline-flex items-center gap-1 text-[11px] text-navy-muted">
      <ShieldCheck className="h-3.5 w-3.5 text-teal" /> Collected data
    </span>
  );
}
