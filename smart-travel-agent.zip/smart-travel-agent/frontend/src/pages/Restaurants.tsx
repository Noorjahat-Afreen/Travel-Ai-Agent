import { useState } from "react";
import { UtensilsCrossed } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import PlaceCard from "@/components/PlaceCard";
import { CardGridSkeleton, EmptyState, ErrorBanner, InfoNote } from "@/components/Loader";
import { api } from "@/services/api";
import { useCitySearch } from "@/hooks/useCitySearch";
import type { PlaceRecord } from "@/types";

interface RestaurantsResponse {
  city: string;
  restaurants: PlaceRecord[];
}

const PREFS = [
  { id: "any", label: "Any" },
  { id: "vegetarian", label: "Vegetarian first" },
  { id: "local", label: "Local cuisine" },
  { id: "continental", label: "Continental" },
];

export default function Restaurants() {
  const search = useCitySearch("Udaipur");
  const [pref, setPref] = useState("any");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<RestaurantsResponse | null>(null);
  const [checked, setChecked] = useState(false);

  const run = async () => {
    setChecked(true);
    setLoading(true);
    setError(null);
    try {
      setData(await api.restaurants<RestaurantsResponse>(search.city || "Udaipur", pref));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Search failed");
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <PageHeader
        eyebrow="Cuisine, veg tags & map links"
        title="Restaurant Finder"
        subtitle="Restaurants and cafes from public OpenStreetMap records. Vegetarian badges appear only where venues are explicitly tagged - we never guess dietary options."
        icon={<UtensilsCrossed className="h-6 w-6 text-teal-light" />}
      />
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <section className="card flex flex-col gap-3 p-5 sm:flex-row sm:items-center">
          <input
            className="field flex-1"
            placeholder="Enter a city, e.g. Udaipur, Jaipur, Mumbai…"
            value={search.city}
            onChange={(e) => search.setCity(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && run()}
            aria-label="City to search restaurants"
          />
          <select className="field sm:w-56" value={pref} onChange={(e) => setPref(e.target.value)} aria-label="Food preference">
            {PREFS.map((p) => (
              <option key={p.id} value={p.id}>
                {p.label}
              </option>
            ))}
          </select>
          <button className="btn-primary sm:w-48" onClick={run} disabled={loading}>
            {loading ? "Searching…" : "Find restaurants"}
          </button>
        </section>

        {error && <div className="mt-6"><ErrorBanner message={error} onRetry={run} /></div>}
        {loading && <div className="mt-6"><CardGridSkeleton count={6} /></div>}

        {!loading && data && (
          <>
            <p className="mt-8 text-sm text-navy-muted">
              <b className="text-navy">{data.restaurants.length}</b> record(s) in <b className="text-navy">{data.city}</b>
            </p>
            <div className="mt-4 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {data.restaurants.slice(0, 18).map((r) => (
                <PlaceCard key={r.name + r.lat} record={r} kind="restaurant" />
              ))}
            </div>
            {data.restaurants.length === 0 && (
              <div className="mt-5">
                <EmptyState
                  title={`No restaurant records collected for ${data.city}`}
                  hint="Providers may be temporarily unreachable or the area has no tagged venues in open data. Each hotel card and the trip planner still provide restaurant exploration links."
                />
              </div>
            )}
            <div className="mt-8">
              <InfoNote>
                Cuisine tags come straight from OpenStreetMap (`cuisine=*`). "Explore Restaurant" opens the venue on
                Google Maps for menus, hours and reviews from the provider.
              </InfoNote>
            </div>
          </>
        )}

        {!checked && !loading && <div className="mt-6"><InfoNote>Try Udaipur, Jaipur, Indore, Delhi, Mumbai or any Indian city.</InfoNote></div>}
      </div>
    </div>
  );
}
