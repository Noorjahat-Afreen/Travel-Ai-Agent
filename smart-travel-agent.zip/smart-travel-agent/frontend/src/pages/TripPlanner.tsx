import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  BedDouble,
  Calendar,
  Cloud,
  Compass,
  IndianRupee,
  Landmark,
  ListOrdered,
  Map,
  MapPin,
  TrainFront,
  Users,
  UtensilsCrossed,
} from "lucide-react";
import PageHeader from "@/components/PageHeader";
import SectionTitle from "@/components/SectionTitle";
import { CardGridSkeleton, ErrorBanner, InfoNote, PlanningProgress, Spinner } from "@/components/Loader";
import PlaceCard from "@/components/PlaceCard";
import MapView, { type MapPoint } from "@/components/MapView";
import BudgetChart, { inrFormat } from "@/components/BudgetChart";
import ItineraryTimeline from "@/components/ItineraryTimeline";
import AgentStatusGrid from "@/components/AgentStatusGrid";
import AiModeBanner from "@/components/AiModeBanner";
import { BookingButtons } from "@/components/SourceBadge";
import { api, getSessionId } from "@/services/api";
import { useTripPrefill } from "@/context/TripPrefillContext";
import type { TripPlanResponse, TripRequest } from "@/types";

const INTERESTS = ["heritage", "history", "adventure", "wildlife", "beach", "spiritual", "food", "shopping", "nature", "photography", "art", "nightlife"];

function iso(offsetDays: number): string {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().slice(0, 10);
}

export default function TripPlanner() {
  const { consumePrefill } = useTripPrefill();
  const [form, setForm] = useState<Omit<TripRequest, "session_id" | "save_plan">>({
    origin_city: "Indore",
    destination_city: "Jaipur",
    start_date: iso(7),
    end_date: iso(10),
    travellers: 2,
    budget_inr: 40000,
    transport_mode: "any",
    trip_type: "leisure",
    interests: ["heritage", "food"],
    hotel_preference: "mid-range",
    food_preference: "any",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [plan, setPlan] = useState<TripPlanResponse | null>(null);

  // Prefill from Explore India.
  useEffect(() => {
    const prefill = consumePrefill();
    if (prefill?.destination) setForm((f) => ({ ...f, destination_city: prefill.destination! }));
    if (prefill?.origin) setForm((f) => ({ ...f, origin_city: prefill.origin! }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const days = useMemo(() => {
    const start = new Date(form.start_date);
    const end = new Date(form.end_date);
    return Math.max(1, Math.round((end.getTime() - start.getTime()) / 86400000) + 1);
  }, [form.start_date, form.end_date]);

  const set = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  const toggleInterest = (i: string) =>
    setForm((f) => ({
      ...f,
      interests: f.interests.includes(i) ? f.interests.filter((x) => x !== i) : [...f.interests, i],
    }));

  const generate = async () => {
    setLoading(true);
    setError(null);
    setPlan(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
    try {
      const payload: TripRequest = { ...form, session_id: getSessionId(), save_plan: true };
      const result = await api.planTrip(payload);
      setPlan(result);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Planning failed");
    } finally {
      setLoading(false);
    }
  };

  const mapPoints: MapPoint[] = plan
    ? [
        plan.map_center && { lat: plan.map_center.lat, lon: plan.map_center.lon, name: plan.map_center.name ?? "Destination", category: "destination" as const },
        ...plan.hotels.slice(0, 12).map((h) => ({ lat: h.lat, lon: h.lon, name: h.name, category: "hotel" as const, detail: h.category, link: h.directions_link })),
        ...plan.restaurants.slice(0, 12).map((r) => ({ lat: r.lat, lon: r.lon, name: r.name, category: "restaurant" as const, detail: r.cuisine ?? "", link: r.directions_link })),
        ...plan.attractions.slice(0, 14).map((a) => ({ lat: a.lat, lon: a.lon, name: a.name, category: "attraction" as const, detail: a.category, link: a.directions_link })),
      ].filter(Boolean) as MapPoint[]
    : [];

  return (
    <div>
      <PageHeader
        eyebrow="Multi-agent orchestration"
        title="AI Trip Planner"
        subtitle="The Master Travel Agent coordinates transport, hotel, restaurant, attraction, weather, budget, itinerary, recommendation and verification agents - all on live public data."
        icon={<Compass className="h-6 w-6 text-teal-light" />}
      />

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        {/* ---------------- FORM ---------------- */}
        <section className="card p-6" id="planner-form">
          <div className="grid gap-4 md:grid-cols-3">
            <label className="block">
              <span className="field-label">Starting city</span>
              <input className="field" value={form.origin_city} onChange={(e) => set("origin_city", e.target.value)} />
            </label>
            <label className="block">
              <span className="field-label">Destination</span>
              <input className="field" value={form.destination_city} onChange={(e) => set("destination_city", e.target.value)} />
            </label>
            <label className="block">
              <span className="field-label">Travellers</span>
              <div className="relative">
                <Users className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <input
                  type="number"
                  min={1}
                  max={20}
                  className="field pl-9"
                  value={form.travellers}
                  onChange={(e) => set("travellers", Math.max(1, Math.min(20, Number(e.target.value) || 1)))}
                />
              </div>
            </label>
            <label className="block">
              <span className="field-label">
                <Calendar className="mr-1 inline h-3 w-3" /> Departure date
              </span>
              <input type="date" min={iso(0)} className="field" value={form.start_date} onChange={(e) => set("start_date", e.target.value)} />
            </label>
            <label className="block">
              <span className="field-label">Return date</span>
              <input type="date" min={form.start_date} className="field" value={form.end_date} onChange={(e) => set("end_date", e.target.value)} />
            </label>
            <label className="block">
              <span className="field-label">
                <IndianRupee className="mr-1 inline h-3 w-3" /> Total budget (INR)
              </span>
              <input
                type="number"
                min={1000}
                step={1000}
                className="field"
                value={form.budget_inr}
                onChange={(e) => set("budget_inr", Math.max(1000, Number(e.target.value) || 0))}
              />
            </label>
            <label className="block">
              <span className="field-label">Transport mode</span>
              <select className="field" value={form.transport_mode} onChange={(e) => set("transport_mode", e.target.value as TripRequest["transport_mode"])}>
                <option value="any">All modes</option>
                <option value="train">Train</option>
                <option value="bus">Bus</option>
                <option value="flight">Flight</option>
                <option value="car">Car (self drive)</option>
              </select>
            </label>
            <label className="block">
              <span className="field-label">Trip type</span>
              <select className="field" value={form.trip_type} onChange={(e) => set("trip_type", e.target.value)}>
                {["leisure", "family", "adventure", "religious", "honeymoon", "business", "heritage"].map((t) => (
                  <option key={t} value={t} className="capitalize">
                    {t}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="field-label">Hotel preference</span>
              <select className="field" value={form.hotel_preference} onChange={(e) => set("hotel_preference", e.target.value)}>
                <option value="any">Any</option>
                <option value="budget">Budget</option>
                <option value="mid-range">Mid-range</option>
                <option value="luxury">Luxury</option>
                <option value="homestay">Homestay</option>
              </select>
            </label>
            <label className="block">
              <span className="field-label">Food preference</span>
              <select className="field" value={form.food_preference} onChange={(e) => set("food_preference", e.target.value)}>
                <option value="any">Any</option>
                <option value="vegetarian">Vegetarian</option>
                <option value="vegan">Vegan</option>
                <option value="local">Local cuisine</option>
                <option value="continental">Continental</option>
              </select>
            </label>
            <div className="md:col-span-2">
              <span className="field-label">Travel interests</span>
              <div className="flex flex-wrap gap-1.5">
                {INTERESTS.map((i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => toggleInterest(i)}
                    className={`chip border transition-colors ${
                      form.interests.includes(i)
                        ? "border-teal bg-teal text-white"
                        : "border-slate-200 bg-white text-navy-muted hover:border-teal"
                    }`}
                  >
                    {i}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <button className="btn-primary !px-7 !py-3 text-base" onClick={generate} disabled={loading}>
              {loading ? "Planning…" : "Generate Complete Trip Plan"}
            </button>
            <p className="text-xs text-navy-muted">
              {days} day(s) · {form.origin_city} → {form.destination_city} · plan is saved automatically
            </p>
          </div>
        </section>

        {loading && (
          <div className="mt-6 space-y-4">
            <PlanningProgress visible />
            <CardGridSkeleton count={3} />
          </div>
        )}
        {error && (
          <div className="mt-6">
            <ErrorBanner message={error} onRetry={generate} />
          </div>
        )}

        {/* ---------------- PLAN ---------------- */}
        {plan && (
          <div className="mt-8 space-y-8">
            <AiModeBanner mode={plan.ai_mode} />

            {/* A. Trip overview */}
            <section className="card overflow-hidden">
              <div className="bg-gradient-to-r from-navy to-deepsea p-6 text-white">
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-teal-light">Trip Overview</p>
                <h2 className="mt-1 text-2xl font-extrabold">{plan.title}</h2>
                <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
                  {[
                    ["Route", `${plan.overview.origin_city} → ${plan.overview.destination_city}`],
                    ["Duration", `${plan.overview.days} days / ${plan.overview.nights} nights`],
                    ["Travellers", `${plan.overview.travellers}`],
                    ["Budget", inrFormat(plan.overview.budget_inr)],
                  ].map(([k, v]) => (
                    <div key={k}>
                      <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-300">{k}</p>
                      <p className="mt-0.5 text-sm font-bold">{v}</p>
                    </div>
                  ))}
                </div>
              </div>
              {plan.destination_info && (
                <div className="p-6">
                  <h3 className="font-bold text-navy">
                    About {plan.destination_info.name}
                    {plan.destination_info.state ? `, ${plan.destination_info.state}` : ""}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-navy-muted">{plan.destination_info.description ?? "details unavailable in collected data"}</p>
                  {plan.destination_info.wiki_url && (
                    <a href={plan.destination_info.wiki_url} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block text-xs font-semibold text-teal underline decoration-dotted">
                      Verified source: {plan.destination_info.source.name} ↗
                    </a>
                  )}
                  {plan.notes.length > 0 && (
                    <ul className="mt-3 space-y-1">
                      {plan.notes.map((n) => (
                        <li key={n} className="text-[12px] text-navy-muted">• {n}</li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </section>

            {/* B. Transport */}
            <section>
              <SectionTitle
                title="Transport options"
                subtitle="Booking opens the provider's live search - the app never quotes fares itself"
              />
              <div className="grid gap-4 md:grid-cols-2">
                {plan.transport_options.map((t) => (
                  <div key={t.mode + t.provider} className="card p-5">
                    <div className="flex items-center justify-between">
                      <span className="chip bg-sand text-navy capitalize">{t.mode}</span>
                      <span className="text-xs font-semibold text-deepsea">{t.provider}</span>
                    </div>
                    <h3 className="mt-2 font-bold text-navy">{t.summary}</h3>
                    {t.detail && <p className="mt-1 text-[13px] leading-relaxed text-navy-muted">{t.detail}</p>}
                    {t.is_estimate && t.estimated_cost_inr != null && (
                      <p className="mt-2 text-xs font-semibold text-amber-700">
                        Estimate ≈ {inrFormat(t.estimated_cost_inr)} (not a quote)
                      </p>
                    )}
                    <BookingButtons links={t.booking_links} compact />
                    <div className="mt-3">
                      <a href={t.deep_link} target="_blank" rel="noopener noreferrer" className="btn-navy !px-4 !py-2 text-xs">
                        <TrainFront className="h-3.5 w-3.5" /> Open {t.provider}
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* C. Hotels */}
            <section>
              <SectionTitle title={`Accommodation (${plan.hotels.length})`} subtitle="Collected from OpenStreetMap · prices confirmed via booking links" />
              {plan.hotels.length ? (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {plan.hotels.slice(0, 9).map((h) => (
                    <PlaceCard key={h.name + h.lat} record={h} kind="hotel" />
                  ))}
                </div>
              ) : (
                <InfoNote>
                  No hotel records were available from the public providers for this destination. Use the transport
                  section's booking links to search live hotels on Booking.com / MakeMyTrip.
                </InfoNote>
              )}
            </section>

            {/* D. Restaurants */}
            <section>
              <SectionTitle title={`Restaurants & cafes (${plan.restaurants.length})`} subtitle="Vegetarian tags only appear where venues are tagged in OpenStreetMap" />
              {plan.restaurants.length ? (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {plan.restaurants.slice(0, 9).map((r) => (
                    <PlaceCard key={r.name + r.lat} record={r} kind="restaurant" />
                  ))}
                </div>
              ) : (
                <InfoNote>No restaurant data available from collected sources right now - try again later or explore on Google Maps.</InfoNote>
              )}
            </section>

            {/* E. Attractions */}
            <section>
              <SectionTitle title={`Tourist attractions (${plan.attractions.length})`} subtitle="Curated facts + live OpenStreetMap records, every item sourced" />
              {plan.attractions.length ? (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {plan.attractions.slice(0, 9).map((a) => (
                    <PlaceCard key={a.name + a.lat} record={a} kind="attraction" />
                  ))}
                </div>
              ) : (
                <InfoNote>No attraction records collected - the itinerary uses honest placeholders.</InfoNote>
              )}
            </section>

            {/* F. Weather */}
            <section>
              <SectionTitle title="Weather forecast" subtitle="Open-Meteo daily forecast for your travel window" />
              {plan.weather.length ? (
                <div className="card overflow-x-auto">
                  <table className="w-full min-w-[560px] text-sm">
                    <thead>
                      <tr className="border-b border-slate-100 text-left text-xs font-bold uppercase tracking-wide text-navy-muted">
                        <th className="px-5 py-3">Date</th>
                        <th className="px-5 py-3">Condition</th>
                        <th className="px-5 py-3">Min / Max</th>
                        <th className="px-5 py-3">Rain chance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {plan.weather.map((w) => (
                        <tr key={w.date} className="border-b border-slate-50">
                          <td className="px-5 py-3 font-semibold text-navy">
                            {new Date(w.date).toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" })}
                          </td>
                          <td className="px-5 py-3 text-navy-muted">{w.condition}</td>
                          <td className="px-5 py-3 text-navy-muted">
                            {w.temp_min_c ?? "?"}°C / {w.temp_max_c ?? "?"}°C
                          </td>
                          <td className="px-5 py-3 text-navy-muted">{w.precipitation_probability ?? "?"}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <InfoNote>{plan.weather_note || "Forecast unavailable for the selected dates (Open-Meteo free tier covers ~16 days ahead)."}</InfoNote>
              )}
            </section>

            {/* G. Budget */}
            <section>
              <SectionTitle title="Budget estimate" subtitle="Algorithmic estimates only - confirm real prices on provider sites" />
              <div className="grid gap-4 lg:grid-cols-2">
                <div className="card p-6">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-navy-muted">Estimated total</p>
                      <p className="text-3xl font-extrabold text-navy">{inrFormat(plan.budget.total_estimated_inr)}</p>
                      <p className="text-sm text-navy-muted">{inrFormat(plan.budget.per_person_inr)} per person</p>
                    </div>
                    <span className={`chip ${plan.budget.within_budget ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"}`}>
                      {plan.budget.within_budget ? "Within your budget" : "Over your budget"}
                    </span>
                  </div>
                  <BudgetChart budget={plan.budget} />
                  <p className="text-[11px] leading-relaxed text-navy-muted">{plan.budget.disclaimer}</p>
                </div>
                <div className="card p-6">
                  <ul className="space-y-2.5">
                    {plan.budget.categories.map((c) => (
                      <li key={c.category} className="flex items-center justify-between border-b border-slate-50 pb-2">
                        <div>
                          <p className="text-sm font-semibold text-navy">{c.category}</p>
                          <p className="text-[11px] text-navy-muted">{c.note}</p>
                        </div>
                        <p className="text-sm font-bold text-deepsea">{inrFormat(c.estimated_inr)}</p>
                      </li>
                    ))}
                  </ul>
                  <details className="mt-4">
                    <summary className="cursor-pointer text-xs font-bold uppercase tracking-wide text-teal">Assumptions used</summary>
                    <ul className="mt-2 space-y-1">
                      {plan.budget.assumptions.map((a) => (
                        <li key={a} className="text-[12px] text-navy-muted">• {a}</li>
                      ))}
                    </ul>
                  </details>
                </div>
              </div>
            </section>

            {/* H. Itinerary */}
            <section>
              <SectionTitle title="Day-wise itinerary" subtitle="Attractions scheduled geographically · timings are never invented" />
              <ItineraryTimeline days={plan.itinerary} />
            </section>

            {/* I. Map */}
            <section>
              <SectionTitle title="Interactive map" subtitle="Destination (dark), hotels (blue), restaurants (orange), attractions (green)" />
              {plan.map_center && (
                <MapView center={plan.map_center} points={mapPoints} height={460} />
              )}
            </section>

            {/* J. Booking actions + verification */}
            <section className="grid gap-4 lg:grid-cols-2">
              <AgentStatusGrid statuses={plan.agent_statuses} />
              <div className="card p-5">
                <h3 className="font-bold text-navy">Verification report</h3>
                <p className="mt-1 text-sm text-navy-muted">{plan.verification.summary}</p>
                {plan.verification.issues.length > 0 && (
                  <details className="mt-3">
                    <summary className="cursor-pointer text-xs font-bold uppercase tracking-wide text-teal">
                      {plan.verification.issues.length} issue(s)
                    </summary>
                    <ul className="mt-2 max-h-48 space-y-1.5 overflow-y-auto pr-1 scroll-thin">
                      {plan.verification.issues.slice(0, 30).map((i, idx) => (
                        <li key={idx} className="text-[12px] text-navy-muted">
                          <span className="font-semibold text-navy">{i.record}</span>: {i.detail}
                        </li>
                      ))}
                    </ul>
                  </details>
                )}
                <div className="mt-4 flex flex-wrap gap-2">
                  {plan.trip_id && (
                    <>
                      <a className="btn-outline !py-2 text-xs" href={api.exportXlsxUrl(plan.trip_id)}>
                        <ListOrdered className="h-3.5 w-3.5" /> Export Excel
                      </a>
                      <a className="btn-outline !py-2 text-xs" href={api.exportCsvUrl(plan.trip_id)}>
                        <Landmark className="h-3.5 w-3.5" /> Export CSV
                      </a>
                      <Link to="/saved-trips" className="btn-primary !py-2 text-xs">
                        <Map className="h-3.5 w-3.5" /> View in Saved Trips
                      </Link>
                    </>
                  )}
                </div>
              </div>
            </section>
          </div>
        )}
      </div>
    </div>
  );
}
