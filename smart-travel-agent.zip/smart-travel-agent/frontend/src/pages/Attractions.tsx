import { useState } from "react";
import { Landmark } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import PlaceCard from "@/components/PlaceCard";
import { CardGridSkeleton, EmptyState, ErrorBanner, InfoNote } from "@/components/Loader";
import { api } from "@/services/api";
import { useCitySearch } from "@/hooks/useCitySearch";
import type { PlaceRecord } from "@/types";

interface AttractionsResponse {
  city: string;
  attractions: PlaceRecord[];
}

export default function Attractions() {
  const search = useCitySearch("Jaipur");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<AttractionsResponse | null>(null);
  const [checked, setChecked] = useState(false);

  const run = async () => {
    setChecked(true);
    setLoading(true);
    setError(null);
    try {
      setData(await api.attractions<AttractionsResponse>(search.city || "Jaipur"));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Search failed");
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <PageHeader
        eyebrow="Curated + live OpenStreetMap"
        title="Tourist Attractions"
        subtitle="Famous sights from the curated reference dataset plus live POI records, each with description and verified source links."
        icon={<Landmark className="h-6 w-6 text-teal-light" />}
      />
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <section className="card flex flex-col gap-3 p-5 sm:flex-row">
          <input
            className="field flex-1"
            placeholder="Enter a city, e.g. Jaipur, Agra, Hampi…"
            value={search.city}
            onChange={(e) => search.setCity(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && run()}
            aria-label="City to search attractions"
          />
          <button className="btn-primary sm:w-48" onClick={run} disabled={loading}>
            {loading ? "Searching…" : "Find attractions"}
          </button>
        </section>

        {error && <div className="mt-6"><ErrorBanner message={error} onRetry={run} /></div>}
        {loading && <div className="mt-6"><CardGridSkeleton count={6} /></div>}

        {!loading && data && (
          <>
            <p className="mt-8 text-sm text-navy-muted">
              <b className="text-navy">{data.attractions.length}</b> attraction(s) in <b className="text-navy">{data.city}</b>
            </p>
            <div className="mt-4 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {data.attractions.slice(0, 24).map((a) => (
                <PlaceCard key={a.name + a.lat} record={a} kind="attraction" />
              ))}
            </div>
            {data.attractions.length === 0 && (
              <div className="mt-5">
                <EmptyState
                  title={`No attraction records collected for ${data.city}`}
                  hint="Try a larger nearby city. Curated coverage includes 100+ destinations across all Indian states."
                />
              </div>
            )}
            <div className="mt-8">
              <InfoNote>
                Curated entries carry OpenStreetMap coordinates and Wikipedia source links; live entries are tagged
                `tourism=attraction`, `historic=*` or similar in OpenStreetMap.
              </InfoNote>
            </div>
          </>
        )}

        {!checked && !loading && <div className="mt-6"><InfoNote>Try Jaipur, Agra, Delhi, Varanasi, Khajuraho, Hampi or any Indian city.</InfoNote></div>}
      </div>
    </div>
  );
}
