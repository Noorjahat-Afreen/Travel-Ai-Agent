import { Bot, Code2, Cpu, Database, ExternalLink, Github, Layers, Server, ShieldCheck } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import { InfoNote } from "@/components/Loader";

const STACK = [
  { icon: Layers, title: "Frontend", lines: ["React 18 + TypeScript", "Vite 5, Tailwind CSS, Framer Motion", "React Router, Leaflet maps, Recharts"] },
  { icon: Server, title: "Backend", lines: ["Python FastAPI + Pydantic v2", "SQLAlchemy 2.0 ORM (SQLite / PostgreSQL)", "Rate limiting, caching, GZip, CORS"] },
  { icon: Cpu, title: "AI & Agents", lines: ["Google Gemini via LangChain", "12 specialised agents + master orchestrator", "BM25 RAG retrieval over SQLite"] },
  { icon: Database, title: "Data & CV", lines: ["Nominatim · Overpass · Wikipedia · Open-Meteo · OSRM", "OpenCV: grayscale, blur, Canny, K-means", "Gemini Vision landmark recognition"] },
];

const AGENTS = [
  "Master Travel Agent", "Destination Discovery", "Transport", "Hotel", "Restaurant",
  "Tourist Attraction", "Weather", "Budget", "Itinerary", "Computer Vision",
  "Verification", "Recommendation",
];

const SOURCES = [
  { name: "OpenStreetMap Nominatim", url: "https://nominatim.openstreetmap.org", policy: "https://operations.osmfoundation.org/policies/nominatim/" },
  { name: "OpenStreetMap Overpass", url: "https://overpass-api.de", policy: "https://dev.overpass-api.de/overpass-doc/" },
  { name: "Open-Meteo", url: "https://open-meteo.com", policy: "https://open-meteo.com/en/terms" },
  { name: "Wikipedia REST API", url: "https://en.wikipedia.org/api/rest_v1", policy: "https://www.mediawiki.org/wiki/API:REST_api" },
  { name: "OSRM demo router", url: "https://router.project-osrm.org", policy: "https://github.com/Project-OSRM/osrm-backend" },
  { name: "Photon (Komoot)", url: "https://photon.komoot.io", policy: "https://photon.komoot.io" },
];

export default function About() {
  return (
    <div>
      <PageHeader
        eyebrow="B.Tech CSE (AI & ML) · Major Project"
        title="About This Project"
        subtitle="An AI-powered smart travel agent for India: a complete full-stack platform with multi-agent orchestration, real public-data integration, computer vision and honest handling of missing information."
        icon={<Code2 className="h-6 w-6 text-teal-light" />}
      />

      <div className="mx-auto max-w-6xl space-y-10 px-4 py-10 sm:px-6">
        {/* Objective */}
        <section>
          <h2 className="text-xl font-bold text-navy">Objective</h2>
          <p className="mt-2 max-w-3xl text-sm leading-relaxed text-navy-muted">
            Help travellers plan complete journeys anywhere in India. Users enter a starting city, destination, dates,
            travellers and budget; a Master Travel Agent coordinates specialised agents that collect real data
            (geocoding, hotels, restaurants, attractions, weather, transport deep links), compute transparent budget
            estimates, generate day-wise itineraries and verify every record's source before display.
          </p>
        </section>

        {/* Stack */}
        <section>
          <h2 className="text-xl font-bold text-navy">Technology stack</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            {STACK.map((s) => (
              <div key={s.title} className="card p-5">
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-navy text-teal-light">
                    <s.icon className="h-5 w-5" />
                  </span>
                  <h3 className="font-bold text-navy">{s.title}</h3>
                </div>
                <ul className="mt-3 space-y-1.5">
                  {s.lines.map((l) => (
                    <li key={l} className="text-[13px] text-navy-muted">• {l}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>

        {/* Agents */}
        <section>
          <h2 className="text-xl font-bold text-navy">
            <Bot className="mr-2 inline h-5 w-5 text-teal" /> The multi-agent architecture
          </h2>
          <p className="mt-2 max-w-3xl text-sm leading-relaxed text-navy-muted">
            Each agent has a real responsibility and reports a transparent status (ok / degraded / error). Independent
            agents run in parallel; dependent agents consume their outputs. The execution trace is visible on every
            generated plan.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            {AGENTS.map((a) => (
              <span key={a} className="chip bg-white text-navy shadow-card">{a}</span>
            ))}
          </div>
        </section>

        {/* Data ethics */}
        <section>
          <h2 className="text-xl font-bold text-navy">
            <ShieldCheck className="mr-2 inline h-5 w-5 text-teal" /> Data honesty rules
          </h2>
          <ul className="mt-3 grid gap-2 text-sm text-navy-muted md:grid-cols-2">
            {[
              "No invented hotels, restaurants, fares, ratings or availability.",
              "Estimated prices are always labelled 'ESTIMATE', never mixed with real quotes.",
              "Every record carries a source name, link and retrieval timestamp.",
              "Missing information displays exactly: 'details unavailable in collected data'.",
              "API failures degrade gracefully - other features keep working.",
              "Nominatim / Overpass usage policies respected (caching + rate limits).",
              "The app never claims a booking is completed; booking happens on provider sites.",
              "API keys stay in backend .env - never bundled into the React app.",
            ].map((r) => (
              <li key={r} className="rounded-lg bg-white p-3 shadow-card">✓ {r}</li>
            ))}
          </ul>
        </section>

        {/* Sources */}
        <section>
          <h2 className="text-xl font-bold text-navy">Data sources & policies</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {SOURCES.map((s) => (
              <div key={s.name} className="card p-4">
                <a href={s.url} target="_blank" rel="noopener noreferrer" className="font-bold text-navy hover:text-teal">
                  {s.name} <ExternalLink className="inline h-3 w-3" />
                </a>
                <a href={s.policy} target="_blank" rel="noopener noreferrer" className="mt-1 block text-[11px] text-navy-muted underline decoration-dotted">
                  usage policy ↗
                </a>
              </div>
            ))}
          </div>
        </section>

        {/* Docs */}
        <section>
          <h2 className="text-xl font-bold text-navy">
            <Github className="mr-2 inline h-5 w-5 text-teal" /> Documentation in the repository
          </h2>
          <ul className="mt-3 space-y-1.5 text-sm text-navy-muted">
            <li>• <b className="text-navy">README.md</b> - quick start for Windows / Linux/macOS</li>
            <li>• <b className="text-navy">docs/ARCHITECTURE.md</b> - system design and agent pipeline</li>
            <li>• <b className="text-navy">docs/DEPLOYMENT.md</b> - Render + Vercel + PostgreSQL</li>
            <li>• <b className="text-navy">docs/DATA_SOURCES.md</b> - provider list and attribution</li>
            <li>• <b className="text-navy">backend/tests/</b> - 95 automated tests (API, agents, budget, vision, exports)</li>
          </ul>
          <div className="mt-5">
            <InfoNote>
              Run the backend with <code className="rounded bg-sand px-1.5 py-0.5 text-[12px]">uvicorn main:app --port 8000</code> and
              the frontend with <code className="rounded bg-sand px-1.5 py-0.5 text-[12px]">npm run dev</code> - the Vite
              dev server proxies <code className="rounded bg-sand px-1.5 py-0.5 text-[12px]">/api</code> automatically.
            </InfoNote>
          </div>
        </section>
      </div>
    </div>
  );
}
