import { useState } from "react";
import { BedDouble, Building2 } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import PlaceCard from "@/components/PlaceCard";
import { CardGridSkeleton, EmptyState, ErrorBanner, InfoNote } from "@/components/Loader";
import { BookingButtons } from "@/components/SourceBadge";
import { api } from "@/services/api";
import { useCitySearch } from "@/hooks/useCitySearch";
import type { BookingLink, PlaceRecord } from "@/types";

interface HotelsResponse {
  city: string;
  state: string;
  hotels: PlaceRecord[];
  booking_links: BookingLink[];
}

export default function Hotels() {
  const search = useCitySearch("Jaipur");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<HotelsResponse | null>(null);
  const [checked, setChecked] = useState(false);

  const run = async () => {
    search.submit();
    if (!search.city.trim() && !search.submitted) return;
    setLoading(true);
    setError(null);
    setChecked(true);
    try {
      setData(await api.hotels<HotelsResponse>(search.city || search.submitted));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Search failed");
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <PageHeader
        eyebrow="OpenStreetMap data + booking links"
        title="Hotel Finder"
        subtitle="Real accommodation records collected from public OpenStreetMap data. Prices and availability are never invented - use the prefilled booking links to confirm on the provider."
        icon={<Building2 className="h-6 w-6 text-teal-light" />}
      />
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <section className="card flex flex-col gap-3 p-5 sm:flex-row">
          <input
            className="field flex-1"
            placeholder="Enter a city, e.g. Jaipur, Udaipur, Kochi…"
            value={search.city}
            onChange={(e) => search.setCity(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && run()}
            aria-label="City to search hotels"
          />
          <button className="btn-primary sm:w-48" onClick={run} disabled={loading}>
            {loading ? "Searching…" : "Find hotels"}
          </button>
        </section>

        {error && <div className="mt-6"><ErrorBanner message={error} onRetry={run} /></div>}

        {loading && <div className="mt-6"><CardGridSkeleton count={6} /></div>}

        {!loading && data && (
          <>
            <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm text-navy-muted">
                <BedDouble className="mr-1 inline h-4 w-4 text-teal" />
                <b className="text-navy">{data.hotels.length}</b> record(s) in <b className="text-navy">{data.city}</b>
                {data.state ? `, ${data.state}` : ""} · sorted by distance from centre
              </p>
              <div className="flex flex-wrap gap-2">
                {data.booking_links.map((l) => (
                  <a key={l.url} href={l.url} target="_blank" rel="noopener noreferrer" className="btn-primary !py-2 text-xs">
                    {l.label} ↗
                  </a>
                ))}
              </div>
            </div>

            <div className="mt-5 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {data.hotels.slice(0, 18).map((h) => (
                <PlaceCard key={h.name + h.lat} record={h} kind="hotel" />
              ))}
            </div>
            {data.hotels.length === 0 && (
              <div className="mt-5">
                <EmptyState
                  title={`No hotel records collected for ${data.city}`}
                  hint="The public POI providers had no named hotels within 12 km, or they are temporarily unreachable. Booking links above still work - they open the provider's live search."
                />
              </div>
            )}
            <div className="mt-8">
              <InfoNote>
                Hotel records carry source attribution (OpenStreetMap Overpass / Photon). The app does not store or
                display ratings or prices that providers have not published in open data.
              </InfoNote>
            </div>
          </>
        )}

        {!checked && !loading && (
          <div className="mt-6">
            <InfoNote>Try Jaipur, Udaipur, Manali, Kochi, Varanasi or any Indian city.</InfoNote>
          </div>
        )}
      </div>
    </div>
  );
}

export { BookingButtons };
