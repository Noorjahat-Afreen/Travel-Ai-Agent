import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Bot, Cpu, Eraser, Send, ShieldCheck, Sparkles, User } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import { EmptyState, InfoNote } from "@/components/Loader";
import { SourceBadge } from "@/components/SourceBadge";
import { api, getSessionId } from "@/services/api";
import type { ChatResponse } from "@/types";

interface Message extends ChatResponse {
  role: "user" | "assistant";
  text: string;
}

const SUGGESTIONS = [
  "Plan a trip from Indore to Manali",
  "Find budget hotels in Jaipur",
  "Suggest restaurants in Udaipur",
  "Compare train and flight options Delhi to Goa",
  "Create a five-day Rajasthan itinerary",
  "Weather in Shimla next week",
];

function DataCardView({ card }: { card: { title: string; kind: string; items: Record<string, unknown>[] } }) {
  if (!card.items.length) return null;
  return (
    <div className="mt-2 rounded-xl2 border border-slate-200 bg-white p-3">
      <p className="text-[11px] font-bold uppercase tracking-wide text-teal">{card.title}</p>
      <div className="mt-2 max-h-64 space-y-2 overflow-y-auto pr-1 scroll-thin">
        {card.items.slice(0, 8).map((item, i) => (
          <div key={i} className="rounded-lg bg-mist p-2.5 text-[12.5px] text-navy">
            {card.kind === "weather" ? (
              <span className="flex flex-wrap gap-x-3">
                <b>{String(item.date ?? "")}</b>
                <span>{String(item.condition ?? "")}</span>
                <span>
                  {String(item.temp_min_c ?? "?")}–{String(item.temp_max_c ?? "?")}°C
                </span>
                <span>rain {String(item.precipitation_probability ?? "?")}%</span>
              </span>
            ) : card.kind === "transport" ? (
              <a href={String(item.url ?? "#")} target="_blank" rel="noopener noreferrer" className="font-semibold text-teal hover:underline">
                {String(item.label ?? item.provider ?? "Open")} · {String(item.provider ?? "")} ↗
              </a>
            ) : card.kind === "budget" ? (
              <span className="flex flex-wrap gap-x-3">
                {Object.entries(item)
                  .filter(([k]) => ["total_estimated_inr", "per_person_inr", "within_budget"].includes(k))
                  .map(([k, v]) => (
                    <span key={k}>
                      <b>{k.replace(/_/g, " ")}:</b> {String(v)}
                    </span>
                  ))}
              </span>
            ) : (
              <>
                <b>{String(item.name ?? "")}</b>
                {item.distance_km != null ? <span className="text-navy-muted"> · {String(item.distance_km)} km</span> : null}
                {item.cuisine ? <span className="text-navy-muted"> · {String(item.cuisine)}</span> : null}
                {item.vegetarian === true ? <span className="chip ml-1 bg-emerald-100 text-emerald-800">Veg tagged</span> : null}
                {item.description ? <p className="mt-1 text-navy-muted">{String(item.description)}</p> : null}
                {item.source ? <p className="mt-0.5 text-[10.5px] text-navy-muted">Source: {String(item.source)}</p> : null}
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Chatbot() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const sessionId = useRef(getSessionId());
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMessages([
      {
        role: "assistant",
        text:
          "Namaste! I'm your AI travel assistant for India. Ask me about destinations, hotels, restaurants, weather, budget estimates or transport links - I answer using live collected data and never invent prices or availability.",
        role2: undefined,
      } as unknown as Message,
    ]);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const send = async (text?: string) => {
    const message = (text ?? input).trim();
    if (!message || loading) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: message, reply: "", mode: "local", sources: [], data_cards: [], suggestions: [], tool_trace: [] }]);
    setLoading(true);
    try {
      const response = await api.chat(sessionId.current, message);
      setMessages((m) => [...m, { role: "assistant", text: response.reply, ...response }]);
    } catch (e) {
      setMessages((m) => [
        ...m,
        {
          role: "assistant",
          text: e instanceof Error ? `Sorry - ${e.message}` : "Something went wrong.",
          reply: "", mode: "local", sources: [], data_cards: [], suggestions: [], tool_trace: [],
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const clearHistory = async () => {
    try {
      await api.clearChatHistory(sessionId.current);
      setMessages([]);
    } catch {
      /* ignore */
    }
  };

  return (
    <div>
      <PageHeader
        eyebrow="LangChain tool-calling assistant"
        title="AI Travel Assistant"
        subtitle="Grounded conversation: the assistant calls the same data tools as the planner agents, so answers carry real records with sources - never invented availability."
        icon={<Bot className="h-6 w-6 text-teal-light" />}
      />

      <div className="mx-auto grid max-w-5xl gap-5 px-4 py-8 sm:px-6 lg:grid-cols-[1fr_260px]">
        {/* Chat column */}
        <section className="card flex h-[640px] flex-col overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3.5">
            <div className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-navy text-teal-light">
                <Sparkles className="h-4 w-4" />
              </span>
              <p className="text-sm font-bold text-navy">Travel Assistant</p>
            </div>
            <button className="btn-ghost text-xs" onClick={clearHistory} title="Conversation memory is stored per session with your consent - clear it any time">
              <Eraser className="h-3.5 w-3.5" /> Clear memory
            </button>
          </div>

          <div className="flex-1 space-y-4 overflow-y-auto bg-mist/60 px-4 py-4 scroll-thin">
            {messages.map((m, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className={`flex gap-2.5 ${m.role === "user" ? "justify-end" : ""}`}>
                {m.role === "assistant" && (
                  <span className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-navy text-teal-light">
                    <Cpu className="h-4 w-4" />
                  </span>
                )}
                <div className={`max-w-[85%] ${m.role === "user" ? "rounded-xl2 rounded-br-sm bg-teal px-4 py-3 text-sm text-white" : ""}`}>
                  {m.role === "assistant" ? (
                    <div className="rounded-xl2 rounded-bl-sm bg-white p-4 shadow-card">
                      <p className="whitespace-pre-wrap text-[13.5px] leading-relaxed text-ink">{m.text}</p>
                      {m.data_cards?.map((c, ci) => <DataCardView key={ci} card={c} />)}
                      {m.tool_trace && m.tool_trace.length > 0 && (
                        <p className="mt-2 text-[10.5px] text-navy-muted">Tools used: {m.tool_trace.join(" → ")}</p>
                      )}
                      {m.sources && m.sources.length > 0 && (
                        <div className="mt-1.5 flex flex-wrap gap-2">
                          {m.sources.slice(0, 2).map((s, si) => (
                            <SourceBadge key={si} source={s} />
                          ))}
                        </div>
                      )}
                      {m.mode === "local" && (
                        <p className="mt-2 border-t border-slate-100 pt-2 text-[10.5px] text-navy-muted">
                          Local mode: deterministic answer from collected data. Set GEMINI_API_KEY in backend/.env for full conversational AI.
                        </p>
                      )}
                    </div>
                  ) : (
                    <p className="whitespace-pre-wrap">{m.text}</p>
                  )}
                </div>
                {m.role === "user" && (
                  <span className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-teal text-white">
                    <User className="h-4 w-4" />
                  </span>
                )}
              </motion.div>
            ))}
            {loading && (
              <div className="flex items-center gap-2 text-xs text-navy-muted">
                <Cpu className="h-4 w-4 animate-pulse text-teal" /> Retrieving live data and composing an answer…
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          <div className="border-t border-slate-100 bg-white p-3">
            <div className="flex gap-2">
              <input
                className="field flex-1"
                placeholder="Ask anything about travelling in India…"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && send()}
                aria-label="Message the assistant"
                disabled={loading}
              />
              <button className="btn-primary !px-4" onClick={() => send()} disabled={loading || !input.trim()} aria-label="Send message">
                <Send className="h-4 w-4" />
              </button>
            </div>
          </div>
        </section>

        {/* Suggestions column */}
        <aside className="space-y-4">
          <div className="card p-4">
            <p className="text-xs font-bold uppercase tracking-wide text-navy-muted">Suggested prompts</p>
            <div className="mt-3 space-y-2">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  disabled={loading}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-left text-[12.5px] font-medium text-navy transition-colors hover:border-teal hover:text-teal"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
          <InfoNote>
            <ShieldCheck className="mr-1 inline h-3.5 w-3.5 text-teal" />
            The assistant stores this conversation per session id (with your consent) and never records personal
            data. Clear memory any time with the button above. If the backend is offline, prompts will error - start
            uvicorn on port 8000.
          </InfoNote>
        </aside>
      </div>
    </div>
  );
}
