import { useState } from "react";
import { CloudSun, IndianRupee } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import { CardGridSkeleton, EmptyState, ErrorBanner, InfoNote } from "@/components/Loader";
import BudgetChart, { inrFormat } from "@/components/BudgetChart";
import { api } from "@/services/api";
import type { BudgetBreakdown, WeatherDay } from "@/types";

interface WeatherResponse {
  city: string;
  state: string;
  available: boolean;
  note: string;
  days: WeatherDay[];
}

function iso(offset: number): string {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toISOString().slice(0, 10);
}

export default function WeatherBudget() {
  const [city, setCity] = useState("Shimla");
  const [start, setStart] = useState(iso(0));
  const [end, setEnd] = useState(iso(4));
  const [wLoading, setWLoading] = useState(false);
  const [wError, setWError] = useState<string | null>(null);
  const [weather, setWeather] = useState<WeatherResponse | null>(null);

  // Budget calculator (client-side mirror of the BudgetAgent formula, labelled estimates)
  const [days, setDays] = useState(4);
  const [travellers, setTravellers] = useState(2);
  const [distance, setDistance] = useState(600);
  const [mode, setMode] = useState("train");
  const [tier, setTier] = useState("mid-range");
  const [food, setFood] = useState(500);

  const RATE = { train: 1.3, bus: 1.6, flight: 2.4, car: 9.0 } as Record<string, number>;
  const MIN = { train: 180, bus: 250, flight: 2200, car: 400 } as Record<string, number>;
  const HOTEL = { budget: 1200, "mid-range": 2800, luxury: 7500, homestay: 1800, any: 2500 } as Record<string, number>;

  const budget: BudgetBreakdown = (() => {
    const oneWay = Math.max(MIN[mode] ?? 180, distance * (RATE[mode] ?? 1.3));
    const transport = Math.round(oneWay * 2 * travellers);
    const nights = Math.max(days - 1, 1);
    const hotel = Math.round((HOTEL[tier] ?? 2500) * nights * Math.max(1, Math.round(travellers / 2)));
    const foodTotal = Math.round(food * days * travellers);
    const activities = Math.round(300 * days * travellers);
    const local = Math.round(350 * days);
    const subtotal = transport + hotel + foodTotal + activities + local;
    const emergency = Math.round(subtotal * 0.1);
    return {
      total_estimated_inr: subtotal + emergency,
      per_person_inr: Math.round((subtotal + emergency) / travellers),
      within_budget: subtotal + emergency <= Number((document.getElementById("budget-input") as HTMLInputElement)?.value || Infinity),
      user_budget_inr: 0,
      categories: [
        { category: "Transport", estimated_inr: transport, note: `${mode} round trip`, is_estimate: true },
        { category: "Hotel", estimated_inr: hotel, note: `${tier} × ${nights} nights`, is_estimate: true },
        { category: "Food", estimated_inr: foodTotal, note: `₹${food}/person/day`, is_estimate: true },
        { category: "Activities", estimated_inr: activities, note: "entry fees", is_estimate: true },
        { category: "Local travel", estimated_inr: local, note: "autos/cabs", is_estimate: true },
        { category: "Emergency buffer", estimated_inr: emergency, note: "10%", is_estimate: true },
      ],
      assumptions: ["Client-side mirror of the BudgetAgent formula for quick what-if analysis."],
      disclaimer: "All amounts are ESTIMATES. Real prices come from provider booking links.",
    };
  })();

  const fetchWeather = async () => {
    setWLoading(true);
    setWError(null);
    try {
      setWeather(await api.weather<WeatherResponse>(city, start, end));
    } catch (e) {
      setWError(e instanceof Error ? e.message : "Weather fetch failed");
    } finally {
      setWLoading(false);
    }
  };

  return (
    <div>
      <PageHeader
        eyebrow="Open-Meteo forecasts · transparent estimates"
        title="Weather & Budget"
        subtitle="Check the forecast window supported by Open-Meteo's free API and play with the budget model used by the agents. Estimates are clearly separated from provider prices."
        icon={<CloudSun className="h-6 w-6 text-teal-light" />}
      />

      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-8 sm:px-6 lg:grid-cols-2">
        {/* Weather */}
        <section>
          <div className="card p-5">
            <div className="grid gap-3 sm:grid-cols-[1fr_auto]">
              <input className="field" placeholder="City, e.g. Shimla" value={city} onChange={(e) => setCity(e.target.value)} aria-label="City" />
              <button className="btn-primary" onClick={fetchWeather} disabled={wLoading}>
                {wLoading ? "Fetching…" : "Get forecast"}
              </button>
              <label className="block">
                <span className="field-label">From</span>
                <input type="date" className="field" value={start} onChange={(e) => setStart(e.target.value)} />
              </label>
              <label className="block">
                <span className="field-label">To</span>
                <input type="date" className="field" value={end} onChange={(e) => setEnd(e.target.value)} />
              </label>
            </div>
          </div>

          {wError && <div className="mt-4"><ErrorBanner message={wError} onRetry={fetchWeather} /></div>}
          {wLoading && <div className="mt-6"><CardGridSkeleton count={2} /></div>}

          {weather && !wLoading && (
            <div className="mt-6">
              {weather.available && weather.days.length ? (
                <div className="grid gap-3 sm:grid-cols-2">
                  {weather.days.map((d) => (
                    <div key={d.date} className="card p-4">
                      <p className="text-sm font-bold text-navy">
                        {new Date(d.date).toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "short" })}
                      </p>
                      <p className="mt-1 text-2xl font-extrabold text-deepsea">
                        {d.temp_max_c ?? "?"}°C <span className="text-sm font-medium text-navy-muted">/ {d.temp_min_c ?? "?"}°C</span>
                      </p>
                      <p className="text-sm text-navy-muted">{d.condition}</p>
                      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-sand">
                        <div className="h-full rounded-full bg-teal" style={{ width: `${d.precipitation_probability ?? 0}%` }} />
                      </div>
                      <p className="mt-1 text-[11px] text-navy-muted">Rain chance {d.precipitation_probability ?? 0}%</p>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState title="Forecast unavailable" hint={weather.note} />
              )}
            </div>
          )}
          <div className="mt-6">
            <InfoNote>
              Open-Meteo's free daily API supports ~16 days ahead. Dates beyond that are honestly refused instead of
              guessed. Source: <a href="https://open-meteo.com/en/docs" target="_blank" rel="noopener noreferrer" className="font-semibold text-teal underline">open-meteo.com</a>
            </InfoNote>
          </div>
        </section>

        {/* Budget */}
        <section>
          <div className="card p-5">
            <h2 className="flex items-center gap-2 font-bold text-navy">
              <IndianRupee className="h-4 w-4 text-teal" /> Budget calculator
            </h2>
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
              <label><span className="field-label">Days</span><input type="number" min={1} max={30} className="field" value={days} onChange={(e) => setDays(Math.max(1, Number(e.target.value) || 1))} /></label>
              <label><span className="field-label">Travellers</span><input type="number" min={1} max={20} className="field" value={travellers} onChange={(e) => setTravellers(Math.max(1, Number(e.target.value) || 1))} /></label>
              <label><span className="field-label">Distance (km)</span><input type="number" min={50} step={50} className="field" value={distance} onChange={(e) => setDistance(Math.max(50, Number(e.target.value) || 50))} /></label>
              <label>
                <span className="field-label">Mode</span>
                <select className="field" value={mode} onChange={(e) => setMode(e.target.value)}>
                  <option value="train">Train</option><option value="bus">Bus</option><option value="flight">Flight</option><option value="car">Car</option>
                </select>
              </label>
              <label>
                <span className="field-label">Hotel tier</span>
                <select className="field" value={tier} onChange={(e) => setTier(e.target.value)}>
                  <option value="budget">Budget</option><option value="mid-range">Mid-range</option><option value="luxury">Luxury</option><option value="homestay">Homestay</option>
                </select>
              </label>
              <label><span className="field-label">Food / person / day</span><input type="number" min={100} step={50} className="field" value={food} onChange={(e) => setFood(Math.max(100, Number(e.target.value) || 100))} /></label>
            </div>
          </div>

          <div className="card mt-5 p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-navy-muted">Estimated total</p>
                <p className="text-3xl font-extrabold text-navy">{inrFormat(budget.total_estimated_inr)}</p>
                <p className="text-sm text-navy-muted">{inrFormat(budget.per_person_inr)} per person</p>
              </div>
            </div>
            <BudgetChart budget={budget} />
            <ul className="mt-2 space-y-1.5">
              {budget.categories.map((c) => (
                <li key={c.category} className="flex justify-between text-sm">
                  <span className="text-navy-muted">{c.category} <span className="text-[11px]">({c.note})</span></span>
                  <span className="font-semibold text-deepsea">{inrFormat(c.estimated_inr)}</span>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-[11px] leading-relaxed text-navy-muted">{budget.disclaimer}</p>
          </div>
        </section>
      </div>
    </div>
  );
}
