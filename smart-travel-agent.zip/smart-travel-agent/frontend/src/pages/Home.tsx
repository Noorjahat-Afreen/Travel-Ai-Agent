import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Bot,
  Camera,
  CloudSun,
  Compass,
  Database,
  Landmark,
  MapPin,
  ShieldCheck,
  Sparkles,
  TrainFront,
  UtensilsCrossed,
} from "lucide-react";
import { api } from "@/services/api";
import { HERO_IMAGE } from "@/services/images";
import { useTripPrefill } from "@/context/TripPrefillContext";
import type { DashboardStats } from "@/types";

const CATEGORIES = [
  { icon: Landmark, title: "Heritage & Palaces", query: "Jaipur", note: "Forts, palaces & UNESCO sites" },
  { icon: CloudSun, title: "Hill Stations", query: "Manali", note: "Himalayan escapes" },
  { icon: Compass, title: "Beaches", query: "Goa", note: "Coastlines & islands" },
  { icon: Bot, title: "Spiritual Journeys", query: "Varanasi", note: "Temples & ghats" },
];

const FEATURES = [
  { icon: Sparkles, title: "Multi-agent AI planning", desc: "12 specialised LangChain agents coordinate transport, hotels, food, weather, budget and itineraries." },
  { icon: Database, title: "Real data only", desc: "OpenStreetMap, Wikipedia and Open-Meteo power every record - with source links and retrieval timestamps." },
  { icon: TrainFront, title: "One-click booking links", desc: "Prefilled IRCTC, redBus, Google Flights and Booking.com searches open in a new tab." },
  { icon: Camera, title: "Photo landmark recognition", desc: "OpenCV processing plus Gemini Vision identifies landmarks - or honestly admits uncertainty." },
];

export default function Home() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [origin, setOrigin] = useState("");
  const [dest, setDest] = useState("");
  const navigate = useNavigate();
  const { setPrefill } = useTripPrefill();

  useEffect(() => {
    api
      .dashboardStats()
      .then(setStats)
      .catch(() => setStats(null));
  }, []);

  const startPlanning = (to?: string, from?: string) => {
    setPrefill({ destination: to, origin: from });
    navigate("/trip-planner");
  };

  const statCards = stats
    ? [
        { value: stats.destinations, label: "Destinations indexed" },
        { value: stats.hotels, label: "Hotel records collected" },
        { value: stats.restaurants, label: "Restaurant records" },
        { value: stats.attractions, label: "Attractions collected" },
        { value: stats.plans, label: "AI trips planned" },
        { value: stats.conversations, label: "Assistant messages" },
      ]
    : [];

  return (
    <div>
      {/* ---------- HERO ---------- */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={HERO_IMAGE} alt="Taj Mahal at sunrise" className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-navy/95 via-navy/80 to-deepsea/60" />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 md:py-32">
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-3 inline-flex items-center gap-2 rounded-full bg-white/10 px-3.5 py-1.5 text-xs font-bold uppercase tracking-[0.18em] text-teal-light backdrop-blur"
          >
            <Sparkles className="h-3.5 w-3.5" /> B.Tech CSE-AIML Major Project
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className="max-w-3xl text-4xl font-extrabold leading-tight tracking-tight text-white md:text-6xl"
          >
            Plan your entire India trip with <span className="text-teal-light">AI agents</span> and real data
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.12 }}
            className="mt-4 max-w-2xl text-base leading-relaxed text-slate-200 md:text-lg"
          >
            Enter your starting city and destination - twelve specialised agents collect live hotels, restaurants,
            attractions, weather and transport links, then generate a day-wise itinerary you can save and export.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-8 max-w-3xl rounded-xl2 bg-white/95 p-4 shadow-hero backdrop-blur sm:p-5"
          >
            <div className="grid gap-3 sm:grid-cols-[1fr_1fr_auto]">
              <label className="block">
                <span className="field-label">Starting city</span>
                <input
                  className="field"
                  placeholder="e.g. Indore"
                  value={origin}
                  onChange={(e) => setOrigin(e.target.value)}
                  aria-label="Starting city"
                />
              </label>
              <label className="block">
                <span className="field-label">Destination</span>
                <input
                  className="field"
                  placeholder="e.g. Manali"
                  value={dest}
                  onChange={(e) => setDest(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && startPlanning(dest, origin)}
                  aria-label="Destination city"
                />
              </label>
              <button
                className="btn-primary sm:mt-6 sm:self-start"
                onClick={() => startPlanning(dest || "Manali", origin || "Indore")}
              >
                Explore <ArrowRight className="h-4 w-4" />
              </button>
            </div>
            <p className="mt-3 text-[11px] text-navy-muted">
              Popular: Jaipur · Manali · Goa · Udaipur · Varanasi · Leh · Mysore · Darjeeling
            </p>
          </motion.div>
        </div>
      </section>

      {/* ---------- STATS ---------- */}
      {statCards.length > 0 && (
        <section className="border-b border-slate-200 bg-white">
          <div className="mx-auto grid max-w-7xl grid-cols-2 gap-4 px-4 py-8 sm:grid-cols-3 sm:px-6 lg:grid-cols-6">
            {statCards.map((s) => (
              <div key={s.label} className="text-center">
                <p className="text-2xl font-extrabold text-navy">{s.value.toLocaleString("en-IN")}</p>
                <p className="mt-0.5 text-[11px] font-semibold uppercase tracking-wide text-navy-muted">{s.label}</p>
              </div>
            ))}
          </div>
          <p className="pb-4 text-center text-[11px] text-navy-muted">
            <ShieldCheck className="mr-1 inline h-3 w-3 text-teal" />
            Live counts from the application database - records actually collected by the agents
          </p>
        </section>
      )}

      {/* ---------- FEATURED DESTINATIONS ---------- */}
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="mb-7 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-extrabold text-navy md:text-3xl">Popular destinations</h2>
            <p className="mt-1 text-sm text-navy-muted">Real photos · tap a card to plan a trip there</p>
          </div>
          <Link to="/explore" className="btn-outline hidden sm:inline-flex">
            Explore all of India <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {[
            ["taj-mahal.jpg", "Taj Mahal", "Agra, Uttar Pradesh", "agra"],
            ["jaipur-hawa-mahal.jpg", "Hawa Mahal", "Jaipur, Rajasthan", "jaipur"],
            ["goa-beach.jpg", "Goa Beaches", "Goa", "goa"],
            ["kerala-backwaters.jpg", "Alleppey Backwaters", "Kerala", "alappuzha"],
            ["manali.jpg", "Manali", "Himachal Pradesh", "manali"],
            ["ladakh-leh.jpg", "Pangong Lake", "Ladakh", "leh"],
            ["varanasi.jpg", "Varanasi Ghats", "Uttar Pradesh", "varanasi"],
            ["udaipur.jpg", "Udaipur", "Rajasthan", "udaipur"],
            ["mumbai-gateway.jpg", "Gateway of India", "Mumbai", "mumbai"],
            ["amritsar-golden-temple.jpg", "Golden Temple", "Amritsar", "amritsar"],
            ["darjeeling.jpg", "Darjeeling", "West Bengal", "darjeeling"],
            ["hyderabad-charminar.jpg", "Charminar", "Hyderabad", "hyderabad"],
          ].map(([file, title, place, city], i) => (
            <motion.button
              key={file}
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: (i % 4) * 0.05 }}
              onClick={() => startPlanning(city[0].toUpperCase() + city.slice(1))}
              className="card card-hover group overflow-hidden text-left"
            >
              <div className="relative h-44 overflow-hidden">
                <img
                  src={`/images/${file}`}
                  alt={title}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy/80 via-transparent to-transparent" />
                <div className="absolute bottom-3 left-3 right-3">
                  <p className="text-sm font-bold text-white drop-shadow">{title}</p>
                  <p className="text-[11px] font-medium text-slate-200">{place}</p>
                </div>
              </div>
            </motion.button>
          ))}
        </div>
        <div className="mt-6 text-center sm:hidden">
          <Link to="/explore" className="btn-outline">
            Explore all of India <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* ---------- TRAVEL CATEGORIES ---------- */}
      <section className="bg-white py-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <h2 className="text-2xl font-extrabold text-navy md:text-3xl">Travel categories</h2>
          <p className="mt-1 text-sm text-navy-muted">One tap starts a themed AI plan</p>
          <div className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {CATEGORIES.map((c) => (
              <button
                key={c.title}
                onClick={() => startPlanning(c.query)}
                className="card card-hover group p-5 text-left"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-sand text-deepsea transition-colors group-hover:bg-teal group-hover:text-white">
                  <c.icon className="h-5 w-5" />
                </span>
                <h3 className="mt-3 font-bold text-navy">{c.title}</h3>
                <p className="text-xs text-navy-muted">{c.note}</p>
                <p className="mt-2 text-xs font-semibold text-teal">Try {c.query} →</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- FEATURE GRID ---------- */}
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <h2 className="text-2xl font-extrabold text-navy md:text-3xl">What makes it a real AI system</h2>
        <div className="mt-7 grid gap-4 md:grid-cols-2">
          {FEATURES.map((f) => (
            <div key={f.title} className="card p-5">
              <div className="flex items-start gap-4">
                <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl bg-navy text-teal-light">
                  <f.icon className="h-5 w-5" />
                </span>
                <div>
                  <h3 className="font-bold text-navy">{f.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-navy-muted">{f.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ---------- RECENT TRIPS ---------- */}
      {stats && stats.recent_trips.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 pb-14 sm:px-6">
          <div className="mb-6 flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-extrabold text-navy md:text-3xl">Recently planned trips</h2>
              <p className="mt-1 text-sm text-navy-muted">Saved in the database - reopen or export them any time</p>
            </div>
            <Link to="/saved-trips" className="btn-outline hidden sm:inline-flex">
              View all <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {stats.recent_trips.slice(0, 3).map((t) => (
              <Link key={t.id} to="/saved-trips" className="card card-hover p-5">
                <p className="text-xs font-semibold uppercase tracking-wide text-teal">
                  {t.origin_city} → {t.destination_city}
                </p>
                <p className="mt-1.5 font-bold text-navy">{t.title}</p>
                <p className="mt-1 text-xs text-navy-muted">
                  {new Date(t.start_date).toLocaleDateString("en-IN", { day: "numeric", month: "short" })} ·{" "}
                  {t.travellers} travellers · {t.transport_mode}
                </p>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* ---------- CTA ---------- */}
      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6">
        <div className="rounded-xl2 bg-gradient-to-br from-navy via-navy-soft to-deepsea p-8 text-center text-white md:p-12">
          <UtensilsCrossed className="mx-auto h-8 w-8 text-teal-light" />
          <h2 className="mt-4 text-2xl font-extrabold md:text-3xl">Ready to build your perfect India itinerary?</h2>
          <p className="mx-auto mt-2 max-w-xl text-sm text-slate-300">
            The planner coordinates every agent in parallel - most trips are ready in under a minute.
          </p>
          <button className="btn-primary mt-6 !px-8 !py-3 text-base" onClick={() => startPlanning("Manali", "Indore")}>
            <MapPin className="h-5 w-5" /> Start AI Trip Planning
          </button>
        </div>
      </section>
    </div>
  );
}
