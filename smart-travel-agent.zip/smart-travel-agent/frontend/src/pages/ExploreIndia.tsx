import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Landmark, MapPin, Search, Sparkles } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import SectionTitle from "@/components/SectionTitle";
import DestinationImage from "@/components/DestinationImage";
import { CardGridSkeleton, ErrorBanner, EmptyState, InfoNote } from "@/components/Loader";
import { api } from "@/services/api";
import { useTripPrefill } from "@/context/TripPrefillContext";
import type { ExploreDestination, ExploreSearchResult } from "@/types";

const CATEGORIES = [
  { id: "all", label: "All" },
  { id: "popular", label: "Popular" },
  { id: "historical", label: "Historical" },
  { id: "hill-station", label: "Hill Stations" },
  { id: "beach", label: "Beaches" },
  { id: "religious", label: "Religious & Cultural" },
  { id: "nature", label: "Nature & Adventure" },
];

export default function ExploreIndia() {
  const [category, setCategory] = useState("all");
  const [destinations, setDestinations] = useState<ExploreDestination[] | null>(null);
  const [query, setQuery] = useState("");
  const [searchResult, setSearchResult] = useState<ExploreSearchResult | null>(null);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { setPrefill } = useTripPrefill();
  const navigate = useNavigate();

  useEffect(() => {
    setDestinations(null);
    api
      .exploreDestinations(category === "all" ? undefined : category)
      .then(setDestinations)
      .catch((e) => setError(e.message));
  }, [category]);

  const search = async () => {
    const q = query.trim();
    if (q.length < 2) return;
    setSearching(true);
    setError(null);
    try {
      setSearchResult(await api.exploreSearch(q));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Search failed");
    } finally {
      setSearching(false);
    }
  };

  const planHere = (dest: { city: string }) => {
    setPrefill({ destination: dest.city });
    navigate("/trip-planner");
  };

  return (
    <div>
      <PageHeader
        eyebrow="State-wise discovery"
        title="Explore India"
        subtitle="Over 100 curated destinations with verified descriptions and live search for anywhere in the country. Select one to send it straight into the AI Trip Planner."
        icon={<Landmark className="h-6 w-6 text-teal-light" />}
      />

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        {/* Search */}
        <section className="card p-5">
          <div className="flex flex-col gap-3 sm:flex-row">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3.5 top-3.5 h-4 w-4 text-slate-400" />
              <input
                className="field pl-10"
                placeholder="Search any city, town or tourist place in India…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && search()}
                aria-label="Search destinations"
              />
            </div>
            <button className="btn-primary" onClick={search} disabled={searching}>
              {searching ? "Searching…" : "Search India"}
            </button>
          </div>
          {error && <div className="mt-4"><ErrorBanner message={error} /></div>}

          {searchResult && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mt-5">
              {searchResult.matched_destination || searchResult.lat ? (
                <div className="rounded-xl2 border border-teal/30 bg-teal/5 p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-wide text-teal">Result</p>
                      <h3 className="mt-0.5 text-lg font-extrabold text-navy">
                        {searchResult.matched_destination?.name ?? searchResult.geocoded_name}
                        {searchResult.state ? `, ${searchResult.state}` : ""}
                      </h3>
                      <p className="mt-1 max-w-2xl text-sm leading-relaxed text-navy-muted">
                        {searchResult.description ?? "details unavailable in collected data"}
                      </p>
                      {searchResult.source && <p className="mt-1 text-[11px] text-navy-muted">Source: {searchResult.source}</p>}
                    </div>
                    <div className="flex gap-2">
                      <button
                        className="btn-primary !py-2 text-xs"
                        onClick={() =>
                          planHere({
                            city: searchResult.matched_destination?.city ?? searchResult.geocoded_name,
                          })
                        }
                      >
                        Plan a trip here <ArrowRight className="h-3.5 w-3.5" />
                      </button>
                      {searchResult.wiki_url && (
                        <a href={searchResult.wiki_url} target="_blank" rel="noopener noreferrer" className="btn-outline !py-2 text-xs">
                          Wikipedia ↗
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <EmptyState
                  title={`No match found for "${searchResult.query}"`}
                  hint={searchResult.source || "Try a nearby larger city, or browse the curated list below."}
                />
              )}
            </motion.div>
          )}
        </section>

        {/* Category filter */}
        <div className="mt-8 flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setCategory(c.id)}
              className={`chip border px-4 py-2 transition-colors ${
                category === c.id ? "border-teal bg-teal text-white" : "border-slate-200 bg-white text-navy-muted hover:border-teal"
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="mt-6">
          <SectionTitle
            title={category === "all" ? "All curated destinations" : CATEGORIES.find((c) => c.id === category)?.label ?? ""}
            subtitle={destinations ? `${destinations.length} destinations · facts verified via Wikipedia links` : undefined}
          />
          {!destinations && !error ? (
            <CardGridSkeleton count={9} />
          ) : destinations && destinations.length ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {destinations.map((d, i) => (
                <motion.article
                  key={d.key}
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: (i % 6) * 0.04 }}
                  className="card card-hover flex flex-col overflow-hidden"
                >
                  <DestinationImage imageKey={d.image_key} category={d.category} alt={d.name} className="h-40 w-full" />
                  <div className="flex flex-1 flex-col p-5">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="font-bold text-navy">{d.name}</h3>
                        <p className="text-xs font-medium text-navy-muted">
                          <MapPin className="mr-0.5 inline h-3 w-3 text-teal" />
                          {d.city}, {d.state}
                        </p>
                      </div>
                      <span className="chip bg-sand capitalize text-navy-muted">{d.category.replace("-", " ")}</span>
                    </div>
                    <p className="mt-2 flex-1 text-[13px] leading-relaxed text-navy-muted">{d.blurb}</p>
                    {d.tags.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {d.tags.slice(0, 3).map((t) => (
                          <span key={t} className="chip bg-teal/10 text-teal-dark">
                            {t}
                          </span>
                        ))}
                      </div>
                    )}
                    <div className="mt-4 flex items-center gap-2">
                      <button className="btn-primary flex-1 !py-2 text-xs" onClick={() => planHere(d)}>
                        Add to trip plan
                      </button>
                      <a href={d.wiki_url} target="_blank" rel="noopener noreferrer" className="btn-outline !px-3 !py-2 text-xs">
                        Source ↗
                      </a>
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
          ) : (
            <EmptyState title="No destinations in this category" />
          )}
        </div>

        <div className="mt-8">
          <InfoNote>
            <Sparkles className="mr-1 inline h-3.5 w-3.5 text-teal" />
            Destination coordinates come from OpenStreetMap reference data; descriptions are verified against
            Wikipedia. For any place not in the curated list, live search geocodes it via the Nominatim API.
          </InfoNote>
        </div>
      </div>
    </div>
  );
}
