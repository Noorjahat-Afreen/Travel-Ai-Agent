import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Calendar, Download, FileSpreadsheet, MapPin, Trash2, Users } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import { CardGridSkeleton, EmptyState, ErrorBanner } from "@/components/Loader";
import { api, getSessionId } from "@/services/api";
import type { TripPlanResponse, TripPlanSummary } from "@/types";

export default function SavedTrips() {
  const [trips, setTrips] = useState<TripPlanSummary[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [openTrip, setOpenTrip] = useState<TripPlanResponse | null>(null);
  const [loadingTrip, setLoadingTrip] = useState(false);

  const load = useCallback(() => {
    api
      .listTrips(getSessionId())
      .then((rows) => setTrips(rows.length ? rows : null))
      .catch((e) => setError(e.message));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const open = async (id: number) => {
    setLoadingTrip(true);
    try {
      setOpenTrip(await api.getTrip(id));
      window.scrollTo({ top: 0 });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load trip");
    } finally {
      setLoadingTrip(false);
    }
  };

  const remove = async (id: number) => {
    try {
      await api.deleteTrip(id);
      setOpenTrip(null);
      load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Delete failed");
    }
  };

  const rename = async (id: number, title: string) => {
    try {
      await api.updateTrip(id, { title });
      load();
      if (openTrip?.trip_id === id) setOpenTrip({ ...openTrip, title });
    } catch {
      /* ignore */
    }
  };

  return (
    <div>
      <PageHeader
        eyebrow="Persisted in SQLite via SQLAlchemy"
        title="Saved Trips"
        subtitle="Every generated plan is stored with its full snapshot - reopen it, rename it, or export it to CSV and Excel. Trips are listed per browser session."
        icon={<Calendar className="h-6 w-6 text-teal-light" />}
      />

      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        {error && <div className="mb-6"><ErrorBanner message={error} onRetry={load} /></div>}
        {!trips && !error && <CardGridSkeleton count={3} />}

        {trips && trips.length === 0 && (
          <EmptyState
            title="No saved trips yet for this session"
            hint="Generate a plan in the AI Trip Planner - it is saved automatically. (Trips created in other browser sessions stay in the database; generate one here to see it listed.)"
          />
        )}

        {trips && trips.length > 0 && (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {trips.map((t) => (
              <article key={t.id} className="card card-hover p-5">
                <p className="text-xs font-bold uppercase tracking-wide text-teal">
                  <MapPin className="mr-1 inline h-3 w-3" />
                  {t.origin_city} → {t.destination_city}
                </p>
                <h3 className="mt-1.5 font-bold text-navy">{t.title}</h3>
                <div className="mt-2 space-y-1 text-xs text-navy-muted">
                  <p>
                    <Calendar className="mr-1 inline h-3 w-3" />
                    {new Date(t.start_date).toLocaleDateString("en-IN", { day: "numeric", month: "short" })} –{" "}
                    {new Date(t.end_date).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                  </p>
                  <p>
                    <Users className="mr-1 inline h-3 w-3" /> {t.travellers} travellers · ₹{t.budget_inr.toLocaleString("en-IN")} · {t.transport_mode}
                  </p>
                  <p className="text-[10.5px] uppercase tracking-wide">
                    {t.status} · {t.ai_mode} mode · saved {new Date(t.created_at).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}
                  </p>
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <button className="btn-primary !py-2 text-xs" onClick={() => open(t.id)}>
                    Open trip
                  </button>
                  {t.id && (
                    <>
                      <a className="btn-outline !py-2 text-xs" href={api.exportXlsxUrl(t.id)} title="Export Excel">
                        <FileSpreadsheet className="h-3.5 w-3.5" /> XLSX
                      </a>
                      <a className="btn-outline !py-2 text-xs" href={api.exportCsvUrl(t.id)} title="Export CSV">
                        <Download className="h-3.5 w-3.5" /> CSV
                      </a>
                    </>
                  )}
                  <button
                    className="btn-ghost !px-2 text-rose-600 hover:!bg-rose-50"
                    onClick={() => remove(t.id)}
                    aria-label={`Delete trip ${t.title}`}
                    title="Delete trip"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}

        {loadingTrip && <p className="mt-6 text-sm text-navy-muted">Loading trip snapshot…</p>}

        {openTrip && (
          <section className="mt-10">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <input
                className="field max-w-lg text-base font-bold"
                defaultValue={openTrip.title}
                onBlur={(e) => openTrip.trip_id && rename(openTrip.trip_id, e.target.value)}
                aria-label="Trip title"
              />
              <div className="flex gap-2">
                {openTrip.trip_id && (
                  <>
                    <a className="btn-outline !py-2 text-xs" href={api.exportXlsxUrl(openTrip.trip_id)}>
                      Export Excel
                    </a>
                    <a className="btn-outline !py-2 text-xs" href={api.exportCsvUrl(openTrip.trip_id)}>
                      Export CSV
                    </a>
                  </>
                )}
                <button className="btn-ghost" onClick={() => setOpenTrip(null)}>
                  Close
                </button>
              </div>
            </div>

            <div className="grid gap-4 lg:grid-cols-2">
              <div className="card p-5">
                <h3 className="font-bold text-navy">Overview</h3>
                <ul className="mt-3 space-y-1.5 text-sm text-navy-muted">
                  <li><b className="text-navy">Route:</b> {openTrip.overview.origin_city} → {openTrip.overview.destination_city}</li>
                  <li><b className="text-navy">Duration:</b> {openTrip.overview.days} days / {openTrip.overview.nights} nights</li>
                  <li><b className="text-navy">Travellers:</b> {openTrip.overview.travellers}</li>
                  <li><b className="text-navy">Budget:</b> ₹{openTrip.overview.budget_inr.toLocaleString("en-IN")} (₹{Math.round(openTrip.overview.budget_per_person_inr).toLocaleString("en-IN")} per person)</li>
                  <li><b className="text-navy">Estimated total:</b> ₹{Math.round(openTrip.budget.total_estimated_inr).toLocaleString("en-IN")}</li>
                  <li><b className="text-navy">Generated:</b> {new Date(openTrip.generated_at).toLocaleString("en-IN")}</li>
                </ul>
              </div>
              <div className="card p-5">
                <h3 className="font-bold text-navy">What was collected</h3>
                <div className="mt-3 grid grid-cols-3 gap-3 text-center">
                  {[
                    [openTrip.hotels.length, "hotels"],
                    [openTrip.restaurants.length, "restaurants"],
                    [openTrip.attractions.length, "attractions"],
                  ].map(([n, label]) => (
                    <div key={label as string} className="rounded-xl bg-sand p-3">
                      <p className="text-xl font-extrabold text-navy">{n as number}</p>
                      <p className="text-[11px] font-semibold uppercase text-navy-muted">{label as string}</p>
                    </div>
                  ))}
                </div>
                <p className="mt-3 text-sm text-navy-muted">{openTrip.verification.summary}</p>
                <Link to="/trip-planner" className="btn-primary mt-4 !py-2 text-xs">
                  Plan another trip
                </Link>
              </div>
            </div>

            <h3 className="mb-3 mt-8 font-bold text-navy">Itinerary snapshot</h3>
            <div className="space-y-3">
              {openTrip.itinerary.map((d) => (
                <div key={d.day_number} className="card p-4">
                  <p className="text-sm font-bold text-navy">
                    Day {d.day_number}: {d.title}
                  </p>
                  <ul className="mt-2 space-y-1">
                    {d.activities.map((a, i) => (
                      <li key={i} className="text-[13px] text-navy-muted">
                        <span className="font-semibold text-navy">{a.period}:</span> {a.title}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
