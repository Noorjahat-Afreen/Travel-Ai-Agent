import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { Camera, ExternalLink, MapPin, ScanSearch, Upload, X } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import PlaceCard from "@/components/PlaceCard";
import { CardGridSkeleton, EmptyState, ErrorBanner, InfoNote } from "@/components/Loader";
import AiModeBanner from "@/components/AiModeBanner";
import { SourceBadge } from "@/components/SourceBadge";
import { api } from "@/services/api";
import type { VisionAnalysis } from "@/types";

const MISSING = "details unavailable in collected data";

export default function VisionPage() {
  const [preview, setPreview] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<VisionAnalysis | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const accept = (f: File | undefined | null) => {
    if (!f) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(f.type)) {
      setError("Only JPEG, PNG or WEBP images are supported.");
      return;
    }
    if (f.size > 8 * 1024 * 1024) {
      setError("Image too large (max 8 MB).");
      return;
    }
    setError(null);
    setResult(null);
    setFile(f);
    setPreview(URL.createObjectURL(f));
  };

  const analyze = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);
    try {
      setResult(await api.analyzeImage(file));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Analysis failed");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setFile(null);
    setPreview(null);
    setResult(null);
    setError(null);
  };

  return (
    <div>
      <PageHeader
        eyebrow="OpenCV + Gemini Vision"
        title="Photo Landmark Recognition"
        subtitle="Upload a travel photograph: OpenCV extracts edges, colours and sharpness, then the AI model attempts landmark identification - or honestly reports uncertainty. Nearby stays and food are collected from live OSM data."
        icon={<Camera className="h-6 w-6 text-teal-light" />}
      />

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        {/* Upload */}
        <section
          className={`card flex flex-col items-center justify-center gap-4 border-2 border-dashed p-10 transition-colors ${
            dragging ? "border-teal bg-teal/5" : "border-slate-300 bg-white"
          }`}
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            accept(e.dataTransfer.files?.[0]);
          }}
        >
          {preview ? (
            <div className="relative">
              <img src={preview} alt="Uploaded destination photo" className="max-h-72 rounded-xl2 shadow-card" />
              <button onClick={reset} className="absolute -right-2 -top-2 rounded-full bg-navy p-1.5 text-white shadow-card" aria-label="Remove image">
                <X className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <>
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-sand text-deepsea">
                <Upload className="h-6 w-6" />
              </span>
              <p className="text-sm font-semibold text-navy">Drag &amp; drop a destination photo, or</p>
            </>
          )}
          <input
            ref={inputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={(e) => accept(e.target.files?.[0])}
          />
          <div className="flex gap-2">
            <button className="btn-outline" onClick={() => inputRef.current?.click()}>
              Choose file
            </button>
            {file && (
              <button className="btn-primary" onClick={analyze} disabled={loading}>
                <ScanSearch className="h-4 w-4" /> {loading ? "Analysing…" : "Identify landmark"}
              </button>
            )}
          </div>
          <p className="text-[11px] text-navy-muted">JPEG / PNG / WEBP · max 8 MB · processed entirely in the backend</p>
        </section>

        {error && <div className="mt-6"><ErrorBanner message={error} /></div>}
        {loading && <div className="mt-6"><CardGridSkeleton count={3} /></div>}

        {result && !loading && (
          <div className="mt-8 space-y-8">
            <AiModeBanner
              mode={result.ai_mode}
              note={
                result.ai_mode === "gemini"
                  ? "Landmark identified with Google Gemini Vision."
                  : undefined
              }
            />

            {/* Landmark result */}
            <section className="card overflow-hidden">
              <div className="bg-gradient-to-r from-navy to-deepsea p-6 text-white">
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-teal-light">Recognition result</p>
                {result.landmark.identified ? (
                  <>
                    <h2 className="mt-1 text-2xl font-extrabold">{result.landmark.landmark}</h2>
                    <p className="mt-1 text-sm text-slate-300">
                      {[result.landmark.city, result.landmark.state, result.landmark.country].filter(Boolean).join(", ") || MISSING}
                      {result.landmark.confidence != null && (
                        <span className="ml-2 rounded-full bg-teal px-2.5 py-0.5 text-xs font-bold">
                          confidence {(result.landmark.confidence * 100).toFixed(0)}%
                        </span>
                      )}
                    </p>
                    {result.landmark.rationale && <p className="mt-2 max-w-3xl text-[13px] text-slate-300">{result.landmark.rationale}</p>}
                  </>
                ) : (
                  <>
                    <h2 className="mt-1 text-2xl font-extrabold">Landmark not confidently identified</h2>
                    <p className="mt-2 max-w-3xl text-sm text-slate-300">{result.landmark.note || MISSING}</p>
                  </>
                )}
              </div>
              <div className="grid gap-4 p-6 md:grid-cols-2">
                <div>
                  <h3 className="font-bold text-navy">About this place</h3>
                  <p className="mt-2 text-sm leading-relaxed text-navy-muted">{result.description ?? MISSING}</p>
                  {result.wiki_url && (
                    <a href={result.wiki_url} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-teal underline decoration-dotted">
                      Read on Wikipedia <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                  {result.source && <div className="mt-2"><SourceBadge source={result.source} /></div>}
                  {result.map_link && (
                    <a href={result.map_link} target="_blank" rel="noopener noreferrer" className="btn-primary mt-4 !py-2 text-xs">
                      <MapPin className="h-3.5 w-3.5" /> Explore on Map
                    </a>
                  )}
                </div>
                <div className="rounded-xl2 bg-mist p-4">
                  <h3 className="text-sm font-bold text-navy">Image feature analysis (OpenCV)</h3>
                  <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-[13px]">
                    {[
                      ["Resolution", `${result.features.width} × ${result.features.height}`],
                      ["Edge density", `${(result.features.edge_density * 100).toFixed(1)}%`],
                      ["Brightness", `${result.features.brightness} / 255`],
                      ["Contrast (σ)", `${result.features.contrast}`],
                      ["Sharpness (Laplacian var)", `${result.features.sharpness}`],
                      ["Dominant colours", result.features.dominant_colors.join(" ")],
                    ].map(([k, v]) => (
                      <div key={k}>
                        <dt className="text-[11px] font-semibold uppercase tracking-wide text-navy-muted">{k}</dt>
                        <dd className="font-semibold text-navy">{v}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
              </div>
            </section>

            {/* Processed images side by side */}
            <section>
              <h2 className="mb-4 text-xl font-bold text-navy">Original vs processed (side by side)</h2>
              <div className="grid gap-4 md:grid-cols-3">
                {[
                  ["Original (resized)", result.processed.original],
                  ["Grayscale", result.processed.grayscale],
                  ["Canny edge map", result.processed.edges],
                ].map(([label, src]) => (
                  <motion.figure key={label} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="card overflow-hidden">
                    <img src={src} alt={label} className="h-56 w-full bg-slate-100 object-contain" />
                    <figcaption className="px-4 py-2.5 text-xs font-semibold text-navy-muted">{label}</figcaption>
                  </motion.figure>
                ))}
              </div>
              <div className="mt-4">
                <InfoNote>
                  Pipeline: decode → resize (max 1024 px) → grayscale → 5×5 Gaussian blur → Canny edges (80/200) →
                  K-means dominant colours. Feature stats feed the AI prompt context.
                </InfoNote>
              </div>
            </section>

            {/* Nearby */}
            <section className="grid gap-4 lg:grid-cols-3">
              {(
                [
                  { title: "Nearby hotels", records: result.nearby_hotels, kind: "hotel" as const },
                  { title: "Nearby restaurants", records: result.nearby_restaurants, kind: "restaurant" as const },
                  { title: "Nearby attractions", records: result.nearby_attractions, kind: "attraction" as const },
                ]
              ).map(({ title, records, kind }) => (
                <div key={title}>
                  <h3 className="mb-3 font-bold text-navy">
                    {title} <span className="text-sm font-medium text-navy-muted">({records.length})</span>
                  </h3>
                  {records.length ? (
                    <div className="space-y-3">
                      {records.slice(0, 4).map((r, i) => (
                        <PlaceCard key={i} record={r} kind={kind} />
                      ))}
                    </div>
                  ) : (
                    <EmptyState title="No nearby records collected" hint="POI providers may be unavailable - try again later." />
                  )}
                </div>
              ))}
            </section>
          </div>
        )}
      </div>
    </div>
  );
}
