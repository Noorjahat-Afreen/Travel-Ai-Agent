import { useState } from "react";
import { Bus, Car, ExternalLink, MapPin, Plane, Route, TrainFront } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import { ErrorBanner, InfoNote } from "@/components/Loader";
import { api } from "@/services/api";
import { inrFormat } from "@/components/BudgetChart";

interface TransportResult {
  road_estimate?: { distance_km: number; duration_hours: number; source: string } | null;
  options: {
    mode: string;
    provider: string;
    summary: string;
    detail?: string | null;
    deep_link: string;
    is_estimate: boolean;
    estimated_cost_inr?: number | null;
    notes?: string | null;
    booking_links: { label: string; url: string; provider: string; kind: string }[];
  }[];
}

const MODE_ICON = { train: TrainFront, bus: Bus, flight: Plane, car: Car } as const;

export default function Transport() {
  const [origin, setOrigin] = useState("Indore");
  const [destination, setDestination] = useState("Manali");
  const [date, setDate] = useState(() => new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10));
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<TransportResult | null>(null);

  const search = async () => {
    setLoading(true);
    setError(null);
    try {
      setResult(await api.transportSearch<TransportResult>(origin, destination, date));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Search failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <PageHeader
        eyebrow="Trains · Buses · Flights · Car"
        title="Transport Search"
        subtitle="Prefilled deep links to IRCTC, redBus, Google Flights, MakeMyTrip and Google Maps. Fares and availability are shown by the providers - this app never invents them."
        icon={<TrainFront className="h-6 w-6 text-teal-light" />}
      />
      <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
        <section className="card p-6">
          <div className="grid gap-4 sm:grid-cols-[1fr_1fr_1fr_auto] sm:items-end">
            <label className="block">
              <span className="field-label">From</span>
              <input className="field" value={origin} onChange={(e) => setOrigin(e.target.value)} />
            </label>
            <label className="block">
              <span className="field-label">To</span>
              <input className="field" value={destination} onChange={(e) => setDestination(e.target.value)} />
            </label>
            <label className="block">
              <span className="field-label">Journey date</span>
              <input type="date" min={new Date().toISOString().slice(0, 10)} className="field" value={date} onChange={(e) => setDate(e.target.value)} />
            </label>
            <button className="btn-primary h-[42px]" onClick={search} disabled={loading}>
              {loading ? "Searching…" : "Compare modes"}
            </button>
          </div>
        </section>

        {error && <div className="mt-6"><ErrorBanner message={error} /></div>}

        {result && (
          <div className="mt-8 space-y-5">
            {result.road_estimate && (
              <div className="card flex items-center gap-4 p-5">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-sand text-deepsea">
                  <Route className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-bold text-navy">
                    Road distance ≈ {result.road_estimate.distance_km} km · ≈ {result.road_estimate.duration_hours} h driving
                  </p>
                  <p className="text-xs text-navy-muted">Source: {result.road_estimate.source} (estimate; live traffic varies)</p>
                </div>
                <a
                  className="btn-outline ml-auto !py-2 text-xs"
                  href={`https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(origin + ",India")}&destination=${encodeURIComponent(destination + ",India")}&travelmode=driving`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <MapPin className="h-3.5 w-3.5" /> Route map
                </a>
              </div>
            )}

            <div className="grid gap-4 md:grid-cols-2">
              {result.options.map((o) => {
                const Icon = MODE_ICON[o.mode as keyof typeof MODE_ICON] ?? Route;
                return (
                  <div key={o.mode + o.provider} className="card p-5">
                    <div className="flex items-center gap-3">
                      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-navy text-teal-light">
                        <Icon className="h-5 w-5" />
                      </span>
                      <div>
                        <h3 className="font-bold capitalize text-navy">{o.mode}</h3>
                        <p className="text-xs font-semibold text-deepsea">{o.provider}</p>
                      </div>
                    </div>
                    <p className="mt-3 text-sm text-navy-muted">{o.summary}</p>
                    {o.detail && <p className="mt-1.5 text-[13px] leading-relaxed text-navy-muted">{o.detail}</p>}
                    {o.is_estimate && o.estimated_cost_inr != null && (
                      <p className="mt-2 text-xs font-bold text-amber-700">≈ {inrFormat(o.estimated_cost_inr)} self-drive estimate (fuel + tolls) - not a quote</p>
                    )}
                    {o.notes && <p className="mt-2 text-[11px] text-navy-muted">{o.notes}</p>}
                    <div className="mt-4 flex flex-wrap gap-2">
                      {o.booking_links.map((l) => (
                        <a
                          key={l.url + l.label}
                          href={l.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={l.label.startsWith("Search") || l.label.startsWith("Book") ? "btn-primary !py-2 text-xs" : "chip bg-sand text-navy-muted hover:brightness-95"}
                        >
                          {l.label} <ExternalLink className="h-3 w-3" />
                        </a>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>

            <InfoNote>
              Deep links follow each provider's public URL format and prefill your cities and date where supported.
              If a provider changes its URL structure, the landing page still lets you search manually.
            </InfoNote>
          </div>
        )}
      </div>
    </div>
  );
}
