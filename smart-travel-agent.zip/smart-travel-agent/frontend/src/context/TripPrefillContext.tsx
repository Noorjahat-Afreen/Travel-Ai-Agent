/** Trip prefill state: Explore India can push a destination into the planner. */
import { createContext, useContext, useState } from "react";
import type { ReactNode } from "react";

interface PrefillState {
  destination?: string;
  origin?: string;
  setPrefill: (payload: { destination?: string; origin?: string }) => void;
  consumePrefill: () => { destination?: string; origin?: string } | null;
}

const TripPrefillContext = createContext<PrefillState>({
  setPrefill: () => undefined,
  consumePrefill: () => null,
});

export function TripPrefillProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<{ destination?: string; origin?: string } | null>(null);

  const setPrefill = (payload: { destination?: string; origin?: string }) => setState(payload);
  const consumePrefill = () => {
    const current = state;
    setState(null);
    return current;
  };

  return (
    <TripPrefillContext.Provider value={{ setPrefill, consumePrefill }}>
      {children}
    </TripPrefillContext.Provider>
  );
}

export function useTripPrefill() {
  return useContext(TripPrefillContext);
}
