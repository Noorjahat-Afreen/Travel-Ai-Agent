/** Shared API types mirroring backend Pydantic schemas. */

export interface SourceInfo {
  name: string;
  url: string;
  retrieved_at?: string | null;
}

export interface BookingLink {
  label: string;
  url: string;
  provider: string;
  kind: "hotel" | "train" | "bus" | "flight" | "car" | "map" | "website" | "info";
}

export interface AgentStatus {
  agent: string;
  status: "ok" | "degraded" | "error" | "skipped";
  message: string;
  degraded: boolean;
}

export interface PlaceRecord {
  name: string;
  category: string;
  lat: number;
  lon: number;
  city: string;
  address?: string | null;
  description?: string | null;
  cuisine?: string | null;
  vegetarian?: boolean | null;
  website?: string | null;
  phone?: string | null;
  price_level?: number | null;
  stars?: number | null;
  types: string[];
  distance_km?: number | null;
  source: SourceInfo;
  map_link: string;
  directions_link: string;
  booking_links: BookingLink[];
}

export interface TransportOption {
  mode: string;
  provider: string;
  summary: string;
  detail?: string | null;
  deep_link: string;
  origin_city: string;
  destination_city: string;
  travel_date?: string | null;
  is_estimate: boolean;
  estimated_cost_inr?: number | null;
  notes?: string | null;
  source: SourceInfo;
  booking_links: BookingLink[];
}

export interface DestinationInfo {
  name: string;
  city: string;
  state: string;
  country: string;
  lat: number;
  lon: number;
  description?: string | null;
  wiki_url?: string | null;
  source: SourceInfo;
}

export interface BudgetCategory {
  category: string;
  estimated_inr: number;
  note: string;
  is_estimate: boolean;
}

export interface BudgetBreakdown {
  total_estimated_inr: number;
  per_person_inr: number;
  within_budget: boolean;
  user_budget_inr: number;
  categories: BudgetCategory[];
  assumptions: string[];
  disclaimer: string;
}

export interface WeatherDay {
  date: string;
  temp_min_c?: number | null;
  temp_max_c?: number | null;
  precipitation_probability?: number | null;
  precipitation_mm?: number | null;
  condition: string;
  source: SourceInfo;
}

export interface ItineraryActivity {
  period: string;
  title: string;
  description: string;
  place_name?: string | null;
  lat?: number | null;
  lon?: number | null;
  map_link: string;
  note: string;
}

export interface ItineraryDay {
  day_number: number;
  date: string;
  title: string;
  theme: string;
  activities: ItineraryActivity[];
  travel_note?: string | null;
  is_ai_generated: boolean;
}

export interface RecommendationItem {
  record: PlaceRecord;
  reason: string;
}

export interface RecommendationSet {
  hotels: RecommendationItem[];
  restaurants: RecommendationItem[];
  attractions: RecommendationItem[];
}

export interface VerificationIssue {
  record: string;
  kind: string;
  detail: string;
}

export interface VerificationReport {
  checked_records: number;
  issues: VerificationIssue[];
  all_sourced: boolean;
  summary: string;
}

export interface TripRequest {
  origin_city: string;
  destination_city: string;
  start_date: string;
  end_date: string;
  travellers: number;
  budget_inr: number;
  transport_mode: "train" | "bus" | "flight" | "car" | "any";
  trip_type: string;
  interests: string[];
  hotel_preference: string;
  food_preference: string;
  session_id?: string;
  save_plan: boolean;
}

export interface TripPlanResponse {
  trip_id?: number | null;
  title: string;
  ai_mode: string;
  overview: {
    origin_city: string;
    destination_city: string;
    start_date: string;
    end_date: string;
    days: number;
    nights: number;
    travellers: number;
    budget_inr: number;
    budget_per_person_inr: number;
    transport_mode: string;
    trip_type: string;
  };
  destination_info?: DestinationInfo | null;
  transport_options: TransportOption[];
  hotels: PlaceRecord[];
  restaurants: PlaceRecord[];
  attractions: PlaceRecord[];
  weather: WeatherDay[];
  weather_available: boolean;
  weather_note: string;
  budget: BudgetBreakdown;
  itinerary: ItineraryDay[];
  recommendations: RecommendationSet;
  verification: VerificationReport;
  agent_statuses: AgentStatus[];
  map_center: { lat: number; lon: number; name?: string };
  saved: boolean;
  notes: string[];
  generated_at: string;
}

export interface TripPlanSummary {
  id: number;
  title: string;
  origin_city: string;
  destination_city: string;
  start_date: string;
  end_date: string;
  travellers: number;
  budget_inr: number;
  transport_mode: string;
  status: string;
  ai_mode: string;
  created_at: string;
}

export interface ExploreDestination {
  key: string;
  name: string;
  city: string;
  state: string;
  lat: number;
  lon: number;
  tags: string[];
  blurb: string;
  wiki_url: string;
  image_key: string;
  category: string;
}

export interface ExploreSearchResult {
  query: string;
  matched_destination?: ExploreDestination | null;
  geocoded_name: string;
  state: string;
  lat?: number | null;
  lon?: number | null;
  description?: string | null;
  wiki_url: string;
  source: string;
  curated_alternatives: ExploreDestination[];
}

export interface DataCard {
  title: string;
  kind: string;
  items: Record<string, unknown>[];
}

export interface ChatResponse {
  reply: string;
  mode: string;
  sources: SourceInfo[];
  data_cards: DataCard[];
  suggestions: string[];
  tool_trace: string[];
  error?: string | null;
}

export interface DashboardStats {
  plans: number;
  destinations: number;
  hotels: number;
  restaurants: number;
  attractions: number;
  weather_records: number;
  conversations: number;
  saved_recommendations: number;
  providers: { name: string; url: string; status: string; last_used?: string | null }[];
  ai_mode: string;
  recent_trips: TripPlanSummary[];
}

export interface VisionAnalysis {
  ai_mode: string;
  landmark: {
    identified: boolean;
    landmark: string;
    confidence?: number | null;
    city: string;
    state: string;
    country: string;
    rationale: string;
    note: string;
  };
  description?: string | null;
  wiki_url?: string | null;
  source?: SourceInfo | null;
  processed: { original: string; grayscale: string; edges: string };
  features: {
    width: number;
    height: number;
    edge_density: number;
    brightness: number;
    contrast: number;
    sharpness: number;
    dominant_colors: string[];
  };
  nearby_hotels: PlaceRecord[];
  nearby_restaurants: PlaceRecord[];
  nearby_attractions: PlaceRecord[];
  map_link: string;
  notes: string[];
}
