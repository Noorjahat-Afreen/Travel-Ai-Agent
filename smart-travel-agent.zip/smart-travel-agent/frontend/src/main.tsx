import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import { TripPrefillProvider } from "./context/TripPrefillContext";
import "./index.css";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <BrowserRouter>
      <TripPrefillProvider>
        <App />
      </TripPrefillProvider>
    </BrowserRouter>
  </StrictMode>,
);
