# Architecture — AI Smart Travel Agent for India

## 1. System overview

```
┌──────────────────────────────────────────────────────────────────────────┐
│  React 18 + TypeScript SPA (Vite, Tailwind, Framer Motion, Leaflet)      │
│  12 pages · same-origin /api calls · gateway-port query param support    │
└───────────────▲──────────────────────────────────────────┬───────────────┘
                │ REST (JSON)                              │ static SPA
┌───────────────┴──────────────────────────────────────────▼───────────────┐
│  FastAPI backend (uvicorn, single port 8000)                             │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────────────────────────┐  │
│  │ Middleware    │ │ API routes   │ │ StaticFiles (built frontend)     │  │
│  │ CORS/GZip/429 │ │ 10 routers   │ │ single-service deployments       │  │
│  └──────────────┘ └──────┬───────┘ └──────────────────────────────────┘  │
│                          │                                                │
│  ┌───────────────────────▼───────────────────────────────────────────┐   │
│  │  AGENT LAYER (agents/)                                            │   │
│  │  MasterTravelAgent.plan()                                         │   │
│  │    ├─ DestinationDiscoveryAgent   ├─ HotelAgent                   │   │
│  │    ├─ TransportAgent              ├─ RestaurantAgent              │   │
│  │    ├─ AttractionAgent             ├─ WeatherAgent                 │   │
│  │    ├─ BudgetAgent                 ├─ ItineraryAgent               │   │
│  │    ├─ RecommendationAgent         ├─ VerificationAgent            │   │
│  │    └─ ChatAgent (tools)           └─ VisionAgent (OpenCV+Gemini)  │   │
│  │  LangChain tools (agents/tools.py) + LLM provider (services/llm)  │   │
│  └───────────────────────┬───────────────────────────────────────────┘   │
│  ┌───────────────────────▼───────────────────────────────────────────┐   │
│  │  SERVICE LAYER (services/)                                        │   │
│  │  nominatim · overpass(+photon) · wikipedia · open_meteo · osrm     │   │
│  │  data_collector (normalisation + persistence) · booking_links     │   │
│  │  rag (SQLite BM25) · llm (Gemini) · india_reference (curated)     │   │
│  └───────────────────────┬───────────────────────────────────────────┘   │
│  ┌───────────────────────▼───────────────────────────────────────────┐   │
│  │  CORE: TTL cache · token-bucket rate limiter · retrying httpx     │   │
│  │  client (loop-safe) · redacting logging · pydantic-settings       │   │
│  └───────────────────────────────────────────────────────────────────┘   │
│  ┌───────────────────────────────────────────────────────────────────┐   │
│  │  SQLAlchemy 2.0 → SQLite (dev) / PostgreSQL (deployment)          │   │
│  │  12 tables: users, travel_plans, destinations, hotels,            │   │
│  │  restaurants, attractions, transport_options, weather_records,    │   │
│  │  ai_conversations, data_sources, saved_recommendations,           │   │
│  │  rag_documents                                                    │   │
│  └───────────────────────────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────────────────┘
```

## 2. Agent pipeline detail

`POST /api/trips/plan` → `MasterTravelAgent.plan(request)`:

1. **Destination discovery** (sequential dependency root): Nominatim geocode +
   Wikipedia city summary + curated reference facts. Every other agent needs the
   destination coordinates, so this runs first.
2. **Parallel fan-out** (`asyncio.gather` with `return_exceptions=True`):
   transport, hotels, restaurants, attractions, weather. Failures are converted
   into per-agent *degraded/error* statuses — never a crashed request.
3. **Budget agent**: consumes distance (OSRM road route → haversine fallback),
   hotel tier (OSM `price_level` median when tagged, else preference default),
   food preference, trip length. Produces category rows + assumptions + 10%
   emergency buffer. All amounts are labelled estimates.
4. **Itinerary agent**: nearest-neighbour ordering of attractions from the city
   centre with interest-based boosts; fills Morning/Afternoon slots on middle
   days; Evening slots are generic market/food-street guidance (no fabricated
   venues or clock times; every activity carries "confirm timings" note).
   With Gemini configured, a grounded 2-3 sentence trip summary is generated
   via structured output (facts only, from the collected description).
5. **Recommendation agent**: ranks hotels (tier/stars/distance), restaurants
   (veg tags first for veg/vegan requests), attractions (interest-keyword
   matching) and attaches a human-readable reason to each.
6. **Verification agent**: audits sources, coordinate plausibility, missing
   fields, itinerary clock-time leakage and weather coverage; emits a report.
7. **Persistence** (threadpool): `travel_plans` row + normalised POIs (dedup by
   unique constraints), weather rows, transport options, and the **full plan
   snapshot** (`plan_json`) so saved trips render offline.

### Status transparency

Each agent returns `AgentStatus {agent, status, message, degraded}`. The UI
renders a 12-tile execution trace on every plan — examiners can see exactly
which provider succeeded, degraded or failed, and why.

## 3. Data collection design

- **One HTTP pathway** (`core/http_client.request_json`): descriptive User-Agent,
  bounded timeouts, exponential-backoff retries on 429/5xx, redacted logging.
- **Politeness**: Nominatim throttled to ≥1.1 s between calls (module lock);
  Overpass queries rotate 3 mirrors; every provider call is TTL-cached
  (geocoding 24 h, POIs 6 h, weather 30 min) to avoid unnecessary requests.
- **Normalisation**: `services/data_collector.py` converts Overpass/Photon
  elements into `PlaceRecord` (name, coords, address, website, phone, cuisine,
  veg tags, stars/price level when tagged, distance from centre, source info)
  and attaches booking links per category.
- **Fallbacks**: Overpass → Photon (Komoot) → honest empty result; OSRM →
  haversine; Wikipedia → curated blurb; Open-Meteo beyond horizon → explicit
  "beyond horizon" note instead of guesses.

## 4. RAG design

`services/rag.py` stores normalised documents (curated destination facts +
Wikipedia summaries ingested lazily during planning) in `rag_documents`.
Retrieval is **BM25 implemented in pure Python** (Okapi, k1=1.5, b=0.75) with
an in-memory corpus cache keyed by document count. If `sentence-transformers`
happens to be installed, embeddings are computed locally and used first — no
remote embedding APIs, no heavyweight vector DB. The chatbot's fallback router
and the LLM system prompt both consume this context, always with source URLs.

## 5. Chat agent design

- **Gemini mode**: LangChain tool-calling loop (`bind_tools` on
  ChatGoogleGenerativeAI) over 7 tools (destination search, hotels, restaurants,
  attractions, weather, budget estimate, transport links). Tool results are
  converted into structured `DataCard`s rendered next to the reply. History:
  last 10 messages from `ai_conversations` (session-scoped, clearable).
- **Local mode**: deterministic intent router (hotels / restaurants / weather /
  compare-transport / itinerary / attractions / budget explanation) calling the
  **same tools**, so answers still carry real collected records.

## 6. Computer vision design

`agents/vision_agent.py`:
1. Validation (mime whitelist, ≤8 MB, decodability).
2. Resize to ≤1024 px → grayscale → Gaussian blur (5×5) → Canny (80/200) →
   K-means (k=4) dominant colours; stats: edge density, brightness, contrast,
   Laplacian variance.
3. Landmark ID via `services/llm.identify_landmark` (Gemini multimodal message,
   JSON response, confidence threshold 0.4). Below threshold or no key →
   `identified=False` with an honest note (never a guess).
4. Identified landmarks are enriched: Wikipedia summary + Nominatim geocode +
   nearby Overpass POIs (hotels/restaurants/attractions).

## 7. Security

- Secrets only via `backend/.env` (`pydantic-settings`); `.env.example` has
  placeholders; nothing secret is logged (`core/logging_conf.redact`).
- Per-IP token-bucket rate limit (default 120 req/min) → 429 + Retry-After.
- CORS restricted to configured origins; GZip; safe external links
  (`rel="noopener noreferrer"`); Pydantic validation on all inputs; SQLAlchemy
  ORM (no raw SQL string interpolation).
- Frontend never sees `GEMINI_API_KEY`; the SPA only talks to `/api/*`.

## 8. Testing strategy

- **Backend (pytest, 95 tests)**: budget math, booking URL formats, date
  validation, agent behaviour (itinerary ordering, verification, veg ranking),
  API endpoints (full trip lifecycle incl. exports), DB operations and unique
  constraints, CSV/XLSX content, OpenCV pipeline + uncertainty paths,
  missing-key behaviour, provider-outage resilience, rate limiter and cache.
  All external providers are mocked at module boundaries — the suite never
  touches the network and is deterministic.
- **Frontend (vitest + RTL, 14 tests)**: API client URL/session behaviour,
  image fallback resolution, Home render + stats, planner form defaults,
  submit → mocked plan rendering, date bounds.
