# Deployment Guide

## A. Local Windows development (recap)

See [SETUP_WINDOWS.md](SETUP_WINDOWS.md) for the full click-by-click walkthrough.

## B. Render — FastAPI backend

1. Push `smart-travel-agent/` to GitHub.
2. Render → **New Web Service** → connect the repo.
3. Settings:
   - **Root directory**: `backend`
   - **Runtime**: Python 3
   - **Build command**: `pip install -r requirements.txt`
   - **Start command**: `uvicorn main:app --host 0.0.0.0 --port $PORT`
4. Environment variables:
   - `GEMINI_API_KEY=<your key>`
   - `DB_URL=postgresql+psycopg://<user>:<pass>@<host>/<db>` (Render PostgreSQL)
   - `CORS_ORIGINS=https://<your-vercel-app>.vercel.app`
5. **Persistence warning (important):** Render's free filesystem is **ephemeral**.
   A local SQLite file will be wiped on redeploy/restarts. Either attach Render
   PostgreSQL (recommended — SQLAlchemy models work unchanged) or accept that
   saved trips reset per instance.

### Single-service option

`backend/main.py` automatically serves `../frontend/dist` if it exists, so you
can also deploy one service: build the frontend (`npm run build` in `frontend/`)
and commit `dist/`, then Render serves both API and SPA from port `$PORT`
(SPA fallback included for client-side routes).

## C. Vercel — React frontend

1. Vercel → **New Project** → import the repo.
2. Settings:
   - **Root directory**: `frontend`
   - **Framework preset**: Vite
   - **Build command**: `npm run build`
   - **Output directory**: `dist`
3. Environment variables:
   - `VITE_API_BASE_URL` is not needed if you rewrite `/api/*` (step 4).
4. Add `frontend/vercel.json` to proxy API calls (avoids CORS entirely):

```json
{
  "rewrites": [
    { "source": "/api/:path*", "destination": "https://<your-render-app>.onrender.com/api/:path*" }
  ]
}
```

5. Deploy. Then set the backend's `CORS_ORIGINS` to the Vercel domain.

## D. Database — PostgreSQL

1. Create a Render PostgreSQL (or Neon/Supabase) instance.
2. Copy the internal connection string into `DB_URL`:
   `postgresql+psycopg://user:password@host/dbname`
3. Tables are created automatically on startup (`init_db()` runs
   `Base.metadata.create_all` + seeds curated destinations and RAG documents).
4. No code changes required — all models are portable SQLAlchemy 2.0.

## E. Production checklist

- [ ] `GEMINI_API_KEY` set on the server only (never in frontend env)
- [ ] `CORS_ORIGINS` limited to your real domains
- [ ] `RATE_LIMIT_RPM` tuned to expected traffic
- [ ] Persistent `DB_URL` (PostgreSQL) — not SQLite on ephemeral disks
- [ ] Custom Open-Meteo/OSRM limits respected under load (caching is enabled)
- [ ] Set `LOG_LEVEL=WARNING` for production noise control
