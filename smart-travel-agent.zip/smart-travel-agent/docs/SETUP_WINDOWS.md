# Windows Setup — Step by Step

## 1. Install the tools

1. **Python 3.12** — <https://www.python.org/downloads/> → during install tick
   *"Add python.exe to PATH"*.
2. **Node.js LTS (20+)** — <https://nodejs.org/> (includes npm).
3. **Git** (optional but recommended) — <https://git-scm.com/>.

Verify in PowerShell:

```powershell
python --version    # 3.10 or newer
node --version      # 18 or newer
npm --version
```

## 2. Get the project

Copy the `smart-travel-agent` folder anywhere, e.g. `C:\projects\smart-travel-agent`,
then:

```powershell
cd C:\projects\smart-travel-agent
```

## 3. Backend setup (FastAPI)

```powershell
cd backend
python -m venv venv
.\venv\Scripts\activate          # activates the virtual environment
pip install -r requirements.txt  # FastAPI, SQLAlchemy, LangChain, OpenCV, pandas...
copy .env.example .env           # now edit .env (step 4)
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

Keep this window open. Check <http://localhost:8000/api/health> — it should
return `{"status": "ok", ...}`. The SQLite database is created automatically at
`..\data\travel_agent.db` on first start.

## 4. Configure the environment (backend\.env)

Open `backend\.env` in Notepad:

```
GEMINI_API_KEY=AIza...your-key-here      # optional, from https://aistudio.google.com/apikey
GEMINI_MODEL=gemini-2.0-flash
DB_URL=sqlite:///../data/travel_agent.db
CORS_ORIGINS=http://localhost:5173,http://127.0.0.1:5173
RATE_LIMIT_RPM=120
LOG_LEVEL=INFO
```

- **With a Gemini key**: chatbot reasoning, trip narrative and landmark naming are AI-powered.
- **Without a key**: the app runs in *local intelligence mode* — every data feature
  still works (real OpenStreetMap/Open-Meteo/Wikipedia data); AI narrative features
  are disabled and clearly labelled. Nothing else changes.

**Never commit your .env or share the key.**

## 5. Frontend setup (React + Vite)

Open a **second** PowerShell window:

```powershell
cd C:\projects\smart-travel-agent\frontend
npm install          # first time only (~1-2 minutes)
npm run dev          # starts Vite on http://localhost:5173
```

The dev server proxies `/api/*` to `http://localhost:8000` automatically
(see `vite.config.ts`). Open <http://localhost:5173> in your browser.

## 6. Run the automated tests

```powershell
# backend (from backend\ with venv active)
python -m pytest            # 95 tests, no internet needed

# frontend (from frontend\)
npm test                    # 14 tests
```

## 7. Production-style local run (single port)

After building the frontend once, FastAPI can serve everything:

```powershell
cd frontend
npm run build               # outputs frontend\dist
cd ..\backend
python -m uvicorn main:app --port 8000
# open http://localhost:8000  (SPA + API on one port)
```

## 8. Troubleshooting

| Problem | Fix |
| --- | --- |
| `python` not recognised | Reinstall Python with "Add to PATH" ticked |
| `npm install` fails on OpenCV/leafletter warnings | Delete `node_modules`, run `npm install` again |
| Hotels/restaurants return "details unavailable in collected data" | Public POI providers may be rate-limiting your IP — wait a few minutes; booking links keep working |
| Weather says "beyond horizon" | Open-Meteo free API covers ~16 days ahead — normal behaviour |
| Port 8000 already in use | `netstat -ano | findstr :8000` then `taskkill /PID <pid> /F` |
| Chatbot replies in "local mode" | Add `GEMINI_API_KEY` to backend\.env and restart uvicorn |
| Excel export downloads a broken file | Ensure the trip was generated with "save plan" enabled (default) |
