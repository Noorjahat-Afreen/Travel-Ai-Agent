# Data Sources & Attribution

Every record displayed by the application carries the provider name, a link and
a retrieval timestamp. This document summarises each provider, what is used and
the usage rules respected.

| Provider | Used for | Attribution / policy |
| --- | --- | --- |
| **OpenStreetMap Nominatim** (`nominatim.openstreetmap.org`) | Geocoding cities, landmarks; state lookup | Data © OpenStreetMap contributors, ODbL. Policy: descriptive User-Agent, ≤1 req/s, caching — <https://operations.osmfoundation.org/policies/nominatim/> |
| **OpenStreetMap Overpass** (3 mirrors) | Hotels, restaurants, attractions POIs (tags: tourism, amenity, historic) | ODbL. Queries bounded (`around`, `out center N`) + 6 h cache — <https://dev.overpass-api.de/overpass-doc/> |
| **Photon by Komoot** (`photon.komoot.io`) | POI fallback when Overpass is unreachable | OpenStreetMap data via Komoot — <https://photon.komoot.io> |
| **Wikipedia REST API** (`en.wikipedia.org/api/rest_v1`) | Verified destination/landmark descriptions | Text under CC BY-SA; article link shown with every summary — <https://www.mediawiki.org/wiki/API:REST_api> |
| **Open-Meteo** (`api.open-meteo.com`) | Daily forecasts (temp, rain probability, conditions) | Free tier terms; ~16-day horizon honestly enforced — <https://open-meteo.com/en/terms> |
| **OSRM demo router** (`router.project-osrm.org`) | Road distance/duration estimates (labelled ESTIMATE) | Demo server usage limits; cached 24 h — <https://github.com/Project-OSRM/osrm-backend> |
| **IRCTC / redBus / Google Flights / MakeMyTrip / Skyscanner / Booking.com** | Booking **deep links only** (no scraping, no data capture) | Provider public URL formats; all prices/availability shown on their sites |
| **Google Maps URL API 1** | Get-directions links | Documented scheme: `https://www.google.com/maps/dir/?api=1&…` |
| **Curated reference dataset** (`services/india_reference.py`) | 102 destination facts: names, states, coordinates (OSM-sourced), one-line blurbs, rail station codes, airport codes | Factual reference data; every entry carries a Wikipedia verification link |

## What we never do

- Never scrape provider HTML.
- Never invent records, ratings, fares, availability or opening hours.
- Never present estimates as supplier prices.
- Never store API keys in the database or frontend.

## Destination photographs

`frontend/public/images/*.jpg` were collected via a public web image search
during development (see `scripts/fetch_images.py` at the repo root; source site
per image in `public/images/manifest.json`). They are used for educational
demonstration with the project; replace them with your own licensed images for
any commercial use.
